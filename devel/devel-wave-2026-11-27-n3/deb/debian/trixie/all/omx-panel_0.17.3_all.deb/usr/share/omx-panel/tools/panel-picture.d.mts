/** The renderer command: $OMX_PANEL_RENDER, the tree's build (tools/ beside renderer/), else the one on PATH. */
export function rendererCommand(): string;
/**
 * The host's side of a picture, as the renderer's state file reads it: the title, every control at its declared default
 * with the text the MOD GUI face writes for it (`readings` gives a control, a meter's level, a reading of its own), and
 * the static curves, stems and marks the face draws from the same declaration.
 */
export function defaultState(descriptor: any, { panel, stem, readings }?: {
    readings?: {} | undefined;
}): {
    brand: any;
    name: any;
    values: {};
    curves: {};
    marks: {};
    stems: {};
};
/** The layout a host draws: `describe --layout`'s, refused by its codes when the derivation gives no description. */
export function servedLayout(descriptor: any, { panel, where }?: {}): any;
/** Draws the picture of `descriptor` under `panel` into `png`; `{ width, height }`. */
export function picture(descriptor: any, { panel, stem, png, scale, style, where }?: {
    scale?: number | undefined;
}): {
    width: number | undefined;
    height: number | undefined;
};
