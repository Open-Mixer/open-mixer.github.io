/** The commit the inputs were built from: BUILT_FROM.txt (substituted by git archive), else git's HEAD, else a refusal. */
export function builtFrom(inDir: any, env?: NodeJS.ProcessEnv): string;
/**
 * Holds the base file `base` to the sets `sets`: each member answered from the base alone with a description that has
 * controls. Throws a PluginRefusal `base-incomplete` naming every member that is not.
 */
export function checkBase({ base, inDir, sets, env }: {
    base: any;
    inDir: any;
    sets: any;
    env?: NodeJS.ProcessEnv | undefined;
}): {
    held: number;
};
/** The base from `inDir` into `out`, held to `sets`. Throws a PluginRefusal for what the command reports. */
export function buildBase({ inDir, out, sets, env }: {
    inDir: any;
    out: any;
    sets?: never[] | undefined;
    env?: NodeJS.ProcessEnv | undefined;
}): {
    entries: number;
    builtFrom: string;
    held?: undefined;
} | {
    entries: number;
    builtFrom: string;
    held: number;
};
