/** The CLAP search list when CLAP_PATH is unset: ~/.clap, then the system places, as `omx-clap-scan` reads it. */
export function clapDefaultPath(env?: NodeJS.ProcessEnv): string;
/**
 * Each installed CLAP plugin by its id, the first file on the list holding it, with that file's SHA-256 (null:
 * unreadable); null when `omx-clap-scan` is not on PATH or its answer cannot be read, so nothing can be said of what is
 * installed. A file the scanner cannot read holds no plugin; an empty list (no directory exists) is no plugin installed.
 */
export function installedClap(clapPath: any, { env, log }?: {
    env?: NodeJS.ProcessEnv | undefined;
    log?: (() => void) | undefined;
}): Map<any, any> | null;
/**
 * The pass's store half. Returns { described, noDescriptor, pruned, failed } and logs each plugin it could not store and
 * each key it pruned; `failed` counts the store's refusals (a plugin with no descriptor is no failure: nothing to derive).
 * @param {{ lv2Path: string, clapPath?: string, env?: NodeJS.ProcessEnv, log?: (line: string) => void }} o
 */
export function pass({ lv2Path, env, clapPath, log }: {
    lv2Path: string;
    clapPath?: string;
    env?: NodeJS.ProcessEnv;
    log?: (line: string) => void;
}): {
    described: number;
    noDescriptor: number;
    pruned: number;
    failed: number;
    store: boolean;
};
