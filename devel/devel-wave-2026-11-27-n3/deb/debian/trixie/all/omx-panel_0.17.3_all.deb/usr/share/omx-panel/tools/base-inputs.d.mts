/**
 * The set's inputs written under `base`. Returns { set, inputs, plugins } (the set file's path, the inputs written, the
 * set's members). Throws a PluginRefusal for what the command reports.
 */
export function writeInputs({ set, declarationsDir, base, lv2Path, clapPath, env }: {
    set: any;
    declarationsDir: any;
    base: any;
    lv2Path?: string | undefined;
    clapPath?: string | undefined;
    env?: NodeJS.ProcessEnv | undefined;
}): {
    set: string;
    inputs: number;
    plugins: number;
};
