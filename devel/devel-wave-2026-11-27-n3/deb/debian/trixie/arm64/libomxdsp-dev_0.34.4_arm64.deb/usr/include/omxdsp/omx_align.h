// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
/**
 * @file omx_align.h
 * @brief The input alignment delay: one microphone pushed back to meet another.
 *
 * A per-STRIP input-stage latency: 100 % wet, no feedback, applied beside trim and polarity so
 * everything downstream (the tap points, the analyser rings the measurement reads, EQ, dynamics,
 * the sends) sees the corrected signal. It is not the FX delay (fx/omx_delay.h, a musical echo)
 * and not the console's output delay (a loudspeaker zone, per destination).
 *
 * It is an ORDER-5 FRACTIONAL line ({@link omx_fdelay}), not a whole-sample ring
 * (the decided fractional-delay design):
 *   - the target is `ms × rate / 1000` fractional samples, never rounded first;
 *   - a whole-sample target is an exact copy (the kernel is skipped), so 0 is a passthrough;
 *   - below OMX_ALIGN_FRACTION_MIN_RATE (44.1/48 kHz, where Lagrange-5 loses 6.67-11.40 dB at
 *     20 kHz) and below the kernel's reach (2 samples) the TARGET is the NEAREST WHOLE SAMPLE —
 *     where the line settles; a move between targets still slews through the kernel;
 *   - a re-point SLEWS the read point by OMX_ALIGN_SLEW per sample and lands exactly — one
 *     continuous read of one signal, never a blend of two taps, so delay review D-2's
 *     quantum-wide hole cannot occur, and a move is block-size invariant;
 *   - ONE target for both legs (delay review D-6): one split and one kernel serve the pair.
 *
 * 100 ms is 34 m of air — further apart than two microphones on one source can be while still
 * hearing that source. The rings are the caller's, allocated lazily on the control thread on the
 * first non-zero delay; a NULL ring is a passthrough.
 *
 * Contract: NO allocation, NO lock, NO libc beyond <math.h>.
 */
#ifndef OMX_ALIGN_H
#define OMX_ALIGN_H

#include <math.h>
#include <stdint.h>

#include <omxcontract/omx_vocabulary.h>
#include <omxdsp/omxdsp_definitions.h>
#include "omx_contract.h"
#include "omx_fdelay.h"
#include "omx_kernel_desc.h"

/** @brief The alignment's ceiling, ms: the contract's input alignment travel top (INPUT_ALIGN_DELAY_RANGE.max). */
#define OMX_ALIGN_MAX_MS OMX_INPUT_ALIGN_DELAY_RANGE_MAX
/** @brief Highest graph rate the alignment ring is sized for, so MAX_MS is reachable at every rate. */
#define OMX_ALIGN_MAX_RATE OMX_RT_HARD_TARGET_RATE
/** @brief The Lagrange order the alignment line constructs (fractional-delay-line §3: strip alignment). */
#define OMX_ALIGN_ORDER 5
/** @brief Per-leg ring capacity, samples: MAX_MS at MAX_RATE plus the order-5 kernel's reach — the
 * value of `omx_fdelay_cap_for(19200, OMX_ALIGN_ORDER)`, asserted equal by the align_fdelay oracle. */
#define OMX_ALIGN_CAP (((OMX_ALIGN_MAX_RATE / 1000) * OMX_ALIGN_MAX_MS) + ((OMX_ALIGN_ORDER - 1) / 2) + 2)
/** @brief How fast a re-point moves the read point: samples of delay per sample of time. A ratio, so the
 * pitch excursion during a move (3.1 %) and the time a move takes are the same at every rate. */
#define OMX_ALIGN_SLEW (1.0f / 32.0f)
/** @brief The lowest graph rate at which the fraction is applied; below it the target is the nearest
 * whole sample (smart-alignment §7: the fractional-delay line's §2 numbers). */
#define OMX_ALIGN_FRACTION_MIN_RATE 88200.0f

/** @brief One strip's alignment lines + RT state. Rings are CONTROL-thread owned and NULL until the
 * first non-zero delay (omx_align_arm()); a NULL ring is a passthrough, so the RT needs no
 * other gate. */
struct omx_align_state {
  float *ring_l;                    /**< The left ring, OMX_ALIGN_CAP floats; NULL: a passthrough. */
  float *ring_r;                    /**< The right ring, OMX_ALIGN_CAP floats. */
  uint32_t cap;                     /**< Slots per ring. */
  struct omx_fdelay line_l, line_r; /**< Armed over ring_l / ring_r at OMX_ALIGN_ORDER. */
  float cur;                        /**< RT-owned applied delay, fractional samples, both legs. */
};

#undef OMX_CONTRACT_STAGE
#define OMX_CONTRACT_STAGE "align/arm"
/**
 * @brief Arm a strip's two alignment lines over two zeroed rings of OMX_ALIGN_CAP floats; the
 *        applied delay starts at 0.
 * @param a The state.
 * @param rl The left ring.
 * @param rr The right ring.
 * @return 1 when both lines armed, 0 (and nothing published) otherwise.
 * @pre `align-rings-are-given`.
 * @post `the-ceiling-is-reachable-at-the-highest-rate`.
 * @note Before the audio thread can see `ring_l` (the caller fences). No allocation.
 * @thread control
 */
static inline int omx_align_arm(struct omx_align_state *a, float *rl, float *rr) {
  OMX_PRE(rl != NULL && rr != NULL, "align-rings-are-given");
  if (rl == NULL || rr == NULL) return 0;
  if (omx_fdelay_init(&a->line_l, rl, OMX_ALIGN_CAP, OMX_ALIGN_ORDER) != OMX_FDELAY_OK) return 0;
  if (omx_fdelay_init(&a->line_r, rr, OMX_ALIGN_CAP, OMX_ALIGN_ORDER) != OMX_FDELAY_OK) return 0;
  a->cur = 0.0f;
  a->cap = OMX_ALIGN_CAP;
  a->ring_r = rr;
  a->ring_l = rl; /* last: the RT's gate */
  OMX_POST(omx_fdelay_max_delay(a->cap, OMX_ALIGN_ORDER) >= (float)((OMX_ALIGN_MAX_RATE / 1000) * OMX_ALIGN_MAX_MS),
           "the-ceiling-is-reachable-at-the-highest-rate");
  return 1;
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "align/target"
/**
 * @brief The alignment's TARGET — where the line settles — for `ms` at rate `sr`.
 *
 * `ms × sr / 1000` fractional samples, clamped into [0, OMX_ALIGN_MAX_MS at sr] and the ring, a
 * non-finite or negative request read as 0, and the nearest whole sample below
 * OMX_ALIGN_FRACTION_MIN_RATE or under the kernel's reach. The ONE ms → samples conversion this
 * stage takes; the number a latency or readback publishes.
 * @param ms The requested delay, ms.
 * @param sr The graph rate, Hz.
 * @return The target, samples.
 * @post `the-target-is-inside-the-ring`.
 * @note Thread-safe: arithmetic.
 * @thread audio
 */
static inline float omx_align_target(float ms, float sr) {
  float m = (ms - ms == 0.0f && ms > 0.0f) ? ms : 0.0f;
  if (m > (float)OMX_ALIGN_MAX_MS) m = (float)OMX_ALIGN_MAX_MS;
  /* In double, divided by 1000 rather than multiplied by 0.001f (which is inexact): a dialled
   * delay that IS a whole number of samples (0.5 ms at 96 kHz) arrives as exactly 48.0, so the
   * line takes its exact-copy branch instead of a kernel 4e-6 of a sample off whole. */
  float d = (float)((double)m * (double)sr / 1000.0);
  const float maxd = omx_fdelay_max_delay(OMX_ALIGN_CAP, OMX_ALIGN_ORDER);
  if (!(d >= 0.0f)) d = 0.0f;
  if (d > maxd) d = maxd;
  /* Where the line SETTLES: the nearest whole sample below OMX_ALIGN_FRACTION_MIN_RATE and below
   * the kernel's reach (smart-alignment §7); the moving read point is never rounded here. */
  if (d != floorf(d) && (sr < OMX_ALIGN_FRACTION_MIN_RATE || d < omx_fdelay_min_delay(OMX_ALIGN_ORDER)))
    d = floorf(d + 0.5f);
  OMX_POST(d >= 0.0f && d <= maxd, "the-target-is-inside-the-ring");
  return d;
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "align/read"
/**
 * @brief The delay the line READS at an applied position `d`: `d` itself, except a fraction under
 *        the order-5 kernel's reach (2 samples), which reads the nearest whole sample — the only
 *        rounding of a MOVING read point, and only within two samples of zero.
 * @param d The applied position, samples.
 * @return The delivered delay, samples.
 * @pre `the-applied-delay-is-not-negative`.
 * @post `a-fractional-read-clears-the-kernels-reach`.
 * @note Thread-safe: arithmetic.
 * @thread audio
 */
static inline float omx_align_deliverable(float d) {
  OMX_PRE(d >= 0.0f, "the-applied-delay-is-not-negative");
  const float out =
      (d < omx_fdelay_min_delay(OMX_ALIGN_ORDER) && d != floorf(d)) ? floorf(d + 0.5f) : d;
  OMX_POST(out == floorf(out) || out >= omx_fdelay_min_delay(OMX_ALIGN_ORDER),
           "a-fractional-read-clears-the-kernels-reach");
  return out;
}

/**
 * @brief Split delivered delay `dd` into the whole distance `*id` and, unless it is an exact copy,
 *        the kernel `c`; the one split both of omx_align_apply's loops take.
 * @param a The state.
 * @param dd The delivered delay, samples.
 * @param id Out: the whole distance.
 * @param c Out: OMX_FDELAY_MAX_TAPS kernel taps.
 * @return `c`, or NULL for an exact copy.
 * @pre `the-read-is-inside-the-ring`.
 * @post `the-whole-distance-is-inside-the-ring`.
 * @note No allocation, bounded work.
 * @thread audio
 */
static inline const float *omx_align_kernel(const struct omx_align_state *a, float dd,
                                            uint32_t *id, float *c) {
  OMX_PRE(dd >= 0.0f && dd <= omx_fdelay_max_delay(a->line_l.cap, OMX_ALIGN_ORDER),
          "the-read-is-inside-the-ring");
  float kf = 0.0f;
  if (omx_fdelay_split(&a->line_l, dd, id, &kf)) return NULL;
  omx_fdelay_lagrange(OMX_ALIGN_ORDER, kf, c);
  OMX_POST(*id < a->line_l.cap, "the-whole-distance-is-inside-the-ring");
  return c;
}

/**
 * @brief Sample `i` of both legs through their lines at one split: write, then read `id` behind.
 * @param a The state.
 * @param l The left (or mono) leg.
 * @param r The right leg, or NULL for mono.
 * @param i The frame.
 * @param id The whole distance.
 * @param k The kernel, or NULL for an exact copy.
 * @pre `both-reads-are-inside-the-ring`.
 * @note No allocation, fixed work.
 * @thread audio
 */
static inline void omx_align_rw(struct omx_align_state *a, float *l, float *r, uint32_t i,
                                uint32_t id, const float *k) {
  OMX_PRE(id < a->line_l.cap && (r == NULL || id < a->line_r.cap), "both-reads-are-inside-the-ring");
  omx_fdelay_write(&a->line_l, l[i]);
  l[i] = omx_fdelay_read_at(&a->line_l, id, k);
  if (r != NULL) {
    omx_fdelay_write(&a->line_r, r[i]);
    r[i] = omx_fdelay_read_at(&a->line_r, id, k);
  }
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "align"
/**
 * @brief Delay a strip's legs in place toward `tgt` samples (omx_align_target()).
 *
 * Steady (`cur == tgt`): one kernel for the block. Moving: the applied delay steps toward `tgt`
 * by OMX_ALIGN_SLEW per sample and lands exactly on it; the kernel follows it per sample. An
 * unarmed state (NULL ring) is a passthrough.
 * @param a The state.
 * @param l The left (or mono) leg.
 * @param r The right leg, or NULL for a mono strip.
 * @param n Frames.
 * @param tgt The target, samples.
 * @pre `the-target-is-inside-the-ring`.
 * @invariant `write-cursor-inside-the-ring`.
 * @note No allocation, bounded work.
 * @thread audio
 */
static inline void omx_align_apply(struct omx_align_state *a, float *l, float *r, uint32_t n,
                                   float tgt) {
  if (a->ring_l == NULL || l == NULL || n == 0u || a->line_l.order == 0) return;
  OMX_PRE(tgt >= 0.0f && tgt <= omx_fdelay_max_delay(a->cap, OMX_ALIGN_ORDER),
          "the-target-is-inside-the-ring");
  float cur = a->cur;
  uint32_t i = 0u, id = 0u;
  float c[OMX_FDELAY_MAX_TAPS];
  for (; i < n && cur != tgt; i++) {
    const float gap = tgt - cur;
    cur = (gap > OMX_ALIGN_SLEW) ? cur + OMX_ALIGN_SLEW
          : (gap < -OMX_ALIGN_SLEW) ? cur - OMX_ALIGN_SLEW
                                    : tgt;
    const float *k = omx_align_kernel(a, omx_align_deliverable(cur), &id, c);
    omx_align_rw(a, l, r, i, id, k);
  }
  a->cur = cur;
  if (i < n) {
    const float *k = omx_align_kernel(a, omx_align_deliverable(cur), &id, c);
    for (; i < n; i++) omx_align_rw(a, l, r, i, id, k);
  }
  OMX_INVARIANT(a->line_l.wpos < a->line_l.cap, "write-cursor-inside-the-ring");
}
#undef OMX_CONTRACT_STAGE

/** @brief The alignment as the generic face (fx/omx_fx_face.h) serves it: the strip's two lines over two rings
 * of its own, inline, so the full travel is reachable at every oracle rate and nothing is allocated. The state
 * points into its own rings: it is bound where it lives and never copied after. */
struct omx_align_kernel {
  float sr;                     /**< The sample rate init bound the state to, Hz. */
  struct omx_align_state st;    /**< The two lines, armed over `ring_l` and `ring_r`. */
  float tgt;                    /**< The target, fractional samples, omx_align_target() of `ms`. */
  float ms;                     /**< inputAlignDelay as the last set took it, ms. */
  int enabled;                  /**< Non-zero while engaged, as the last set left it. */
  float ring_l[OMX_ALIGN_CAP];  /**< The left line's ring. */
  float ring_r[OMX_ALIGN_CAP];  /**< The right line's ring. */
};

/**
 * @brief Bind a zeroed state to its rate and arm its two lines over its own rings, at no delay. Allocates nothing.
 * @param state A struct omx_align_kernel, zeroed.
 * @param sr The sample rate, Hz: one of the nine oracle rates.
 * @return 1 when usable, 0 when the rate is not one of them.
 * @thread control
 */
static inline int omx_align_kernel_init(void *state, float sr) {
  struct omx_align_kernel *k = state;
  if (!omx_rate_is_oracle_full(sr)) return 0;
  k->sr = sr;
  if (!omx_align_arm(&k->st, k->ring_l, k->ring_r)) return 0;
  k->enabled = 1;
  return 1;
}

#define OMX_CONTRACT_STAGE "align/clear"
/**
 * @brief Silence both lines, keeping the target: the rings back to 0, both write cursors and the applied delay
 *        back at 0, as init's arm left them. The lines stay armed over the same rings, so only what a block moves
 *        is reset; the arm itself is the control thread's. Bounded work, no allocation.
 * @param state A struct omx_align_kernel.
 * @post `cleared-line-is-fresh`.
 * @thread audio
 */
static inline void omx_align_kernel_clear(void *state) {
  struct omx_align_kernel *k = state;
  for (uint32_t i = 0; i < (uint32_t)OMX_ALIGN_CAP; i++) k->ring_l[i] = 0.0f, k->ring_r[i] = 0.0f;
  k->st.line_l.wpos = k->st.line_r.wpos = 0u;
  k->st.cur = 0.0f;
  OMX_POST(k->ring_l[0] == 0.0f && k->ring_r[OMX_ALIGN_CAP - 1] == 0.0f && k->st.cur == 0.0f && k->st.line_l.wpos == 0u,
           "cleared-line-is-fresh");
}
#undef OMX_CONTRACT_STAGE

/**
 * @brief Take the resolved inputAlignDelay: the target the line slews to, omx_align_target()'s, the kernel's own
 *        conversion. A bypassed -> engaged edge clears the lines, so a re-engaged alignment is a fresh one.
 * @param state A struct omx_align_kernel.
 * @param values inputAlignDelay, ms, inside INPUT_ALIGN_DELAY_RANGE.
 * @param bypass Non-zero while bypassed.
 * @thread audio
 */
static inline void omx_align_kernel_set(void *state, const float *values, int bypass) {
  struct omx_align_kernel *k = state;
  if (!bypass && !k->enabled) omx_align_kernel_clear(k);
  k->enabled = bypass ? 0 : 1;
  k->ms = values[0];
  k->tgt = omx_align_target(k->ms, k->sr);
}

/**
 * @brief One engaged block, both legs in place, toward the target: omx_align_apply().
 * @param state A struct omx_align_kernel.
 * @param l The left leg, `n` frames.
 * @param r The right leg, `n` frames.
 * @param n The block length.
 * @thread audio
 */
static inline void omx_align_kernel_process(void *state, float *l, float *r, uint32_t n) {
  struct omx_align_kernel *k = state;
  omx_align_apply(&k->st, l, r, n, k->tgt);
}

/**
 * @brief The frames of latency the alignment reports: none. The delay IS the effect; a host that compensated it
 *        would undo the alignment.
 * @param state A struct omx_align_kernel, unread.
 * @return 0.
 * @thread audio
 */
static inline uint32_t omx_align_kernel_latency(const void *state) {
  (void)state;
  return 0u;
}

/**
 * @brief The alignment's descriptor: data/kernels/align.json's one control through the render. The travel declares
 *        no default; its floor, no delay, is the come-up value and what a non-finite word reads as.
 * @return The descriptor, a constant.
 * @thread control
 */
static inline const struct omx_kernel_desc *omx_align_desc(void) {
  static const struct omx_param_desc params[] = {
      {"inputAlignDelay", OMX_PARAM_TRAVEL, (float)OMX_INPUT_ALIGN_DELAY_RANGE_MIN, (float)OMX_INPUT_ALIGN_DELAY_RANGE_MAX,
       (float)OMX_INPUT_ALIGN_DELAY_RANGE_MIN, OMX_PARAM_UNITS_MS},
  };
  static const struct omx_kernel_desc desc = {
      "align", sizeof(struct omx_align_kernel), 1u, params, 0u, NULL, omx_align_kernel_init, omx_align_kernel_set,
      omx_align_kernel_process, omx_align_kernel_clear, omx_align_kernel_latency, NULL,
  };
  return &desc;
}

#endif /* OMX_ALIGN_H */
