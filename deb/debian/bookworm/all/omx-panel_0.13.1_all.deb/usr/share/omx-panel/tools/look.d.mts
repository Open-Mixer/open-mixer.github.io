/** WCAG relative luminance of `#rrggbb`. */
export function luminance(h: any): number;
/** WCAG contrast ratio of two `#rrggbb` colours. */
export function contrast(a: any, b: any): number;
/**
 * Every rule of the role file `doc` broken, as sentences, or none. The floors are measured on `values` (name ->
 * #rrggbb) when given, else on the defaults: a host's table is held to the same floors by the same function.
 */
export function checkRoles(doc: any, values: any): string[];
/** tools/look.json's text: the look the defaults are, every role at its default, and the font. */
export function emitLook(doc?: any): string;
/** renderer/src/look_roles.h's text: the role names read_look requires of every look. */
export function emitRoleHeader(doc?: any): string;
export const ROLES_JSON: string;
export const LOOK_JSON: string;
export const ROLE_HEADER: string;
/** The families a role belongs to (omx look §2(i)); finish is a host's chrome, never a role's. */
export const FAMILIES: readonly string[];
/** The tokens that are not colours: the CSS font stack, and the font file (relative to tools/) the raster reads. */
export const NOT_COLOURS: readonly string[];
export function loadRoles(file?: string): any;
export function roleNames(doc?: any): any;
/** The tokens tools/look.json lists: every role, then the font. */
export const LOOK_TOKENS: readonly any[];
