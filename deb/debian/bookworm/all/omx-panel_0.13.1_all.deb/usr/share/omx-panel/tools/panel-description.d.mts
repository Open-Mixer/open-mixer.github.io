/**
 * The standard widget control `c` (a descriptor control) is drawn with: `{ widget }`, a meter's with
 * its `measurement`, `held` and `clip`, a trigger's switch `momentary`. A declared widget wins; else a
 * read-only travel in a level unit is a meter and any other read-only control a display, a toggle or a
 * trigger a switch, a choice a selector, a travel a knob. A foreign meter (one inferred here, not read
 * from the descriptor's `meters` word) never guesses its measurement from the unit, and holds nothing
 * and clips nothing of its own (contract §7.9).
 */
export function widgetOf(c: any, declared: any): {
    widget: any;
    measurement?: undefined;
    held?: undefined;
    clip?: undefined;
    momentary?: undefined;
} | {
    widget: string;
    measurement: null;
    held: boolean;
    clip: boolean;
    momentary?: undefined;
} | {
    widget: string;
    momentary: boolean;
    measurement?: undefined;
    held?: undefined;
    clip?: undefined;
};
/**
 * The family of a plugin whose controls are `controls` (descriptor controls): `{ family }`, and for a
 * declared family none of its controls' meanings backs, `{ family, needs }` naming what it lacks. With
 * no declared family, an effect takes the first family whose meanings it carries; an instrument, or a
 * plugin no family fits, is none.
 */
export function familyOf(controls: any, declared: any, features?: any[]): {
    family: any;
    needs: any;
} | {
    family: any;
    needs?: undefined;
};
/** Whether every required role of `family` (role-table.mjs REQUIRED_ROLES) is mapped at index 0 in `roles`: the one check that
 * decides whether a family's view is drawn, for a declared family and a derived one alike. `none` needs nothing. */
export function requiredRolesMapped(family: any, roles: any): any;
/**
 * The panel of `descriptor`, of any origin. `panel` (a declaration's) gives the family, sections,
 * order, roles, widgets and graphs; with none, the sections are the controls' groups, the family the
 * one their meanings make and the roles the ones their meanings play. `ns` is the label-key namespace
 * (without one the label keys are null); `choiceUnits` and `byKind` are a declaration's extras.
 */
export function panelLayout(descriptor: any, { panel, ns, where, choiceUnits, byKind, family: forced, inferredRoles, completingRoles, derive }?: {
    where?: string | undefined;
    choiceUnits?: {} | undefined;
    byKind?: {} | undefined;
    derive?: boolean | undefined;
}): {
    origin: any;
    family: any;
    sections: any;
    controls: any;
    roles: any[];
    unpublished: {
        role: string | undefined;
        symbol: any;
        why: string;
    }[];
    displays: any;
    defaults: any;
    ports: {
        inputs: {
            id: any;
            name: any;
            role: any;
            channels: any;
        }[];
        outputs: {
            id: any;
            name: any;
            role: any;
            channels: any;
        }[];
        sidechain: boolean;
        notes: boolean;
    };
    easy: any[];
    meters: {
        symbol: any;
        widget: string;
        kind: any;
        measurement: any;
        unit: any;
        min: any;
        max: any;
        channels: any;
        held: boolean;
        clip: boolean;
        label: any;
        labelKey: any;
    }[];
    meterRefusals: any[];
};
/** The mask of a visibility rule: `values` sets bit v for each value v; `atLeast: n` sets bits n..63 (a count: band n
 * shows while the count is n or more). */
export function visibilityMask(rule: any): any;
/** The checked visibility rules of a declared panel over `descriptor`: control symbol -> `{ symbol, visible, mask,
 * default }`, the governing control's symbol and id, the mask, and the governing control's come-up value. */
export function visibilityRules(descriptor: any, visibleWhen?: {}, where?: string): Map<string, {
    symbol: any;
    visible: any;
    mask: any;
    default: any;
}>;
/** Whether control `c` of a layout is shown while the controls read `values` (symbol -> value; a governing control left
 * out reads its come-up value). A control with no visibility rule is always shown. */
export function isVisible(c: any, values?: {}): boolean;
/**
 * THE one cut of a panel into control-surface pages (the pages amendment, one-panel spec 7.14). Every surface pages a
 * plugin's controls through this function at its own width, `perPage` (a surface that states none gets eight); no surface
 * builds, stores or reorders pages. The sequence:
 *
 * 1. the Easy controls (`x.easy`, symbols; a skin's list wins in `describe`), on pages of their own named Easy, Easy 2;
 * 2. then the plugin's declared remote-controls pages, as the host reports them (`remote`: `[{ name, ids }]`, a slot a
 *    control's param id or null), replacing the derived ones; a declared page is not edited, so an Easy control may also
 *    sit on its remote page, and a slot of no control is blank;
 * 3. else the sections in order, each cut at the width with a group kept whole at every width: a page ends early to keep
 *    a group together, a group longer than a page is the only one split, starting on a page of its own and ending
 *    on one, never mixed with its neighbour. A derived page holds a control once. A control with no group is its own.
 *    A section of several pages names each page by the controls it holds, "Band: Freq - Q".
 *
 * A control hidden by `values` (symbol -> current value; a governing control left out reads its come-up value) keeps its
 * slot, blank: the slots do not move with the governing values. Below two encoders a group is plain controls (one a page).
 */
export function pagesOf(x: any, { perPage, remote, values }?: {
    values?: {} | undefined;
}): any[];
/** The canonical serialisation: UTF-8, LF after every line, TAB-separated, parameters by symbol, the
 * fallback labels left out. */
export function panelCanonical(x: any): string;
export const PANEL_ID: "org.openmixer.panel-description/1";
/** The extension's families, by enum value. */
export const FAMILIES: string[];
/** The widgets a face serves, by enum value. */
export const WIDGETS: string[];
/** The standard widgets a panel picks from a descriptor; a representation (a skin) draws each. */
export const STANDARD_WIDGETS: string[];
/** What a meter measures, the level kinds the descriptor spells (contract §7.9): `rms`, `vu` and
 * `ppm` are not words. */
export const MEASUREMENTS: string[];
export function namesAnalogueState(text: any): boolean;
export const METER_REFUSED: "PANEL_METER_REFUSED";
export function servedWidget(standard: any): any;
/** The display kinds and sources, by enum value. */
export const DISPLAY_KINDS: string[];
export const DISPLAY_SOURCES: string[];
/** The origins a band may be planted under besides the operator's `user`: the closed set the console's band origins name. */
export const BAND_ORIGINS: string[];
export const PLACEMENTS: string[];
/** A section `graph` -> the display the extension names for it; a graph with none here is the
 * renderer's own (delay taps, a decay envelope, an LFO). */
export const DISPLAY_OF_GRAPH: {
    'eq-curve': string;
    'dynamics-curve': string;
    'transfer-curve': string;
};
export function basisOf(descriptor: any, section: any): "exact" | "modelled";
export function unitToken(unit: any): any;
export namespace FAMILY_MEANINGS {
    namespace limiter {
        let backs: string[];
        let infer: string[][];
    }
    namespace deesser {
        let backs_1: string[];
        export { backs_1 as backs };
        let infer_1: string[][];
        export { infer_1 as infer };
    }
    namespace gate {
        let backs_2: string[];
        export { backs_2 as backs };
        let infer_2: string[][];
        export { infer_2 as infer };
    }
    namespace dynamics {
        let backs_3: string[];
        export { backs_3 as backs };
        let infer_3: string[][];
        export { infer_3 as infer };
    }
    namespace eq {
        let backs_4: string[];
        export { backs_4 as backs };
        let infer_4: string[][];
        export { infer_4 as infer };
    }
    namespace filter {
        let backs_5: string[];
        export { backs_5 as backs };
        let infer_5: string[][];
        export { infer_5 as infer };
    }
    namespace drive {
        let backs_6: string[];
        export { backs_6 as backs };
        let infer_6: string[][];
        export { infer_6 as infer };
    }
    namespace delay {
        let backs_7: string[];
        export { backs_7 as backs };
        let infer_7: string[][];
        export { infer_7 as infer };
    }
    namespace reverb {
        let backs_8: string[];
        export { backs_8 as backs };
        let infer_8: string[][];
        export { infer_8 as infer };
    }
    namespace pitch {
        let backs_9: string[];
        export { backs_9 as backs };
        let infer_9: string[][];
        export { infer_9 as infer };
    }
    namespace modulation {
        let backs_10: null;
        export { backs_10 as backs };
        let infer_10: string[][];
        export { infer_10 as infer };
    }
}
export function snake(s: any): any;
/** A descriptor with no control to lay out (none stated, or every one hidden): there is no panel to make, and the
 * layout says so by code instead of answering an empty one. */
export class NoControls extends Error {
    code: string;
}
/** A declared family none of whose meanings the controls carry: a transient designer is no compressor (#138). */
export class FamilyNotBacked extends Error {
    code: string;
}
/** A section's declared `bars: true` that fails a check of the bar rule, by the check's code (tools/bars.mjs). */
export class BarsRefused extends Error {
    constructor(message: any, code: any);
    code: any;
}
export function keyOf(c: any): any;
/** The highest value a visibility mask has a bit for: the ABI's visible_mask is 64 bits. */
export const VISIBLE_MAX: 63;
/** The key a control carries its declared group under, for the page cut: a symbol, so no serialisation sees it. */
export const GROUP: unique symbol;
/** The name of the Easy controls' page and of a MOD GUI's first section. */
export const EASY_PAGE: "Easy";
/** The slots per page a caller that states no width gets: CLAP_REMOTE_CONTROLS_COUNT. A surface states its own. */
export const PAGE_SIZE: 8;
export function panelFingerprint(x: any): string;
import { INDEXED_ROLES } from './role-table.mjs';
import { ROLES } from './role-table.mjs';
export { INDEXED_ROLES, ROLES };
