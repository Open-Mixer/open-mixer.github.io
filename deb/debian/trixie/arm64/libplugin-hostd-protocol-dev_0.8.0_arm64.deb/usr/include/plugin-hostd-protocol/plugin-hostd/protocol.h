/* SPDX-License-Identifier: GPL-3.0-or-later */
/*
 * This file is part of plugin-hostd-protocol.
 *
 * plugin-hostd-protocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * plugin-hostd-protocol is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with plugin-hostd-protocol.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
 */

/* The protocol surface plugin-hostd owns, declared once. The daemon compiles against this header; the tables of
 * README.md, the key list of the man page and protocol/plugin-hostd.json are generated from it by tools/protocol-gen.c
 * (make gen; make check-generated fails on drift). A consumer includes this header and reads nothing else, or reads the
 * JSON when it is not C. The mod-host protocol itself, which the daemon speaks unchanged, is not declared here.
 *
 * The daemon's own verbs are declared in its contract directory (data/verbs.json, docs/contract-dir.md of omx-contract)
 * and rendered into plugin_hostd_host_verbs.h beside this header: a verb is OMX_VERB_<VERB>, its line OMX_VERB_<VERB>_FMT,
 * its reply OMX_VERB_<VERB>_REPLY and its refusals OMX_VERB_<VERB>_CODES_INIT. The tables below take the words and the
 * replies from there and add the prose of the README. */

/** @file protocol.h
 * @brief The protocol surface plugin-hostd owns, declared once.
 *
 * The phd_* inline functions keep no state of their own.
 */

#ifndef PLUGIN_HOSTD_PROTOCOL_H
#define PLUGIN_HOSTD_PROTOCOL_H

#include <limits.h>
#include <stdlib.h>
#include <string.h>

#include "omx_clap_host_verbs.h"
#include "omx_clap_vocabulary.h"
#include "plugin_hostd_protocol_host_verbs.h"
#include "plugin_hostd_protocol_vocabulary.h"
#include "plugin_db_vocabulary.h"

/** @brief the version of the protocol this header declares
 *
 * It is bumped when a name, a code or the shape of a verb or an event changes incompatibly.
 */
#define PLUGIN_HOSTD_PROTOCOL_VERSION 1

/* ---------------------------------------------------------------- readiness */

/** @brief the daemon prints this line once both its ports accept */
#define PHD_READY_LINE "plugin-hostd ready!"
/** @brief a worker prints a line ending with this once its socket accepts */
#define PHD_WORKER_READY_MARKER "ready!"

/** @brief the QT_QPA_PLATFORM value that gives Qt a platform that needs no display
 *
 * A plugin that makes a QApplication as it is instantiated (synthv1 and the other Qt-linked LV2 plugins) aborts when
 * the platform plugin Qt picks cannot open a display.
 *
 * With neither DISPLAY nor WAYLAND_DISPLAY set, QT_QPA_PLATFORM is set to this unless the user set it:
 * phd_headless_qt() of the library (utils.h), called before the host loads a plugin or starts a process that does.
 */
#define PHD_HEADLESS_QT_PLATFORM "offscreen"

/** @brief tells whether the process has a display session
 *
 * DISPLAY or WAYLAND_DISPLAY is set and not empty. A host with none gives Qt PHD_HEADLESS_QT_PLATFORM; a daemon with
 * none refuses show_external_ui and hide_external_ui itself, with PHD_EXTERNAL_UI_NO_DISPLAY after the -902, since the
 * window would belong to its workers, which inherit its environment.
 *
 * @return nonzero when DISPLAY or WAYLAND_DISPLAY is set and not empty, else 0.
 */
static inline int phd_has_display(void)
{
    const char *x = getenv("DISPLAY"), *wayland = getenv("WAYLAND_DISPLAY");

    return (x && *x) || (wayland && *wayland);
}

/** @brief the word after a window verb's -902 from a daemon with no display session
 *
 * It is omx-clap's hosting.window code for the same fact (data/hosting.json), the word its worker gives after -404
 * when no display answers.
 */
#define PHD_EXTERNAL_UI_NO_DISPLAY "hosting.window.no-display"

/* ---------------------------------------------------------------- constants */

/** @brief the command port without -p; the feedback port is the next one, unless -n is given */
#define PHD_DEFAULT_COMMAND_PORT 5555
/** @brief how long, in milliseconds, the idle tick asks again for a connect a respawned worker could not make yet */
#define PHD_CONNECT_RETRY_MS     5000
/** @brief the protocol socket's buffer in bytes: the longest pin_set line the daemon takes */
#define PHD_LINE_MAX             4096
/** @brief the words of one command line the daemon reads, the verb included; a word past them is not read */
#define PHD_LINE_WORDS_MAX       64
/** @brief the fewest members of a chain: a chain of one is valid */
#define PHD_CHAIN_MEMBERS_MIN    1

/** @brief the constants above as rows X(name, value, unit, meaning), for the generators of the docs
 *
 * @param X the macro each row is passed to.
 */
#define PHD_CONSTANTS(X) \
    X(protocol_version, PLUGIN_HOSTD_PROTOCOL_VERSION, "version", \
      "the protocol version hello sends and answers on the socket; the table's version key is the same number") \
    X(default_command_port, PHD_DEFAULT_COMMAND_PORT, "port", \
      "the command port without -p; the feedback port is the next one, unless -n is given") \
    X(connect_retry_ms, PHD_CONNECT_RETRY_MS, "ms", \
      "how long the idle tick asks again for a connect a respawned worker could not make yet") \
    X(line_max, PHD_LINE_MAX, "bytes", "the protocol socket's buffer: the longest pin_set line the daemon takes") \
    X(line_words_max, PHD_LINE_WORDS_MAX, "words", \
      "the words of one command line the daemon reads, the verb included; a word past them is not read") \
    X(chain_members_min, PHD_CHAIN_MEMBERS_MIN, "instances", \
      "the fewest members of a chain: a chain of one is valid, so one isolated plugin is a chain like any other")

/* ---------------------------------------------------------------- placement */

/** @brief the placement word for an instance in a worker of its own */
#define PHD_PLACE_OWN           "own"
/** @brief the placement word that takes the placement policy_set gives its format */
#define PHD_PLACE_DEFAULT       "default"
/** @brief the prefix of the placement of a pool: pool:\<name\> */
#define PHD_PLACE_POOL_PREFIX   "pool:"
/** @brief the prefix of the place of a chain's worker in worker_list, chain:\<chain\>
 *
 * Chain puts instances there, and an add naming it puts its instance at the end of that chain, in the chain's worker
 * (#348).
 */
#define PHD_PLACE_CHAIN_PREFIX  "chain:"
/** @brief the separator in the place of the worker of segment k of a plan, chain:\<plan\>.\<k\>
 *
 * k counts from 0 in the plan's order; only plan puts instances there, and the plan's number is its own, apart from the
 * numbers of the chains chain declares.
 */
#define PHD_PLACE_PLAN_SEPARATOR "."
/** @brief a full pool opens \<name\>\<separator\>\<n\>, n counting from 2 */
#define PHD_POOL_SIBLING_SEPARATOR "#"

/** @brief the fewest characters of a pool name */
#define PHD_POOL_NAME_MIN 1
/** @brief the most characters of a pool name */
#define PHD_POOL_NAME_MAX 32
/** @brief the characters of a pool name: ranges written x-y, a '-' last or first is itself */
#define PHD_POOL_NAME_CLASS "A-Za-z0-9_-"

/** @brief the placements a verb takes, as text: own | pool:\<name\> | chain:\<chain\> | default */
#define PHD_PLACEMENT_SYNTAX \
    PHD_PLACE_OWN " | " PHD_PLACE_POOL_PREFIX "<name> | " PHD_PLACE_CHAIN_PREFIX "<chain> | " PHD_PLACE_DEFAULT

/** @brief turns its argument into a string literal without expanding it first; use PHD_STR
 *
 * @param x the tokens to turn into a string.
 */
#define PHD_STR_(x) #x
/** @brief turns its argument, after macro expansion, into a string literal
 *
 * @param x the tokens to expand and turn into a string.
 */
#define PHD_STR(x)  PHD_STR_(x)
/** @brief the regular expression a pool name matches whole
 *
 * It is built from PHD_POOL_NAME_CLASS, PHD_POOL_NAME_MIN and PHD_POOL_NAME_MAX.
 */
#define PHD_POOL_NAME_PATTERN \
    "^[" PHD_POOL_NAME_CLASS "]{" PHD_STR(PHD_POOL_NAME_MIN) "," PHD_STR(PHD_POOL_NAME_MAX) "}$"

/* the formats a worker holds, and the words a verb takes for "every one", "all" and "none" */
/** @brief the name of the LV2 format */
#define PHD_FORMAT_LV2  "lv2"
/** @brief the name of the CLAP format */
#define PHD_FORMAT_CLAP "clap"
/** @brief the format name of the LV2 plugins the CLAP worker runs through its LV2 adapter
 *
 * A row of its own, reached by lv2_worker and never by a uri.
 */
#define PHD_FORMAT_LV2_CLAP "lv2-clap"
/** @brief the format word that stands for every format */
#define PHD_FORMAT_ANY  "*"
/** @brief a format argument as the verb table writes it: \<format | *\> */
#define PHD_FORMAT_ARGUMENT "<format | " PHD_FORMAT_ANY ">"
/** @brief the word a verb takes for every one of its things */
#define PHD_WORD_ALL    "all"
/** @brief the word that stands for none, in a verb's argument and in a reply */
#define PHD_WORD_NONE   "-"
/** @brief the word history_get answers while the history file is blocked or history_window_s is 0 */
#define PHD_WORD_UNAVAILABLE "unavailable"
/** @brief after an instance id in worker_list: the pins read again refuse its files, and it keeps running */
#define PHD_WORKER_PIN_REFUSED "!"

/** @brief the built-in formats, as rows X(id, name), in the order of the daemon's table (src/formats.c)
 *
 * The rest of what a format is (its prefix, its worker, the files its pin holds, whether its pin holds in a shared
 * world, who answers its instance verbs) is a field of its row there, and a format joins with a row.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_FORMATS(X) X(LV2, PHD_FORMAT_LV2) X(CLAP, PHD_FORMAT_CLAP) X(LV2_CLAP, PHD_FORMAT_LV2_CLAP)

/** @brief the lv2_worker value that makes mod-host run LV2 plugins */
#define PHD_LV2_WORKER_MOD_HOST  "mod-host"
/** @brief the lv2_worker value that makes omx-clap-host run LV2 plugins through its LV2 adapter */
#define PHD_LV2_WORKER_CLAP_HOST "omx-clap-host"
/** @brief the programs that can run an LV2 plugin, as rows X(id, name, meaning)
 *
 * They are the values of the lv2_worker setting and of lv2_worker_set. The user chooses one; a plugin it refuses is
 * answered with its code and never handed to the other.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_LV2_WORKERS(X) \
    X(MOD_HOST, PHD_LV2_WORKER_MOD_HOST, "the " PHD_FORMAT_LV2 " row: mod_host runs the plugin") \
    X(CLAP_HOST, PHD_LV2_WORKER_CLAP_HOST, "the " PHD_FORMAT_LV2_CLAP " row: clap_host runs the plugin through its LV2 adapter, " \
                                           "a plugin the adapter refuses is refused with a named code, and one it does not " \
                                           "find answers the worker's -101")

/** @brief the states of a worker, as rows X(id, name, meaning), in the order of the daemon's enum
 *
 * @param X the macro each row is passed to.
 */
#define PHD_WORKER_STATES(X) \
    X(UP, "up", "accepting commands") \
    X(STARTING, "starting", "spawned, not yet accepting") \
    X(BACKOFF, "backoff", "dead, waiting to be respawned") \
    X(GIVEN_UP, "given-up", "the storm bound is spent for its placement")

/* ---------------------------------------------------------------- the probe output
 *
 * What plugin-hostd-probe writes about one plugin binary and one offer: facts only, no verdict. The document's schema
 * (protocol/probe-output.schema.json) is generated from the lists below, so a code is declared here once. A code is
 * never reworded: a new one is a minor release of the format, a removed or changed one a major. */

/** @brief the format name of the document plugin-hostd-probe writes */
#define PHD_PROBE_FORMAT "plugin-hostd.probe-output"
/** @brief the major version of the probe output format; a removed or changed code is a major release */
#define PHD_PROBE_FORMAT_MAJOR 1
/** @brief the minor version of the probe output format; a new code is a minor release */
#define PHD_PROBE_FORMAT_MINOR 4
/** @brief the name of the probe protocol the document records */
#define PHD_PROBE_PROTOCOL_NAME "plugin-hostd.probe-protocol"
/** @brief the version of the probe protocol */
#define PHD_PROBE_PROTOCOL_VERSION 1
/* version 1 of the probe protocol runs an LV2 plugin as plugin-qualify's LV2 hosting pass does today
 * (LV2_HOSTING_LIFECYCLES, LV2_HOSTING_REPEATS), so the verdicts from its documents equal today's: this many
 * instantiate/destroy cycles and swept rt-safety runs, at the highest rate asked for */
/** @brief the instantiate/destroy cycles version 1 of the probe protocol runs for an LV2 plugin */
#define PHD_PROBE_LV2_LIFECYCLES 30
/** @brief the swept rt-safety runs version 1 of the probe protocol makes for an LV2 plugin
 *
 * They are made at the highest rate asked for.
 */
#define PHD_PROBE_LV2_REPEATS 3

/** @brief how a step, a grid point or the whole run ended: X(id, code, meaning)
 *
 * @param X the macro each row is passed to.
 */
/* BEGIN GENERATED PHD_PROBE_OUTCOMES: tools/probe-words-gen.py, from contract.d/probe/probe.json */
#define PHD_PROBE_OUTCOMES(X) \
    X(OK, "probe.ok", "the step ran to its end") \
    X(CRASHED, "probe.crashed", "the child died of a signal not caused by a limit") \
    X(TIMEOUT, "probe.timeout", "the supervisor's wall-clock deadline passed") \
    X(CPU_LIMIT, "probe.cpu-limit", "the CPU-time limit was hit") \
    X(MEMORY_LIMIT, "probe.memory-limit", "the memory limit was hit, known from the cgroup's oom_kill count") \
    X(TASKS_LIMIT, "probe.tasks-limit", "the plugin tried to start more tasks than allowed, known from the cgroup's pids.events") \
    X(OUTPUT_LIMIT, "probe.output-limit", "the plugin wrote a file past the size limit") \
    X(SANDBOX_DENIED, "probe.sandbox-denied", "a syscall on the kill list was made") \
    X(REFUSED_INSTANTIATION, "probe.refused-instantiation", "create, init or instantiate returned failure") \
    X(REFUSED_BY_HOST, "probe.refused-by-host", "the host or its LV2 adapter refused the plugin; hostingCode holds its code unchanged") \
    X(NOT_FOUND, "probe.not-found", "no such plugin in the files named") \
    X(UNPINNABLE, "probe.unpinnable", "the files cannot be pinned") \
    X(NON_FINITE_OUTPUT, "probe.non-finite-output", "NaN or infinity came out") \
    X(SILENT_OUTPUT, "probe.silent-output", "silence under a stimulus that should pass") \
    X(CANCELLED, "probe.cancelled", "stopped by the busy signal, a client or shutdown") \
    X(NOT_ATTEMPTED, "probe.not-attempted", "the protocol did not ask for this step, or it does not apply") \
    X(CHILD_PROTOCOL, "probe.child-protocol", "the child wrote a record outside the step grammar") \
    X(ERROR, "probe.error", "anything else; detail keeps the words")
/* END GENERATED PHD_PROBE_OUTCOMES */

/** @brief why a run was made, the document's run.reason: X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
/* BEGIN GENERATED PHD_PROBE_REASONS: tools/probe-words-gen.py, from contract.d/probe/probe.json */
#define PHD_PROBE_REASONS(X) \
    X(ADD, "add", "a user added the plugin") \
    X(RESCAN, "rescan", "the plugin was offered for a rescan") \
    X(BINARY_CHANGED, "binary-changed", "the files the host loads changed") \
    X(ON_REQUEST, "on-request", "a client asked") \
    X(AUTO_MEASURE, "auto-measure", "the machine measures what has no figures when it is idle") \
    X(REFERENCE, "reference", "a reference run on the named rig") \
    X(CI, "ci", "a continuous integration run")
/* END GENERATED PHD_PROBE_REASONS */

/** @brief the limits a set can ask for: X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PROBE_LIMIT_NAMES(X) \
    X(WALL_CLOCK, "wall-clock", "the supervisor's deadline; the whole process tree is killed at it") \
    X(CPU_TIME, "cpu-time", "RLIMIT_CPU") \
    X(MEMORY, "memory", "cgroup memory.max, else RLIMIT_DATA") \
    X(TASKS, "tasks", "cgroup pids.max") \
    X(FILES, "files", "RLIMIT_NOFILE") \
    X(FILE_SIZE, "file-size", "RLIMIT_FSIZE") \
    X(CORE_DUMP, "core-dump", "RLIMIT_CORE 0") \
    X(RT_PRIORITY, "rt-priority", "RLIMIT_RTPRIO: the priority the measurement was granted, 0 without a grant") \
    X(RT_TIME, "rt-time", "RLIMIT_RTTIME: the wall budget, past which the kernel kills a real-time thread that never blocks") \
    X(MEMORY_LOCK, "memory-lock", "RLIMIT_MEMLOCK: what the measured child may lock, the hard limit the runner was started with") \
    X(CPUS, "cpus", "sched_setaffinity") \
    X(NICE, "nice", "the child's nice value") \
    X(NO_NEW_PRIVS, "no-new-privs", "PR_SET_NO_NEW_PRIVS") \
    X(NETWORK, "network", "an unprivileged user and network namespace") \
    X(FILESYSTEM, "filesystem", "Landlock") \
    X(SYSCALLS, "syscalls", "a seccomp kill list")

/** @brief what enforced a limit: X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PROBE_LIMIT_MECHANISMS(X) \
    X(SUPERVISOR, "supervisor", "the runner's own timer and tree kill") \
    X(RLIMIT, "rlimit", "setrlimit") \
    X(CGROUP, "cgroup", "a cgroup v2 controller") \
    X(AFFINITY, "affinity", "sched_setaffinity") \
    X(PRCTL, "prctl", "prctl") \
    X(NETNS, "netns", "a network namespace") \
    X(USERNS, "userns", "a user namespace") \
    X(LANDLOCK, "landlock", "Landlock") \
    X(SECCOMP, "seccomp", "seccomp-bpf")

/** @brief a limit the set asked for and this machine could not apply: X(id, code, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PROBE_LIMIT_CODES(X) \
    X(CGROUP_ABSENT, "probe.limit.cgroup-absent", "no cgroup v2 hierarchy to use") \
    X(CONTROLLER_NOT_DELEGATED, "probe.limit.controller-not-delegated", "the controller is not delegated to this user") \
    X(USERNS_DENIED, "probe.limit.userns-denied", "unprivileged user namespaces are refused") \
    X(LANDLOCK_ABSENT, "probe.limit.landlock-absent", "the kernel offers no Landlock") \
    X(SECCOMP_ABSENT, "probe.limit.seccomp-absent", "the kernel offers no seccomp filter") \
    X(NOT_IMPLEMENTED, "probe.limit.not-implemented", "the runner of this version does not apply the limit")

/** @brief the machine profile read back and not meeting the protocol: X(id, code, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PROBE_PROFILE_CODES(X) \
    X(GOVERNOR, "probe.profile.governor", "the cpu governor is not the one the protocol names") \
    X(DEEP_IDLE_ENTERED, "probe.profile.deep-idle-entered", "a deep idle state was entered during the run") \
    X(TURBO_UNKNOWN, "probe.profile.turbo-unknown", "whether turbo is on could not be read") \
    X(SMT_ON, "probe.profile.smt-on", "SMT siblings are on") \
    X(NOT_PINNED, "probe.profile.not-pinned", "the child was not pinned to cpus")

/** @brief who granted the measurement its real-time scheduling, as rows X(id, name, meaning)
 *
 * It is the document's run.realtime.grantedBy. The class itself (none, fifo) is omx-contract's
 * RESOURCE_THREAD_SCHEDULING.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PROBE_RT_GRANTS(X) \
    X(CAP, "cap", "the runner holds CAP_SYS_NICE: the highest SCHED_FIFO priority") \
    X(RLIMIT, "rlimit", "the RLIMIT_RTPRIO hard limit the runner was started with: the highest priority it allows") \
    X(NONE, "none", "no grant, or the kernel refused it: the measurement ran SCHED_OTHER, and the reason says why")

/** @brief the scheduling policy the kernel reports for the measured child after its exec, as rows X(id, name, meaning)
 *
 * It is the document's run.realtime.observed.policy; id is the SCHED_\<id\> of sched_getscheduler.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PROBE_SCHED_POLICIES(X) \
    X(OTHER, "other", "SCHED_OTHER") \
    X(BATCH, "batch", "SCHED_BATCH") \
    X(IDLE, "idle", "SCHED_IDLE") \
    X(FIFO, "fifo", "SCHED_FIFO") \
    X(RR, "rr", "SCHED_RR") \
    X(DEADLINE, "deadline", "SCHED_DEADLINE")

/** @brief the steps of the protocol, in the order they are run: X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
/* BEGIN GENERATED PHD_PROBE_STEPS: tools/probe-words-gen.py, from contract.d/probe/probe.json */
#define PHD_PROBE_STEPS(X) \
    X(HASH, "hash", "the files the host loads, pinned") \
    X(SCAN, "scan", "the plugin's descriptor read") \
    X(INSTANTIATE, "instantiate", "created and initialised") \
    X(LIFECYCLE, "lifecycle", "created, activated, processed and destroyed") \
    X(LATENCY, "latency", "latency per rate") \
    X(COST, "cost", "cost per rate and quantum") \
    X(RT_SAFETY, "rt-safety", "what process() does under the interposer") \
    X(NOTE_SWEEP, "note-sweep", "a note input played") \
    X(SOAK, "soak", "a long render")
/* END GENERATED PHD_PROBE_STEPS */

/** @brief tells whether a string is a pool name
 *
 * Its characters are in PHD_POOL_NAME_CLASS and its length is from PHD_POOL_NAME_MIN to PHD_POOL_NAME_MAX.
 *
 * @pre name is not NULL.
 * @param[in] name a NUL-terminated string.
 * @return nonzero when name is a pool name, else 0.
 */
static inline int phd_pool_name_valid(const char *name)
{
    int n = 0;

    for (; name[n]; n++)
    {
        const char *c = PHD_POOL_NAME_CLASS;
        int ok = 0;

        for (; *c; c++)
        {
            if (c[1] == '-' && c[2])
            {
                if (name[n] >= c[0] && name[n] <= c[2])
                    ok = 1;
                c += 2;
            }
            else if (name[n] == *c)
                ok = 1;
        }
        if (!ok)
            return 0;
    }
    return n >= PHD_POOL_NAME_MIN && n <= PHD_POOL_NAME_MAX;
}

/* ---------------------------------------------------------------- error codes */

/** @brief the codes the supervisor adds to mod-host's, as rows X(id, resp, meaning)
 *
 * The codes are the -5xx hundred; a reply is "resp \<code\>". resp is the rendered number of the code. Each number has
 * one name in the contract, rendered as OMX_REPLY_\<GROUP\>_\<REASON\>_RESP: the ones omx-clap-host answers too are
 * omx-clap's reply.host.* codes (its HOST_REPLY_CODES, omx_clap_vocabulary.h), the others plugin-hostd's
 * reply.plugin-hostd.* (data/verbs.json PLUGIN_HOSTD_REPLY_CODES, plugin_hostd_vocabulary.h); the header defines none.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_ERRORS(X) \
    X(PLACEMENT_INVALID, OMX_REPLY_PLUGIN_HOSTD_PLACEMENT_INVALID_RESP, "placement invalid: not a placement, or not valid here, as a " PHD_PLACE_POOL_PREFIX \
                         "<name> for a plugin of a format whose pin holds only in a world of the plugin's own, while require_pins is on") \
    X(NO_BACKEND, OMX_REPLY_PLUGIN_HOSTD_NO_BACKEND_RESP, "no worker program for the scheme") \
    X(WORKER_SPAWN, OMX_REPLY_PLUGIN_HOSTD_WORKER_SPAWN_RESP, "the worker is not up: the spawn failed, or it is in backoff; ask again after instance_restored") \
    X(REPLAY, OMX_REPLY_PLUGIN_HOSTD_REPLAY_RESP, "the name of a refused replay, never a reply: a replayed add that its pin or the worker refuses is " \
              "announced by the instance_replay_refused event with the refusal's own code, and written to stderr " \
              "with this one and the step that refused it") \
    X(GAVE_UP, OMX_REPLY_PLUGIN_HOSTD_GAVE_UP_RESP, "the storm bound is spent for that placement") \
    X(NO_SUCH_WORKER, OMX_REPLY_PLUGIN_HOSTD_NO_SUCH_WORKER_RESP, "no such worker") \
    X(VERB_DROPPED, OMX_REPLY_PLUGIN_HOSTD_VERB_DROPPED_RESP, "the worker died on this very command and the daemon dropped it: it is not replayed, " \
                    "and the instance_verb_dropped event names it; or it died on, or did not answer in rpc_timeout_ms, " \
                    "the " OMX_VERB_PIN_EXPECT " of an add, which is then never forwarded") \
    X(PIN_ABSENT, OMX_REPLY_HOST_PIN_ABSENT_RESP, "pin_mode strict and the plugin has no pin, or its layout pin is in a scheme this version does " \
                  "not know: add is refused and no worker sees it") \
    X(PIN_BINARY_MISMATCH, OMX_REPLY_PLUGIN_HOSTD_PIN_BINARY_MISMATCH_RESP, "a pinned file is missing or its SHA-256 differs, or the plugin's manifest names a file the " \
                           "pin does not hold: add is refused and no worker sees it") \
    X(PIN_LAYOUT_MISMATCH, OMX_REPLY_HOST_PIN_LAYOUT_MISMATCH_RESP, "the worker found the parameter layout after init differs from the layout pin: the " \
                           "instance is destroyed before activate") \
    X(NO_PARAM_CONTRACT, OMX_REPLY_HOST_NO_PARAM_CONTRACT_RESP, "the host holds no checked unit and scale for this parameter: fall back to qualification") \
    X(LV2_ADAPTER_REFUSED, OMX_REPLY_PLUGIN_HOSTD_LV2_ADAPTER_REFUSED_RESP, "the " PHD_FORMAT_LV2_CLAP " worker's LV2 adapter cannot run this plugin (MIDI it does not feed, a " \
                           "required feature it lacks, a layout it does not take): the worker answered the add -102, the " \
                           PHD_EVENT_LV2_ADAPTER_REFUSED " event carries the hosting.* code of that reply; the plugin is never handed to " \
                           "another host; a plugin no bundle of the worker's world holds is no refusal: the worker's -101 is answered") \
    X(NO_NOTE_INPUT, OMX_REPLY_HOST_NO_NOTE_INPUT_RESP, "the instance's plugin takes no notes (an effect): its worker answers " OMX_VERB_NOTE_ON ", " \
                     OMX_VERB_NOTE_OFF " and " OMX_VERB_ALL_NOTES_OFF " with this code") \
    X(NOTES_BY_JACK, OMX_REPLY_HOST_NOTES_BY_JACK_RESP, "the instance's worker takes no notes on its socket (mod-host): the daemon answers the note verbs " \
                     "and " OMX_VERB_NOTE_INPUT " with this code, and the plugin is played through its jack MIDI input " \
                     "with connect") \
    X(NO_PRESET_LIST, OMX_REPLY_PLUGIN_HOSTD_NO_PRESET_LIST_RESP, "the instance's worker cannot list the plugin's presets (mod-host): the daemon answers " \
                      OMX_VERB_PRESET_LIST " and " OMX_VERB_PRESET_GET " with this code; preset_load still takes a preset " \
                      "the controller knows") \
    X(PIN_REFUSED, OMX_REPLY_PLUGIN_HOSTD_PIN_REFUSED_RESP, "the plugin's pin carries " PHD_PIN_VERDICT_KEY PHD_PIN_VERDICT_REFUSED ": its files are the ones that " \
                   "failed qualification, so add is refused and no worker sees it, and a replayed add is refused the " \
                   "same way; files that differ from the pin answer " PHD_STR(OMX_REPLY_PLUGIN_HOSTD_PIN_BINARY_MISMATCH_RESP) " first. A pins_dir " \
                   "pin of that verdict is not overridden by the host's pins: " OMX_VERB_PIN_SET " of its plugin answers this " \
                   "code. Only the user's " OMX_VERB_PIN_ACCEPT " under pin_mode " PHD_PIN_MODE_FIRST_USE " loads it, alone") \
    X(NOTE_QUEUE_FULL, OMX_REPLY_HOST_NOTE_QUEUE_FULL_RESP, "the instance's worker has no room for this " OMX_VERB_NOTE_ON ", " OMX_VERB_NOTE_OFF " or " \
                       OMX_VERB_ALL_NOTES_OFF " before its next block: the line was not taken and nothing of it is kept; the " \
                       "controller may send it again") \
    X(CHAIN_UNKNOWN_INSTANCE, OMX_REPLY_PLUGIN_HOSTD_CHAIN_UNKNOWN_INSTANCE_RESP, "a member of " OMX_VERB_CHAIN " is an instance no add made: the chain is not declared") \
    X(CHAIN_DUPLICATE, OMX_REPLY_PLUGIN_HOSTD_CHAIN_DUPLICATE_RESP, "an instance is named twice in one " OMX_VERB_CHAIN ": the chain is not declared") \
    X(CHAIN_INSTANCE_BUSY, OMX_REPLY_PLUGIN_HOSTD_CHAIN_INSTANCE_BUSY_RESP, "a member of " OMX_VERB_CHAIN " is already in another chain: the chain is not declared; " \
                           OMX_VERB_CHAIN_CLEAR " of the other chain frees it") \
    X(CHAIN_MIXED_FORMAT, OMX_REPLY_PLUGIN_HOSTD_CHAIN_MIXED_FORMAT_RESP, "the members of " OMX_VERB_CHAIN " are not all run by one worker program, or are of two " \
                          "rows of one program and a row does not run chains in one client, so no one worker runs " \
                          "them: the chain is not declared") \
    X(NO_SUCH_CHAIN, OMX_REPLY_PLUGIN_HOSTD_NO_SUCH_CHAIN_RESP, OMX_VERB_CHAIN_CLEAR " or " OMX_VERB_CHAIN_GET " of a chain no " OMX_VERB_CHAIN " declared") \
    X(PRESET_NOT_OFFERED, OMX_REPLY_PLUGIN_HOSTD_PRESET_NOT_OFFERED_RESP, "the worker: preset_load or preset_show of a stable name the plugin does not offer, or of a " \
                          "plugin with no preset system and no state") \
    X(PRESET_INVALID, OMX_REPLY_PLUGIN_HOSTD_PRESET_INVALID_RESP, "preset_save with a file path that is not absolute or with no name, or preset_load or " \
                      OMX_VERB_PRESET_SHOW " of a file that cannot be read, is no JSON, is of a format version other than " \
                      PHD_PRESET_FORMAT_1 " and " PHD_PRESET_FORMAT_2 ", or breaks the format (docs/presets.md): the " \
                      "daemon answers it and no worker sees the file") \
    X(PRESET_NEEDS_STATE, OMX_REPLY_PLUGIN_HOSTD_PRESET_NEEDS_STATE_RESP, "the worker: a preset file that carries state for a worker that cannot take state yet") \
    X(PRESET_PLUGIN_CHANGED, OMX_REPLY_PLUGIN_HOSTD_PRESET_PLUGIN_CHANGED_RESP, "the worker: the preset file's plugin id, version or fingerprint is not the instance's; " \
                             "nothing of it is applied") \
    X(LOAD_REFUSED, OMX_REPLY_PLUGIN_HOSTD_LOAD_REFUSED_RESP, "the worker: the plugin refused the preset or the state its file carries") \
    X(PRESET_NOT_APPLIED, OMX_REPLY_PLUGIN_HOSTD_PRESET_NOT_APPLIED_RESP, "the worker: the plugin took the preset and had not run once since when the host's wait for that ran out") \
    X(DIR_NOT_WRITABLE, OMX_REPLY_PLUGIN_HOSTD_DIR_NOT_WRITABLE_RESP, "descriptor_dir cannot be made or written: the daemon does not start, and " \
                        "says which key and which path on stderr with this code; a directory that turns read-only " \
                        "later makes the scan of an add write nothing, and " OMX_VERB_DESCRIPTOR_GET " and " \
                        OMX_VERB_PANEL_GET " of that plugin answer this code") \
    X(DESCRIPTOR_ABSENT, OMX_REPLY_PLUGIN_HOSTD_DESCRIPTOR_ABSENT_RESP, OMX_VERB_DESCRIPTOR_GET " (" OMX_VERB_PANEL_GET ") of a plugin that has no descriptor (panel) " \
                         "in descriptor_dir for its binary as it is now, and none being written: no add since it " \
                         "changed, or a binary that cannot be found") \
    X(DESCRIPTOR_PENDING, OMX_REPLY_PLUGIN_HOSTD_DESCRIPTOR_PENDING_RESP, OMX_VERB_DESCRIPTOR_GET " (" OMX_VERB_PANEL_GET ") of a plugin whose scan, started by its " \
                          "add, has not written its descriptor (panel) yet: ask again") \
    X(DESCRIPTOR_SCAN_FAILED, OMX_REPLY_PLUGIN_HOSTD_DESCRIPTOR_SCAN_FAILED_RESP, OMX_VERB_DESCRIPTOR_GET " (" OMX_VERB_PANEL_GET ") of a plugin whose last scan wrote no " \
                              "descriptor (panel): the scanner refused the plugin, made no dump or no panel, or is not " \
                              "installed; the add it ran for stands, and stderr and the scan's log say why. The next add " \
                              "scans again") \
    X(NO_SUCH_PLAN, OMX_REPLY_PLUGIN_HOSTD_NO_SUCH_PLAN_RESP, OMX_VERB_PLAN_GET " or " OMX_VERB_PLAN_CLEAR " of a chain no " OMX_VERB_PLAN " planned") \
    X(NO_RECORD, OMX_REPLY_PLUGIN_HOSTD_NO_RECORD_RESP, "a member of " OMX_VERB_ESTIMATE " that no qualification record " \
                 "names: never a reply, the code of the member in the reply's list") \
    X(NO_CELL, OMX_REPLY_PLUGIN_HOSTD_NO_CELL_RESP, "a member of " OMX_VERB_ESTIMATE " whose qualification records hold no " \
               "point of the grid at that rate and quantum with a cost and a latency: never a reply, the code of the " \
               "member in the reply's list") \
    X(UNKNOWN_PLUGIN, OMX_REPLY_PLUGIN_HOSTD_UNKNOWN_PLUGIN_RESP, "a member of " OMX_VERB_ESTIMATE " whose uri names no " \
                      "plugin installed here (its format cannot tell the plugin's binary, or the binary is not there): " \
                      "never a reply, the code of the member in the reply's list") \
    X(CURVE_KIND_UNKNOWN, OMX_REPLY_PLUGIN_HOSTD_CURVE_KIND_UNKNOWN_RESP, OMX_VERB_CURVE_BIND " of a family with no closed " \
                          "form for the display's kind, or " OMX_VERB_CURVE_POINTS " of a binding whose values pick a band " \
                          "shape or a head filter slope with no closed form: no curve is drawn") \
    X(CURVE_TERM_MISSING, OMX_REPLY_PLUGIN_HOSTD_CURVE_TERM_MISSING_RESP, OMX_VERB_CURVE_POINTS " of a display with no " \
                          "binding, or of a binding that lacks a term the model needs (a band's frequency, shape or Q, " \
                          "a threshold, a ratio, a gate's range): no curve is drawn from a guess") \
    X(CURVE_UNIT_REFUSED, OMX_REPLY_PLUGIN_HOSTD_CURVE_UNIT_REFUSED_RESP, OMX_VERB_CURVE_BIND " of a term in a unit its role " \
                          "does not take: nothing of the line is kept") \
    X(CURVE_POINTS_RANGE, OMX_REPLY_PLUGIN_HOSTD_CURVE_POINTS_RANGE_RESP, OMX_VERB_CURVE_POINTS " of fewer than 2 points or " \
                          "more than a curve carries, three anchors a drawn band counted, or of a band index past what fits") \
    X(DURABLE_WRITE_FAILED, OMX_REPLY_PLUGIN_HOSTD_DURABLE_WRITE_FAILED_RESP, "the daemon's writer thread could not " \
                            "write the file the verb changes (" OMX_VERB_HISTORY_CLEAR ", " OMX_VERB_PIN_CLEAR ", " \
                            OMX_VERB_PIN_ACCEPT "): the change is not on disk, and stderr names the path and the error") \
    X(WRITER_QUEUE_FULL, OMX_REPLY_PLUGIN_HOSTD_WRITER_QUEUE_FULL_RESP, "the daemon's writer queue holds its most writes " \
                         "or bytes: the write the verb needs is refused and nothing of the verb changed; the controller " \
                         "may send it again") \
    X(CURVE_VALUE_NOT_FINITE, OMX_REPLY_PLUGIN_HOSTD_CURVE_VALUE_NOT_FINITE_RESP, OMX_VERB_CURVE_POINTS " of a binding " \
                              "whose value, as the instance holds it, is not finite, or of an instance that runs at no " \
                              "rate: no curve is drawn") \
    X(OUTPUT_NOT_MONITORED, OMX_REPLY_PLUGIN_HOSTD_OUTPUT_NOT_MONITORED_RESP, "monitor_output_off of an output this " \
                           "connection did not monitor: a monitor ends with the connection that set it, and only " \
                           "that connection ends it earlier") \
    X(LABEL_INVALID, OMX_REPLY_PLUGIN_HOSTD_LABEL_INVALID_RESP, OMX_VERB_NODE_LABEL " of a label longer than " \
                     "PHD_NODE_LABEL_MAX bytes or not UTF-8: the node keeps the label it had")

/* ---------------------------------------------------------------- verbs */

/** @brief the word of mod-host's add verb, which the daemon extends with a placement
 *
 * Every verb of its own is OMX_VERB_\<VERB\> of plugin_hostd_host_verbs.h, and pin_expect is omx-clap's,
 * OMX_VERB_PIN_EXPECT.
 */
#define PHD_VERB_ADD              "add"

/** @brief the prefix of a CLAP plugin's uri: clap:\<path\>#\<id\> */
#define PHD_CLAP_URI_PREFIX "clap:"
/** @brief reads the uri of an add, words[1] on, whole
 *
 * A clap: uri is clap:\<path\>#\<id\>, its path percent-encoded or in quotation marks when it holds a space; written
 * bare, the line's words split it. So a clap: word with no '#' goes on over the words after it up to the one that holds
 * the '#', joined with one space each (a run of spaces is not told from one: such a path is written encoded or quoted).
 * A clap: word whose '#' no later word holds, or that does not fit, is its one word.
 *
 * joined is scratch: it may be written even when words[1] is returned, and holds the uri only when joined is returned.
 *
 * @pre words holds at least count words, count being 2 or more for a uri to be read.
 * @pre joined and next are not NULL.
 * @param[in] words the words of the line, the verb first.
 * @param count how many words there are.
 * @param[out] joined the buffer a uri joined from several words is written to, NUL-terminated.
 * @param size the size of joined in bytes.
 * @param[out] next always written: set to 2, or to the index of the word after the last one joined.
 * @return NULL when count is less than 2; joined when the uri was joined from several words; otherwise words[1].
 */
static inline const char *phd_add_uri(char *const *words, unsigned count, char *joined, size_t size, unsigned *next)
{
    unsigned i;
    size_t used = 0;

    *next = 2;
    if (count < 2 || strncmp(words[1], PHD_CLAP_URI_PREFIX, strlen(PHD_CLAP_URI_PREFIX)) || strchr(words[1], '#'))
        return count < 2 ? NULL : words[1];
    for (i = 1; i < count; i++)
    {
        size_t n = strlen(words[i]) + (i > 1);

        if (used + n + 1 > size)
            return words[1];
        if (i > 1)
            joined[used++] = ' ';
        memcpy(joined + used, words[i], n - (i > 1));
        used += n - (i > 1);
        joined[used] = '\0';
        if (strchr(words[i], '#'))
        {
            *next = i + 1;
            return joined;
        }
    }
    return words[1];
}

/** @brief separates the \<path\>=\<sha256\> words of the files of a pin */
#define PHD_PIN_FILE_SEPARATOR   ","
/** @brief separates a file's path from its SHA-256 in a pin */
#define PHD_PIN_DIGEST_SEPARATOR "="
/** @brief separates the scheme from its SHA-256 in the layout word of a pin: \<scheme\>:\<sha256\> */
#define PHD_PIN_SCHEME_SEPARATOR ":"
/** @brief what a path of a pin cannot hold as it is: the separators of pin_set's words, and whitespace */
#define PHD_PIN_PATH_EXCLUDED    PHD_PIN_FILE_SEPARATOR PHD_PIN_DIGEST_SEPARATOR " \t\r\n"
/** @brief the escape character of a percent-encoded path of a pin
 *
 * A path of a pin, and the path of a clap: uri, is written percent-encoded: every byte of PHD_PIN_PATH_EXCLUDED, the
 * escape itself, a double quote, a backslash and every control byte is PHD_PIN_PATH_ESCAPE and two uppercase hex
 * digits, every other byte as it is.
 *
 * So any file name is one bare word ("Surge XT.clap" is "Surge%20XT.clap"), and a reader decodes it before it opens or
 * hashes the file. The escape is always one: a name holding '%' itself writes it %25. A pin is keyed by its clap: uri's
 * path decoded, so the uri written with the space as it is (quoted) and written encoded name one pin (doc/protocol.md,
 * Pins and qualification).
 */
#define PHD_PIN_PATH_ESCAPE      "%"

/** @brief tells whether a byte of a path is written escaped
 *
 * @param c the byte of a path.
 * @return nonzero when c is written escaped: a control byte, 0x7f, the escape, a double quote, a backslash or a byte of
 *     PHD_PIN_PATH_EXCLUDED; else 0.
 */
static inline int phd_pin_path_escaped(unsigned char c)
{
    return c < 0x20 || c == 0x7f || c == PHD_PIN_PATH_ESCAPE[0] || c == '"' || c == '\\' ||
           (c && strchr(PHD_PIN_PATH_EXCLUDED, c) != NULL);
}

/** @brief writes a path as the word of a pin
 *
 * @pre path and out are not NULL.
 * @param[in] path the NUL-terminated path.
 * @param[out] out the buffer the encoded word is written to, NUL-terminated.
 * @param size the size of out in bytes.
 * @return 0, or -1 when out cannot hold the word and its NUL; out is then partly written and not NUL-terminated.
 */
static inline int phd_pin_path_encode(const char *path, char *out, size_t size)
{
    static const char hex[] = "0123456789ABCDEF";
    size_t o = 0;

    for (; *path; path++)
    {
        unsigned char c = (unsigned char)*path;

        if (phd_pin_path_escaped(c))
        {
            if (o + 4 > size)
                return -1;
            out[o++] = PHD_PIN_PATH_ESCAPE[0];
            out[o++] = hex[c >> 4];
            out[o++] = hex[c & 15];
        }
        else
        {
            if (o + 2 > size)
                return -1;
            out[o++] = (char)c;
        }
    }
    if (o + 1 > size)
        return -1;
    out[o] = '\0';
    return 0;
}

/** @brief gives the value of a hex digit
 *
 * @param c a character.
 * @return the value, 0 to 15, of the hex digit c in either case, or -1 for any other character.
 */
static inline int phd_hex_value(char c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    return -1;
}

/** @brief reads the path a word of a pin names
 *
 * Hex digits are read in either case; a byte written as it is stays as it is.
 *
 * @pre word and out are not NULL.
 * @pre size is 1 or more: with an empty word and a size of 0, out[0] is written and 0 is returned
 *     (plugin-hostd-protocol#72).
 * @param[in] word the NUL-terminated pin word.
 * @param[out] out the buffer the path is written to, NUL-terminated.
 * @param size the size of out in bytes.
 * @return 0, or -1 when word holds an escape not followed by two hex digits or an escaped NUL, or when out cannot hold
 *     the path and its NUL; out is then partly written and not NUL-terminated.
 */
static inline int phd_pin_path_decode(const char *word, char *out, size_t size)
{
    size_t o = 0;

    if (size == 0)
        return -1;
    for (; *word; word++)
    {
        if (o + 2 > size)
            return -1;
        if (*word == PHD_PIN_PATH_ESCAPE[0])
        {
            int hi = phd_hex_value(word[1]), lo = hi < 0 ? -1 : phd_hex_value(word[2]);

            if (lo < 0 || (hi | lo) == 0)
                return -1;
            out[o++] = (char)(hi * 16 + lo);
            word += 2;
        }
        else
            out[o++] = *word;
    }
    out[o] = '\0';
    return 0;
}
/** @brief the layout word of a pin whose layout has not been learned yet
 *
 * A pin of the store, of a pins file or learned by the daemon may hold it, pin_set may not.
 */
#define PHD_PIN_LAYOUT_UNKNOWN   "-"
/** @brief the optional last word of a pin line: the qualification verdict of the pinned bytes.
 *
 * The key is plugin-db's (its domain plugin-db, rendered beside this header); the verdict words are the domain pin's
 */
#define PHD_PIN_VERDICT_KEY      OMX_PLUGIN_DB_PIN_KEYS_VERDICT "="

/* The verdict words of a pin and what each means. Only in-process lets a plugin share a worker under pin_mode first-use.
 * The words are the domain pin's (contract.d/pin), the wire words of pin_set. */
/* BEGIN GENERATED PHD_PIN_VERDICTS: tools/pin-words-gen.py, from contract.d/pin/pin.json */
#define PHD_PIN_VERDICT_IN_PROCESS "in-process" ///< qualified to run in a worker that other plugins share
#define PHD_PIN_VERDICT_ISOLATED "isolated" ///< qualified to run, in a worker of its own
#define PHD_PIN_VERDICT_REFUSED "refused" ///< failed qualification: the pin records the bytes, a host should not load them
/** @brief the rows of the list: X(id, word, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PIN_VERDICTS(X) \
    X(IN_PROCESS, PHD_PIN_VERDICT_IN_PROCESS, "qualified to run in a worker that other plugins share") \
    X(ISOLATED, PHD_PIN_VERDICT_ISOLATED, "qualified to run, in a worker of its own") \
    X(REFUSED, PHD_PIN_VERDICT_REFUSED, "failed qualification: the pin records the bytes, a host should not load them")
/* END GENERATED PHD_PIN_VERDICTS */

/** @brief the key of the optional pool word of a pin line, after the verdict
 *
 * The word tells whether the plugin's qualification measured the CLAP thread pool (docs/thread-pool.md of
 * omx-clap) real-time safe and faster at the quantum; a plugin with no word runs serial.
 */
#define PHD_PIN_POOL_KEY   OMX_PLUGIN_DB_PIN_KEYS_POOL "="
/* The pool words of a pin and what each means; cores: no other plugin shares the worker. The words are the domain pin's
 * (contract.d/pin). */
/* BEGIN GENERATED PHD_PIN_POOLS: tools/pin-words-gen.py, from contract.d/pin/pin.json */
#define PHD_PIN_POOL_CORES "cores" ///< its worker starts with the thread pool on, one helper per core of its cpu set but one, and no other plugin shares the worker
#define PHD_PIN_POOL_OFF "off" ///< measured, and not faster or not safe with the pool: the worker keeps no option
/** @brief the rows of the list: X(id, word, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PIN_POOLS(X) \
    X(CORES, PHD_PIN_POOL_CORES, "its worker starts with the thread pool on, one helper per core of its cpu set but one, and no other plugin shares the worker") \
    X(OFF, PHD_PIN_POOL_OFF, "measured, and not faster or not safe with the pool: the worker keeps no option")
/* END GENERATED PHD_PIN_POOLS */

/** @brief what pin_changed names when the plugin's files changed */
#define PHD_PIN_CHANGED_FILES  OMX_PLUGIN_DB_PIN_CHANGES_FILES
/** @brief what pin_changed names when the plugin's layout changed */
#define PHD_PIN_CHANGED_LAYOUT OMX_PLUGIN_DB_PIN_CHANGES_LAYOUT

/** @brief the pin_mode in which add admits only a plugin that has a pin */
#define PHD_PIN_MODE_STRICT    "strict"
/** @brief the pin_mode in which add of a plugin with no pin records its pin */
#define PHD_PIN_MODE_FIRST_USE "first-use"
/** @brief the pin modes as rows X(id, name, meaning), read while require_pins is 1
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PIN_MODES(X) \
    X(STRICT, PHD_PIN_MODE_STRICT, "add admits only a plugin that has a pin; a pin comes from pin_set, pin_file or pins_dir") \
    X(FIRST_USE, PHD_PIN_MODE_FIRST_USE, "add of a plugin with no pin records its pin, keeps it in the pin store and places " \
                              "the instance " PHD_PLACE_OWN "; a later change is refused until pin_accept")

/** @brief the grouping setting that makes plan answer the plan it would make and apply none */
#define PHD_GROUPING_OFF "off"
/** @brief the grouping setting that makes plan apply its plan */
#define PHD_GROUPING_ON  "on"
/** @brief the grouping modes as rows X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_GROUPING_MODES(X) \
    X(OFF, PHD_GROUPING_OFF, OMX_VERB_PLAN " answers the plan it would make and applies none") \
    X(ON, PHD_GROUPING_ON, OMX_VERB_PLAN " applies its plan")

/** @brief the placement setting that pins each new worker to the audio core that has the least load */
#define PHD_CORE_PLACEMENT_SPREAD "spread"
/** @brief the placement setting that pins nothing: the workers run where the daemon may */
#define PHD_CORE_PLACEMENT_NONE   "none"
/** @brief the core placements (docs/placement.md) as rows X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_CORE_PLACEMENTS(X) \
    X(SPREAD, PHD_CORE_PLACEMENT_SPREAD, "each new worker is pinned to the audio core that has the least load, and the " \
      "daemon, its threads and the helpers it forks to the reserved cores") \
    X(NONE, PHD_CORE_PLACEMENT_NONE, "nothing is pinned: the workers run where the daemon may")

/** @brief what cannot be pinned, each a refusal and never a partial pin: X(id, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PIN_LIMITS(X) \
    X(PATH, "a path is pinned percent-encoded (" PHD_PIN_PATH_ESCAPE "XX): '" PHD_PIN_FILE_SEPARATOR "', '" \
            PHD_PIN_DIGEST_SEPARATOR "', whitespace, '" PHD_PIN_PATH_ESCAPE "', a quote, a backslash and a control byte " \
            "are escaped, so any file name is one word; a path holding one of them as it is, or a stray " \
            PHD_PIN_PATH_ESCAPE ", is refused by " OMX_VERB_PIN_SET " as a token outside its grammar") \
    X(LINE, "a " OMX_VERB_PIN_SET " line is at most line_max, " PHD_STR(PHD_LINE_MAX) " bytes, the protocol socket's " \
            "buffer; a longer one is refused as outside the grammar") \
    X(MANIFEST, "a manifest that uses @base makes add answer " \
                "OMX_REPLY_PLUGIN_HOSTD_PIN_BINARY_MISMATCH_RESP " PHD_STR(OMX_REPLY_PLUGIN_HOSTD_PIN_BINARY_MISMATCH_RESP) ": the daemon does not resolve " \
                "it, so it cannot know the file the host would load. A file the manifest names by a percent-encoded IRI is " \
                "pinned as written, one word, and opened decoded; a name with a stray % is refused the same way")

/** @brief the verbs the daemon adds to mod-host's, or extends: X(id, name, arguments, reply, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_VERBS(X) \
    X(ADD, PHD_VERB_ADD, "<uri> <instance> [" PHD_PLACEMENT_SYNTAX "] [client_name]", "resp <instance>", \
      "mod-host's add with a placement; a token after the instance that is not a placement is the jack client name") \
    X(WORKER_LIST, OMX_VERB_WORKER_LIST, "", OMX_VERB_WORKER_LIST_REPLY, "the workers, one record each") \
    X(INSTANCE_INFO, OMX_VERB_INSTANCE_INFO, "<instance>", OMX_VERB_INSTANCE_INFO_REPLY, \
      "where an instance lives and what it has cost") \
    X(SUPERVISOR_RESET, OMX_VERB_SUPERVISOR_RESET, "[<worker> | " PHD_WORD_ALL "]", OMX_VERB_SUPERVISOR_RESET_REPLY, \
      "re-arm the storm bound and the backoff of a given-up placement") \
    X(QUARANTINE_CLEAR, OMX_VERB_QUARANTINE_CLEAR, "<instance> | " PHD_WORD_ALL, OMX_VERB_QUARANTINE_CLEAR_REPLY, \
      "let a quarantined instance go back where its placement says") \
    X(POLICY_SET, OMX_VERB_POLICY_SET, PHD_FORMAT_ARGUMENT " " \
      PHD_PLACE_OWN " | " PHD_PLACE_POOL_PREFIX "<name>", OMX_VERB_POLICY_SET_REPLY, "the placement of an add that says default") \
    X(POOL_CONFIG, OMX_VERB_POOL_CONFIG, "<name> <max_instances>", OMX_VERB_POOL_CONFIG_REPLY, \
      "the instances a pool holds before a sibling opens") \
    X(WORKER_ENV, OMX_VERB_WORKER_ENV, PHD_FORMAT_ARGUMENT " <cpu-list|" \
      PHD_WORD_NONE "> <nice|" PHD_WORD_NONE ">", OMX_VERB_WORKER_ENV_REPLY, \
      "the cpu list and the nice value of the workers of a format, at spawn and on the ones running") \
    X(PIN_SET, OMX_VERB_PIN_SET, "<uri> <path>" PHD_PIN_DIGEST_SEPARATOR "<sha256>[" PHD_PIN_FILE_SEPARATOR "<path>" \
      PHD_PIN_DIGEST_SEPARATOR "<sha256>...] <scheme>" PHD_PIN_SCHEME_SEPARATOR "<sha256> [" PHD_PIN_VERDICT_KEY \
      "<verdict>] [" PHD_PIN_POOL_KEY "<pool>]", OMX_VERB_PIN_SET_REPLY, \
      "the pin of one plugin: the SHA-256 of every file the host loads for it, a path relative to the bundle (the " \
      "directory of a single-file format's file), its layout fingerprint and, when they are known, the verdict of its qualification and whether its worker gets the " \
      "CLAP thread pool; " \
      "it replaces an earlier pin of the uri; -516 for a plugin whose pins_dir pin carries " PHD_PIN_VERDICT_KEY \
      PHD_PIN_VERDICT_REFUSED ", which only the user's " OMX_VERB_PIN_ACCEPT " overrides. The pin store, a pin_file and a pins_dir file hold the same " \
      "line, with or without the verb") \
    X(PIN_CLEAR, OMX_VERB_PIN_CLEAR, "<uri> | " PHD_WORD_ALL, OMX_VERB_PIN_CLEAR_REPLY, "forget the pin of one plugin, or of every one; a pins_dir " \
      "pin is read-only and holds again") \
    X(PIN_RELOAD, OMX_VERB_PIN_RELOAD, "", OMX_VERB_PIN_RELOAD_REPLY, \
      "read the pin_file and the pins_dir files again and put the pins in at once, without a restart; the daemon also does " \
      "this by itself when one of those files changes. Running instances keep running: one the new pins refuse is logged " \
      "and its id in " OMX_VERB_WORKER_LIST " is followed by " PHD_WORKER_PIN_REFUSED ". The pin_set pins of the controller " \
      "are kept. -902 under pin_mode off or when the pin_file is gone or has a line outside the grammar, and the earlier " \
      "pins hold") \
    X(PIN_CHANGED, OMX_VERB_PIN_CHANGED, "[<uri>] [files | layout]", OMX_VERB_PIN_CHANGED_REPLY, \
      "the notice the package sync sends to every daemon it knows after it rewrote the pin file: the same as " \
      OMX_VERB_PIN_RELOAD ", with or without the " PHD_EVENT_PIN_CHANGED " event's words after it; more words than those are -902") \
    X(LV2_WORKER_SET, OMX_VERB_LV2_WORKER_SET, "<uri> <" PHD_LV2_WORKER_MOD_HOST " | " PHD_LV2_WORKER_CLAP_HOST " | " \
      PHD_WORD_NONE ">", OMX_VERB_LV2_WORKER_SET_REPLY, \
      "the worker of one LV2 plugin, for its adds from now on: it overrides the lv2_worker setting, " PHD_WORD_NONE " takes the " \
      "override back; -902 for a word that is none of these. Like policy_set it is the controller's, not in the ledger, gone with the daemon") \
    X(PIN_ACCEPT, OMX_VERB_PIN_ACCEPT, "<uri>", OMX_VERB_PIN_ACCEPT_REPLY, \
      "pin_mode " PHD_PIN_MODE_FIRST_USE " only: take the plugin's files as they are now as its pin, after a " \
      PHD_EVENT_PIN_CHANGED " event; the layout is learned again by the next add and the verdict is dropped. Of a plugin " \
      "whose pin carries " PHD_PIN_VERDICT_KEY PHD_PIN_VERDICT_REFUSED " (pins_dir or pin_file) it is the user's choice to " \
      "load it anyway: kept beside the pin store, it runs alone in a worker of its own, " OMX_VERB_PIN_CLEAR " takes the " \
      "choice back; -508 when the plugin has no pin, -509 when its files cannot be collected, -902 under pin_mode strict") \
    X(PIN_LAYOUT, OMX_VERB_PIN_LAYOUT, "<instance>", OMX_VERB_PIN_LAYOUT_REPLY, \
      "sent by the daemon to a worker of a format that checks layouts, after it accepted the add of a plugin whose layout pin is " \
      "still unknown: the layout the worker found after init, which the daemon records in the pin") \
    X(PIN_EXPECT, OMX_VERB_PIN_EXPECT, "<instance> <scheme>" PHD_PIN_SCHEME_SEPARATOR "<sha256>", "resp 0", \
      "sent by the daemon to a worker of a format that checks layouts, just before the instance's add: the layout pin that add " \
      "checks after init and before activate; any other reply than resp 0 refuses the add with that code, and the " \
      "add is never forwarded") \
    X(CHAIN, OMX_VERB_CHAIN, "<chain> <instance> [<instance> ...]", OMX_VERB_CHAIN_REPLY, \
      "the instances, in this order, are one chain, run in one worker of place " PHD_PLACE_CHAIN_PREFIX "<chain>: each " \
      "member's state is saved, it is removed from the worker it was in and replayed in the chain's. A chain already " \
      "declared takes the new order, and a member left out of it goes back to a worker of its own; while its worker " \
      "is up that worker is kept: a new member joins it (its add, the order, its state, its ledger, its connections) " \
      "and no other member is restarted, unless the new member's format narrows the worker's world, which forms " \
      "the chain again. Members of " PHD_FORMAT_CLAP " and " PHD_FORMAT_LV2_CLAP " form one chain. A worker that runs " \
      "chains in one client (" PHD_FORMAT_CLAP ", " PHD_FORMAT_LV2_CLAP ") is sent this line, with the members it holds, " \
      "after the adds of its replay; one that does not (mod-host) never is. A worker that refuses the line would not " \
      "run the members as one: the chain is forgotten and each member runs in a worker of its own, the line answers " \
      "-501, and the event " PHD_EVENT_CHAIN_REFUSED " carries the worker's own code, also when the refusal comes later, on a " \
      "respawn. Every instance verb still names one member by its own number. A member that crashes the " \
      "worker is quarantined to a worker of its own and the chain goes on without it; quarantine_clear puts it back. " \
      "-518 for an instance no add made, -519 for one named twice, -520 for one in another chain, -521 for members no " \
      "one worker program runs together, -501 for a plugin that may not share a worker while require_pins is on (a CLAP plugin " \
      "whose first-use pin is not in-process; an LV2 member whose bundle is not found, since a chain's worker sees " \
      "a world narrowed to the union of its members' bundles), -902 for a chain " \
      "or an instance that is not a number, or fewer than chain_members_min (" PHD_STR(PHD_CHAIN_MEMBERS_MIN) ") instances") \
    X(CHAIN_CLEAR, OMX_VERB_CHAIN_CLEAR, "<chain>", OMX_VERB_CHAIN_CLEAR_REPLY, \
      "forget the chain: each member goes to a worker of its own; -522 for a chain no " OMX_VERB_CHAIN " declared") \
    X(CHAIN_GET, OMX_VERB_CHAIN_GET, "<chain>", OMX_VERB_CHAIN_GET_REPLY, \
      "read a chain back: its worker (" PHD_WORD_NONE " when it has none), its members in the declared order, and the " \
      "members its worker runs now in their order (" PHD_WORD_NONE " for none); a quarantined member is declared and " \
      "not running; -522 for a chain no " OMX_VERB_CHAIN " declared, -902 for a chain that is not a number") \
    X(PLAN, OMX_VERB_PLAN, "<chain> <instance> [<instance> ...]", OMX_VERB_PLAN_REPLY, \
      "the instances, in signal order, are planned (the grouping-planner design note): the daemon decides, from the " \
      "pin and the cost of each, which runs of consecutive members share a worker. A run of two or more is declared " \
      "as a chain of place " PHD_PLACE_CHAIN_PREFIX "<chain>" PHD_PLACE_PLAN_SEPARATOR "<k>, k counting segments from 0; " \
      "a member that shares with no neighbour is placed " PHD_PLACE_OWN ". The reply names the segments in order, " \
      "the members of one joined by commas and the segments by semicolons, then the cores: the segments again with " \
      "each member replaced by the audio core of the worker that runs it now, " PHD_WORD_NONE " for one the setting " \
      "placement did not pin (docs/placement.md). A chain planned again keeps the running " \
      "worker of every segment that did not change, and the daemon plans it again by itself when a member is " \
      "quarantined and, history_regroup_s after a death that split its group, to gather it. The plan numbers are its " \
      "own, apart from chain's. While the setting grouping is off the plan is answered and kept for " OMX_VERB_PLAN_GET " and nothing moves. A segment " \
      "that cannot be formed refuses the whole plan with its own code, moves nothing and is told by " OMX_VERB_PLAN_GET \
      " as plan-refused:<code>. A segment its worker refuses, which is known only once it has moved, refuses the plan " \
      "with -501 too, and then every segment ends and each member runs in a worker of its own. -518 for an instance no add " \
      "made, -519 for one named twice, -520 for one in a chain " \
      "or in the plan of another chain, -501 for a segment no world can be built for or its worker refuses, -902 for a chain or an " \
      "instance that is not a number, or fewer than chain_members_min (" PHD_STR(PHD_CHAIN_MEMBERS_MIN) ") instances") \
    X(PLAN_GET, OMX_VERB_PLAN_GET, "<chain>", OMX_VERB_PLAN_GET_REPLY, \
      "read the last plan of a chain back: its segments as " OMX_VERB_PLAN " answered them, then the members that have " \
      "a reason, instance:reason joined by commas (" PHD_WORD_NONE " for none); the reasons are the words of " \
      "PLUGIN_HOSTD_GROUPING_REASONS (domain plugin-hostd/grouping), then the cores of the members as " OMX_VERB_PLAN " answers " \
      "them; -532 for a chain no " OMX_VERB_PLAN " planned, -902 for a chain that is not a number") \
    X(PLAN_CLEAR, OMX_VERB_PLAN_CLEAR, "<chain>", OMX_VERB_PLAN_CLEAR_REPLY, \
      "forget the plan: each member goes to a worker of its own; -532 for a chain no " OMX_VERB_PLAN " planned") \
    X(DESCRIPTOR_GET, OMX_VERB_DESCRIPTOR_GET, "<uri>", OMX_VERB_DESCRIPTOR_GET_REPLY, \
      "the scanned descriptor of the plugin, answered from descriptor_dir: the file named for its binary as it is now " \
      "(" PHD_DESCRIPTOR_NAME_SYNTAX "), written by the scan the plugin's add ran. -529 when there is none, -530 while " \
      "its scan runs, -531 when its last scan wrote nothing, -528 when the directory could not be written") \
    X(PANEL_GET, OMX_VERB_PANEL_GET, "<uri>", OMX_VERB_PANEL_GET_REPLY, \
      "the panel the plugin publishes (org.openmixer.panel-description/1), answered from descriptor_dir: the file " \
      PHD_PANEL_NAME_SYNTAX ", named as its descriptor, which the same scan writes once the descriptor is in place, " \
      "{\"plugin\": {\"format\", \"id\"}, \"panel\": <the panel object omx-clap-scan --json prints for the plugin, " \
      "null when it serves none>, \"meters\": [<the clap.meters/1 meters the panel's displays index, each a row of descriptor_get's meters[], " \
      "same ids>]} " \
      "(the keys of PHD_PANEL_FILE_KEYS; meters is optional, absent from a file written before it); an LV2 plugin's " \
      "panel is null and its meters empty. The codes are " OMX_VERB_DESCRIPTOR_GET "'s: -529 " \
      "when there is none, -530 while its scan runs, -531 when its last scan wrote nothing, -528 when the directory " \
      "could not be written") \
    X(HISTORY_GET, OMX_VERB_HISTORY_GET, "<uri>", OMX_VERB_HISTORY_GET_REPLY, \
      "what the daemon kept of the plugin on this host class, for the binary its pin holds now (the running history: " \
      "the windows it ran alone and in a group, its crashes, restarts and quarantines): one word of comma-joined " \
      "digest=<sha256>, class=<host class>, crashed=<0|1>, raises_xruns=<0|1> and then every key=value of the record " \
      "(domain plugin-hostd/history, contract.d/plugin-hostd/history/history.json); " PHD_WORD_NONE " when the plugin has no pin or no record, " PHD_WORD_UNAVAILABLE " while the " \
      "history file is blocked or history_window_s is 0, -902 for a line that is not one word") \
    X(HISTORY_CLEAR, OMX_VERB_HISTORY_CLEAR, "<uri> | " PHD_WORD_ALL, OMX_VERB_HISTORY_CLEAR_REPLY, \
      "delete the history of one plugin (every binary and host class of it), or all of it, from memory and from the " \
      "file at once; -902 while the history is blocked or off, or for a line that is not one word") \
    X(ESTIMATE, OMX_VERB_ESTIMATE, "<rate> <quantum> <uri> [<uri> ...]", OMX_VERB_ESTIMATE_REPLY, \
      "what a chain of these plugins, in signal order and named as " PHD_VERB_ADD " names them, would cost at that rate " \
      "and quantum, read from the qualification records; no plugin is loaded and nothing moves. " \
      "latency_frames adds up each member's measured latency of the grid point, else its declared one; cpu_percent " \
      "adds up each member's median nanoseconds per sample times the rate, percent of one core's cycle (a member's " \
      "cost per block over the block's duration); ram_bytes adds up the Pss of the worker each member ran alone in, " \
      "the history's pss_mb_solo of the binary its pin holds on this host class, " PHD_WORD_NONE " unless every " \
      "member has one, since no qualification record carries a RAM figure; workers is how many workers " OMX_VERB_PLAN \
      " would place the members in (an isolated one alone); unknown_count is how many members have no figure at that " \
      "rate and quantum, and the latency and the CPU add up only the others. The last word names each of them as its " \
      "position in the line, from 0, and its code, -533 for no record, -534 for no point of the grid at that rate " \
      "and quantum, -535 for a uri that names no plugin installed here, joined by commas, " PHD_WORD_NONE " for none. " \
      "Several records of one plugin (several versions) give the largest figure. Then the memory: ram_used_bytes, " \
      "what the workers hold now (" PHD_WORD_NONE " when one cannot be read), ram_added_bytes, what the members would " \
      "add, ram_budget_bytes, the host's ram_budget_mb in bytes (" PHD_WORD_NONE " when none is set), and " \
      "ram_unknown_count, how many members have no such figure. Last the host's insert verdict on the last uri, the " \
      "candidate, added to the chain the others make: a word of PHD_ESTIMATE_VERDICTS and the word of " \
      "PHD_ESTIMATE_REASONS that gave it, the first that holds in this order: the candidate's -535 refuses, its -533 " \
      "or -534 is not measured; the CPU over PHD_ESTIMATE_CPU_CEILING, used and added over the budget, another " \
      "member's code, a memory figure missing each warns; else recommend, within. -902 for a rate or a quantum that " \
      "is not a whole number above 0, or no uri")

/* ---------------------------------------------------------------- the insert verdict of estimate */

/* The words of estimate's verdict and reason are this package's domain estimate (contract.d/estimate/estimate.json), as
 * the pin and probe words are: the host judges, a consumer shows the words and computes no verdict of its own. */
/* BEGIN GENERATED PHD_ESTIMATE_VERDICTS: tools/estimate-words-gen.py, from contract.d/estimate/estimate.json */
#define PHD_ESTIMATE_VERDICT_RECOMMEND "recommend" ///< nothing the host knows speaks against adding the candidate
#define PHD_ESTIMATE_VERDICT_WARN "warn" ///< the candidate is measured, but the chain would pass the CPU ceiling or the memory budget, or a figure the judgement needs is missing: it may still be added
#define PHD_ESTIMATE_VERDICT_NOT_MEASURED "not-measured" ///< the candidate is installed but has no figure at that rate and quantum: the host cannot judge it
#define PHD_ESTIMATE_VERDICT_REFUSE "refuse" ///< the candidate names no plugin installed on this host: it cannot be added here
#define PHD_ESTIMATE_VERDICT_PATTERN "recommend|warn|not-measured|refuse" ///< one word of PHD_ESTIMATE_VERDICTS
/** @brief the rows of the list: X(id, word, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_ESTIMATE_VERDICTS(X) \
    X(RECOMMEND, PHD_ESTIMATE_VERDICT_RECOMMEND, "nothing the host knows speaks against adding the candidate") \
    X(WARN, PHD_ESTIMATE_VERDICT_WARN, "the candidate is measured, but the chain would pass the CPU ceiling or the memory budget, or a figure the judgement needs is missing: it may still be added") \
    X(NOT_MEASURED, PHD_ESTIMATE_VERDICT_NOT_MEASURED, "the candidate is installed but has no figure at that rate and quantum: the host cannot judge it") \
    X(REFUSE, PHD_ESTIMATE_VERDICT_REFUSE, "the candidate names no plugin installed on this host: it cannot be added here")
/* END GENERATED PHD_ESTIMATE_VERDICTS */
/* BEGIN GENERATED PHD_ESTIMATE_REASONS: tools/estimate-words-gen.py, from contract.d/estimate/estimate.json */
#define PHD_ESTIMATE_REASON_UNKNOWN_PLUGIN "unknown-plugin" ///< a member names no plugin installed on this host: the candidate's refuses, another member's warns
#define PHD_ESTIMATE_REASON_NO_RECORD "no-record" ///< a member has no qualification record: the candidate's is not measured, another member's warns
#define PHD_ESTIMATE_REASON_NO_CELL "no-cell" ///< a member's qualification records hold no figure at that rate and quantum: the candidate's is not measured, another member's warns
#define PHD_ESTIMATE_REASON_CPU_OVER_BUDGET "cpu-over-budget" ///< the chain's CPU, percent of one core, is over the real-time admission ceiling of one core
#define PHD_ESTIMATE_REASON_RAM_OVER_BUDGET "ram-over-budget" ///< what the workers hold now plus what the members would add is over the host's ram_budget_mb
#define PHD_ESTIMATE_REASON_RAM_UNKNOWN "ram-unknown" ///< a member has no memory figure, or what the workers hold now cannot be read
#define PHD_ESTIMATE_REASON_WITHIN "within" ///< every member is measured, and the chain is within the CPU ceiling and the memory budget
#define PHD_ESTIMATE_REASON_PATTERN "unknown-plugin|no-record|no-cell|cpu-over-budget|ram-over-budget|ram-unknown|within" ///< one word of PHD_ESTIMATE_REASONS
/** @brief the rows of the list: X(id, word, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_ESTIMATE_REASONS(X) \
    X(UNKNOWN_PLUGIN, PHD_ESTIMATE_REASON_UNKNOWN_PLUGIN, "a member names no plugin installed on this host: the candidate's refuses, another member's warns") \
    X(NO_RECORD, PHD_ESTIMATE_REASON_NO_RECORD, "a member has no qualification record: the candidate's is not measured, another member's warns") \
    X(NO_CELL, PHD_ESTIMATE_REASON_NO_CELL, "a member's qualification records hold no figure at that rate and quantum: the candidate's is not measured, another member's warns") \
    X(CPU_OVER_BUDGET, PHD_ESTIMATE_REASON_CPU_OVER_BUDGET, "the chain's CPU, percent of one core, is over the real-time admission ceiling of one core") \
    X(RAM_OVER_BUDGET, PHD_ESTIMATE_REASON_RAM_OVER_BUDGET, "what the workers hold now plus what the members would add is over the host's ram_budget_mb") \
    X(RAM_UNKNOWN, PHD_ESTIMATE_REASON_RAM_UNKNOWN, "a member has no memory figure, or what the workers hold now cannot be read") \
    X(WITHIN, PHD_ESTIMATE_REASON_WITHIN, "every member is measured, and the chain is within the CPU ceiling and the memory budget")
/* END GENERATED PHD_ESTIMATE_REASONS */
/* BEGIN GENERATED PHD_ESTIMATE_CPU_CEILING: tools/estimate-words-gen.py, from contract.d/estimate/estimate.json */
#define PHD_ESTIMATE_CPU_CEILING 60 ///< the real-time admission ceiling of one core, in percent of its cycle: an estimate whose CPU is over it warns, cpu-over-budget. The host judges the figure, never the word the reply rounds it to
#define PHD_ESTIMATE_CPU_CEILING_UNIT "percent" ///< the unit of PHD_ESTIMATE_CPU_CEILING, a word of omx-contract's PARAM_UNITS
/* END GENERATED PHD_ESTIMATE_CPU_CEILING */

/* ---------------------------------------------------------------- instance verbs */

/* What a host knows of a strip and of a plugin's controls, asked by instance. The daemon routes them to a
 * worker of a format whose workers answer them from the plugin; for a format whose worker does not, it answers them
 * itself and never forwards them. A string word is quoted when it is not a plain word, and always in a reply, with \" inside it
 * for a quote: mod-host's own tokenizer reads them. */
/* The words and the lines of these verbs, and of the note verbs below, are omx-clap's declarations (its HOST_VERBS,
 * omx_clap_host_verbs.h): OMX_VERB_<VERB> and OMX_VERB_<VERB>_FMT. preset_list and preset_get are the daemon's,
 * OMX_VERB_PRESET_LIST and OMX_VERB_PRESET_GET */

/* Notes, played on an instance by a controller that is not a jack client: the worker delivers each one as a MIDI
 * message at the start of its next cycle, on the plugin's note input. Nothing of them is kept: a note is an act, not a
 * setting, and a respawned instance starts silent. */
/** @brief the highest MIDI channel a note verb takes; the lowest is 0 */
#define PHD_NOTE_CHANNEL_MAX  15
/** @brief the highest MIDI key a note verb takes; the lowest is 0 */
#define PHD_NOTE_KEY_MAX      127
/** @brief the highest MIDI velocity a note verb takes */
#define PHD_NOTE_VELOCITY_MAX 127
/** @brief the word note_input answers for a plugin that takes no notes */
#define PHD_NO_NOTE_INPUT     PHD_WORD_NONE

/** @brief the longest string word, in bytes: CLAP_NAME_SIZE - 1 */
#define PHD_STRING_MAX 255

/* the user-preset file a worker writes for preset_save and reads for preset_load and preset_show (docs/presets.md,
 * protocol/preset.schema.json): /1 is params-only, /2 adds the state body */
/** @brief the format word of a user-preset file that holds the parameters only */
#define PHD_PRESET_FORMAT_1   "org.openmixer.preset/1"
/** @brief the format word of a user-preset file that adds the state body */
#define PHD_PRESET_FORMAT_2   "org.openmixer.preset/2"
#define PHD_PRESET_ALIAS_MAX  12
#define PHD_PRESET_FILE_MAX   (64 * 1024 * 1024)
/** @brief the parameters on one remote page */
#define PHD_REMOTE_PAGE_SLOTS 8
/** @brief the word of an empty slot of a remote page */
#define PHD_EMPTY_SLOT        PHD_WORD_NONE
/** @brief the colour of a strip that has none */
#define PHD_NO_COLOR          PHD_WORD_NONE

/** @brief the kind of strip, the fourth word of track_info; none for an input channel: X(id, name)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_TRACK_KINDS(X) \
    X(BUS, OMX_HOST_TRACK_KINDS_BUS) X(RETURN, OMX_HOST_TRACK_KINDS_RETURN) X(MASTER, OMX_HOST_TRACK_KINDS_MASTER)

/* the JACK metadata a worker sets on the uuid of each client it opens for an instance, after each activation, read by
 * every graph client on jackd and on PipeWire; the client's name stays effect_<instance>. A client matches a hosted node
 * on the instance key, never on the effect_ prefix of its name (plugin-hostd#33). A server that keeps no metadata (a
 * PipeWire with no session manager) takes none, and the node keeps its name. Each row's key and the printf format of
 * its value are PHD_NODE_METADATA_<ID>_KEY and _FORMAT. */
/** @brief the JACK metadata key of the pretty name of a hosted node */
#define PHD_NODE_METADATA_PRETTY_NAME_KEY    "http://jackaudio.org/metadata/pretty-name"
/** @brief the printf format of the pretty name's value: the plugin name and the instance */
#define PHD_NODE_METADATA_PRETTY_NAME_FORMAT "%s (%d)"
/** @brief the JACK metadata key of the instance a node hosts */
#define PHD_NODE_METADATA_INSTANCE_KEY       "http://openmixer.org/ns/plugin-hostd#instance"
/** @brief the printf format of the instance's value */
#define PHD_NODE_METADATA_INSTANCE_FORMAT    "%d"
/** @brief the JACK metadata key of the pretty name of a labelled node
 *
 * A node a client has labelled; it is the key of the plain pretty name.
 */
#define PHD_NODE_METADATA_LABELLED_NAME_KEY    PHD_NODE_METADATA_PRETTY_NAME_KEY
/** @brief the printf format of the labelled name's value: the label, the plugin name and the instance */
#define PHD_NODE_METADATA_LABELLED_NAME_FORMAT "%s: %s (%d)"
/** @brief the most bytes of a node_label label, its words joined by one space (plugin-hostd#35) */
#define PHD_NODE_LABEL_MAX 64
/** @brief the JACK metadata a worker sets on a hosted node, as rows X(id, name, args, meaning)
 *
 * args is what fills the format, in order, separated by commas.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_NODE_METADATA(X) \
    X(PRETTY_NAME, "pretty_name", "plugin name,instance", \
      "the name a graph client shows for the node: the plugin's name from its descriptor and the instance") \
    X(INSTANCE, "instance", "instance", "the instance the node hosts, which a client matches a hosted node on") \
    X(LABELLED_NAME, "labelled_name", "label,plugin name,instance", \
      "the pretty-name of a node a client has labelled (node_label): the label, the plugin's name and the instance, " \
      "in place of pretty_name until the label is cleared")

/** @brief how a parameter's plain value maps to a control's travel: X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
/* BEGIN GENERATED PHD_PARAM_SCALES: tools/param-scales-gen.py, from omx-contract's domain param, item PARAM_SCALES */
#define PHD_PARAM_SCALES(X) \
    X(LINEAR, "linear", "the value is linear in position") \
    X(LOG, "log", "the value is geometric in position; both bounds are positive") \
    X(STEPPED, "stepped", "the whole numbers from min to max, step 1")
/* END GENERATED PHD_PARAM_SCALES */

/* what the ledger keeps of a verb: nothing; the latest one per instance; or the latest one per instance and first argument
 * (replace-keyed, ruling of 2026-11-14 on omx-clap-core#15: a property is the daemon's state, so a respawned worker gets
 * back every symbol it was given, each the latest set of it, in the order they were first set). Replayed after the add. */
/** @brief the word of the show_external_ui verb
 *
 * mod-host.h declares it as the format SHOW_EXTERNAL_UI, and omx-clap's verb table does not.
 */
#define PHD_VERB_SHOW_EXTERNAL_UI "show_external_ui"
/** @brief the ledger keeps nothing of the verb */
#define PHD_LEDGER_NONE    0
/** @brief the ledger keeps the latest line of the verb per instance */
#define PHD_LEDGER_REPLACE 1
/** @brief the ledger keeps the latest line of the verb per instance and first argument
 *
 * They are replayed in the order they were first set.
 */
#define PHD_LEDGER_REPLACE_KEYED 2

/** @brief the verbs that name an instance, as rows X(id, name, arguments, reply, ledger, meaning)
 *
 * ledger is NONE, REPLACE or REPLACE_KEYED, what the ledger keeps of the verb.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_INSTANCE_VERBS(X) \
    X(TRACK_INFO, OMX_VERB_TRACK_INFO, "<instance> <name> <#RRGGBB | " PHD_NO_COLOR "> [bus | return | master]", \
      "resp 0", REPLACE, \
      "the strip's name (\"\" for none), colour and kind, absent for an input channel; a worker whose plugin format " \
      "has a track-info extension passes them on; any other word is -902, and so is a name of 256 bytes or more, one " \
      "that is not UTF-8 as RFC 3629 spells it (an overlong form, a surrogate, a code point past U+10FFFF, a lead " \
      "byte without its tails) or one that holds a control character of Unicode's class Cc: U+0000 to U+001F, U+007F " \
      "or U+0080 to U+009F") \
    X(NODE_LABEL, OMX_VERB_NODE_LABEL, "<instance> [<label word> ...]", "resp 0", REPLACE, \
      "label the node for graph clients: the worker that holds the instance sets its pretty-name to the labelled " \
      "form of PHD_NODE_METADATA, the label the words joined by one space; no words clears it, back to the plain " \
      "form. -545 for a label over PHD_NODE_LABEL_MAX bytes or not UTF-8; the ledger keeps the latest, so a " \
      "respawned worker is labelled again (plugin-hostd#35)") \
    X(REMOTE_PAGES, OMX_VERB_REMOTE_PAGES, "<instance>", "resp <count>", NONE, \
      "the plugin's remote-control pages, from clap.remote-controls; 0 for an instance of a format whose worker has none") \
    X(REMOTE_PAGE_GET, OMX_VERB_REMOTE_PAGE_GET, "<instance> <page>", \
      "resp 0 <page_id> <section> <page_name> <s1> <s2> <s3> <s4> <s5> <s6> <s7> <s8>", NONE, \
      "one page, 0 to count - 1: each slot the symbol param_set takes, " PHD_EMPTY_SLOT " for an empty one; -902 " \
      "for a page that is not one") \
    X(PROPERTY_LIST, OMX_VERB_PROPERTY_LIST, "<instance>", OMX_VERB_PROPERTY_LIST_REPLY, NONE, \
      "the plugin's file and text properties (org.openmixer.properties/1): how many; 0 for an instance of a worker " \
      "that has none") \
    X(PROPERTY_INFO, OMX_VERB_PROPERTY_INFO, "<instance> <index>", OMX_VERB_PROPERTY_INFO_REPLY, NONE, \
      "one property, 0 to count - 1: its symbol, its kind (path or string), its access (rw, w or r) and its name; " \
      PHD_STR(OMX_REPLY_HOST_PROPERTY_SYMBOL_INVALID_RESP) " for an index that is not one") \
    X(PROPERTY_GET, OMX_VERB_PROPERTY_GET, "<instance> <symbol>", OMX_VERB_PROPERTY_GET_REPLY, NONE, \
      "the value the plugin holds now, one quoted-escaped word; " PHD_STR(OMX_REPLY_HOST_PROPERTY_ACCESS_RESP) \
      " for a property that is not readable") \
    X(PROPERTY_SET, OMX_VERB_PROPERTY_SET, "<instance> <symbol> <value>", OMX_VERB_PROPERTY_SET_REPLY, REPLACE_KEYED, \
      "set a property to a quoted-escaped value, which reaches the plugin at its next block; the ledger keeps the latest " \
      "per symbol and replays each to a respawned worker. " PHD_STR(OMX_REPLY_HOST_PROPERTY_ACCESS_RESP) " for one not " \
      "writable, " PHD_STR(OMX_REPLY_HOST_PROPERTY_VALUE_INVALID_RESP) " for a value too large, not UTF-8 or a path " \
      "that is not absolute, " PHD_STR(OMX_REPLY_HOST_PROPERTY_QUEUE_FULL_RESP) " to send again") \
    X(PARAM_INFO, OMX_VERB_PARAM_INFO, "<instance> <symbol>", \
      "resp 0 <unit> <scale> <min> <max> <default> <step> <stable_symbol>", NONE, \
      "what a parameter's value means: its unit, its scale, and the symbol it keeps across hosts and versions; -103 " \
      "for a symbol that is not a parameter, the plugin's own bypass and :bypass included; " \
      "-511 for a parameter whose unit and scale the worker holds no checked contract for") \
    X(PRESET_LIST, OMX_VERB_PRESET_LIST, "<instance>", OMX_VERB_PRESET_LIST_REPLY, NONE, \
      "the plugin's presets, the ones its preset discovery or its bundle lists; " PHD_STR(OMX_REPLY_PLUGIN_HOSTD_NO_PRESET_LIST_RESP) \
      " for an instance of a worker that cannot list them") \
    X(PRESET_GET, OMX_VERB_PRESET_GET, "<instance> <index>", OMX_VERB_PRESET_GET_REPLY, NONE, \
      "one preset, 0 to count - 1: the key preset_load takes for it, and its name; -902 for an index that is not one") \
    X(NOTE_INPUT, OMX_VERB_NOTE_INPUT, "<instance>", "resp 0 <port | " PHD_NO_NOTE_INPUT ">", NONE, \
      "whether the instance takes notes: the name of its note input on its worker's jack client, " PHD_NO_NOTE_INPUT \
      " for a plugin that takes none; " PHD_STR(OMX_REPLY_HOST_NOTES_BY_JACK_RESP) " for an instance of a worker that cannot say") \
    X(NOTE_ON, OMX_VERB_NOTE_ON, "<instance> <channel> <key> <velocity>", "resp 0", NONE, \
      "play a key: channel 0 to " PHD_STR(PHD_NOTE_CHANNEL_MAX) ", key 0 to " PHD_STR(PHD_NOTE_KEY_MAX) ", velocity 1 to " \
      PHD_STR(PHD_NOTE_VELOCITY_MAX) ", a MIDI note on at the start of the worker's next cycle; " \
      PHD_STR(OMX_REPLY_HOST_NO_NOTE_INPUT_RESP) " for a plugin that takes no notes, " PHD_STR(OMX_REPLY_HOST_NOTES_BY_JACK_RESP) \
      " for an instance of a worker that takes none on its socket, -902 for a word out of its range") \
    X(NOTE_OFF, OMX_VERB_NOTE_OFF, "<instance> <channel> <key> <velocity>", "resp 0", NONE, \
      "release a key, velocity 0 to " PHD_STR(PHD_NOTE_VELOCITY_MAX) ", a MIDI note off; answered as " OMX_VERB_NOTE_ON " is") \
    X(ALL_NOTES_OFF, OMX_VERB_ALL_NOTES_OFF, "<instance>", "resp 0", NONE, \
      "release every key of every channel, MIDI's all notes off (controller 123) on each; answered as " OMX_VERB_NOTE_ON " is") \
    X(SHOW_EXTERNAL_UI, PHD_VERB_SHOW_EXTERNAL_UI, "<instance>", "resp 0", REPLACE, \
      "put the plugin's own window on the display, as jalv and mod-host show one: the worker that holds the instance " \
      "answers, and its resp comes back as it wrote it (omx-clap-host: -404 and a hosting.window code when no window " \
      "shows); -902 for an instance whose worker has no window (mod-host's), and -902 " PHD_EXTERNAL_UI_NO_DISPLAY \
      " from a daemon with no display session. The ledger keeps the latest of this verb and " OMX_VERB_HIDE_EXTERNAL_UI \
      " as one setting: a window shown is shown again after a respawn, after the state") \
    X(HIDE_EXTERNAL_UI, OMX_VERB_HIDE_EXTERNAL_UI, "<instance>", "resp 0", REPLACE, \
      "take the plugin's own window off the display, kept for the next " PHD_VERB_SHOW_EXTERNAL_UI "; answered as " \
      PHD_VERB_SHOW_EXTERNAL_UI " is, resp 0 also when no window is shown; in the ledger it takes back the show, so a " \
      "respawn shows nothing")

/** @brief tells whether a string is a string word
 *
 * It is valid UTF-8 as RFC 3629 spells it, has no byte below 0x20 and is at most PHD_STRING_MAX bytes.
 *
 * @pre s is not NULL.
 * @param[in] s a NUL-terminated string.
 * @return nonzero when s is a string word, else 0.
 */
static inline int phd_string_valid(const char *s)
{
    const unsigned char *p = (const unsigned char *)s;
    int n = 0;

    while (p[n])
    {
        unsigned c = p[n], cp;
        int more, k;

        if (c < 0x20)
            return 0;
        if (c < 0x80)
        {
            n++;
            continue;
        }
        if (c >= 0xc2 && c <= 0xdf)
            more = 1, cp = c & 0x1f;
        else if (c >= 0xe0 && c <= 0xef)
            more = 2, cp = c & 0x0f;
        else if (c >= 0xf0 && c <= 0xf4)
            more = 3, cp = c & 0x07;
        else
            return 0;
        for (k = 1; k <= more; k++)
        {
            if ((p[n + k] & 0xc0) != 0x80)
                return 0;
            cp = (cp << 6) | (p[n + k] & 0x3f);
        }
        if ((more == 2 && (cp < 0x800 || (cp >= 0xd800 && cp <= 0xdfff))) || (more == 3 && (cp < 0x10000 || cp > 0x10ffff)))
            return 0;
        n += more + 1;
    }
    return n <= PHD_STRING_MAX;
}

/** @brief tells whether a string is a colour of track_info
 *
 * @pre c is not NULL.
 * @param[in] c a NUL-terminated string.
 * @return nonzero when c is PHD_NO_COLOR or \#RRGGBB in either case, else 0.
 */
static inline int phd_color_valid(const char *c)
{
    int n;

    if (!strcmp(c, PHD_NO_COLOR))
        return 1;
    if (c[0] != '#')
        return 0;
    for (n = 1; n <= 6; n++)
        if (!((c[n] >= '0' && c[n] <= '9') || (c[n] >= 'a' && c[n] <= 'f') || (c[n] >= 'A' && c[n] <= 'F')))
            return 0;
    return c[7] == '\0';
}

/** @brief gives the kind of strip a fourth word of track_info names
 *
 * @param[in] word the fourth word of a track_info line, or NULL for an input channel.
 * @return the 1-based row of word in PHD_TRACK_KINDS; 0 for NULL (an input channel); -1 for a word that is not a kind.
 */
static inline int phd_track_kind(const char *word)
{
    int n = 0;

    if (!word)
        return 0;
#define X(id, name) n++; if (!strcmp(word, name)) return n;
    PHD_TRACK_KINDS(X)
#undef X
    return -1;
}

/** @brief tells whether the words of a track_info line are its grammar
 *
 * The instance, word[1], is not checked.
 *
 * @pre word is an array of at least count words, the verb first.
 * @param[in] word the words of the line.
 * @param count how many words there are.
 * @return nonzero when count is 4 or 5, the name is a string word, the colour is valid and the kind, when there is one,
 *     is a kind; else 0.
 */
static inline int phd_track_info_valid(char *const *word, int count)
{
    return (count == 4 || count == 5) && phd_string_valid(word[2]) && phd_color_valid(word[3]) &&
           phd_track_kind(count == 5 ? word[4] : NULL) >= 0;
}

/** @brief tells whether a word is a whole number from lo to hi
 *
 * It is in decimal with no sign but a leading '-'. Leading zeros are accepted (0, 00 and 000 are numbers); a negative
 * zero, a '-' followed only by zeros ('-0', '-00', '-000'), is refused, whatever lo is. A magnitude above 1000009 is
 * refused whatever hi is, since a digit past a value of 100000 is refused: a caller that asks for more, as
 * phd_note_valid does with 1 << 20, never gets it (plugin-hostd-protocol#73).
 *
 * @pre word is not NULL.
 * @param[in] word a NUL-terminated string.
 * @param lo the least value accepted.
 * @param hi the greatest value accepted.
 * @return nonzero when word is such a number, else 0.
 */
static inline int phd_number_in(const char *word, int lo, int hi)
{
    long long v = 0;
    int negative = word[0] == '-', n = negative;

    if (!word[n] || (word[n] == '0' && (negative || word[n + 1])))
        return 0;
    for (; word[n]; n++)
    {
        int digit = word[n] - '0';

        if (digit < 0 || digit > 9 || v > (LLONG_MAX - digit) / 10)
            return 0;
        v = v * 10 + digit;
    }
    if (negative)
        v = -v;
    return v >= lo && v <= hi;
}

/** @brief tells whether the words of a note verb's line are its grammar
 *
 * The verb is read before count is looked at (plugin-hostd-protocol#71).
 *
 * @pre word is an array of at least count words, the verb first, and count is 1 or more.
 * @param[in] word the words of the line.
 * @param count how many words there are.
 * @return nonzero when the line has the grammar of its note verb; 0 for a line that does not, and for the line of
 *     another verb.
 */
static inline int phd_note_valid(char *const *word, int count)
{
    int on;

    if (count < 2 || !phd_number_in(word[1], 0, 1 << 20))
        return 0;
    on = !strcmp(word[0], OMX_VERB_NOTE_ON);
    if (on || !strcmp(word[0], OMX_VERB_NOTE_OFF))
        return count == 5 && phd_number_in(word[2], 0, PHD_NOTE_CHANNEL_MAX) && phd_number_in(word[3], 0, PHD_NOTE_KEY_MAX) &&
               phd_number_in(word[4], on ? 1 : 0, PHD_NOTE_VELOCITY_MAX);
    if (!strcmp(word[0], OMX_VERB_ALL_NOTES_OFF) || !strcmp(word[0], OMX_VERB_NOTE_INPUT))
        return count == 2;
    return 0;
}

/** @brief tells whether a verb is one of the note verbs
 *
 * @pre verb is not NULL.
 * @param[in] verb a NUL-terminated string.
 * @return nonzero when verb is OMX_VERB_NOTE_ON, OMX_VERB_NOTE_OFF, OMX_VERB_ALL_NOTES_OFF or OMX_VERB_NOTE_INPUT, else
 *     0.
 */
static inline int phd_is_note_verb(const char *verb)
{
    return !strcmp(verb, OMX_VERB_NOTE_ON) || !strcmp(verb, OMX_VERB_NOTE_OFF) || !strcmp(verb, OMX_VERB_ALL_NOTES_OFF) ||
           !strcmp(verb, OMX_VERB_NOTE_INPUT);
}

/* ---------------------------------------------------------------- the host verb table */

/* What each host profile owes every verb a controller sends the daemon: the commands of mod-host's protocol, the two
 * that Zynthian's mod-ui still names and mod-host never had, and the verbs this daemon adds. tests/verb_table.py holds
 * the table to that list, no more and no fewer, so a verb cannot be added to the daemon without its row.
 *
 * required: answered as its grammar says. optional: answered, or refused with -902; never misread. absent: refused on
 * purpose, and no client of the profile may need it. */
/** @brief a host profile owes the verb an answer as its grammar says */
#define PHD_LEVEL_REQUIRED "required"
/** @brief a host profile answers the verb, or refuses it with -902, and never misreads it */
#define PHD_LEVEL_OPTIONAL "optional"
/** @brief the verb is refused on purpose, and no client of the profile may need it */
#define PHD_LEVEL_ABSENT   "absent"
/** @brief the levels as rows X(id, name)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_LEVELS(X) X(REQUIRED, PHD_LEVEL_REQUIRED) X(OPTIONAL, PHD_LEVEL_OPTIONAL) X(ABSENT, PHD_LEVEL_ABSENT)

/** @brief the profiles, a column each: X(id, name, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_HOST_PROFILES(X) \
    X(LV2, "lv2-worker", "an LV2 plugin's worker: mod-host, or omx-clap-host's LV2 adapter") \
    X(CLAP, "clap-worker", "a CLAP plugin's worker, omx-clap-host") \
    X(CONSOLE, "console", "the openmixer console as a controller of the daemon") \
    X(ZYNTHIAN, "zynthian", "Zynthian's mod-ui and its plugind engine as a controller of the daemon")

/* who sends the verb: mod-ui (Zynthian's mod-ui sends it to its host), mod-host (a command of mod-host.h that mod-ui
 * does not send), daemon (a verb this daemon adds: it answers it itself, whatever the worker) */
/** @brief the verb is sent by Zynthian's mod-ui to its host */
#define PHD_HOST_VERB_SOURCE_MOD_UI   "mod-ui"
/** @brief the verb is a command of mod-host.h that mod-ui does not send */
#define PHD_HOST_VERB_SOURCE_MOD_HOST "mod-host"
/** @brief the verb is one this daemon adds: it answers it itself, whatever the worker */
#define PHD_HOST_VERB_SOURCE_DAEMON   "daemon"

/** @brief the table of what each host profile owes each verb
 *
 * A row is X(name, source, lv2-worker, clap-worker, console, zynthian).
 *
 * The mod-ui rows are the decision of 2026-10-21 (FreeMixer/plugin-hostd#131), read from Zynthian's verbs.tsv, with the
 * decisions of 2026-10-22: presets and bundles are required of the CLAP worker and of Zynthian; MIDI learn and CV
 * addressing are policy of the surfaces, so the host answers them only as the mechanism and they stay optional for
 * every profile (presets in the host, docs/presets.md). The others are this tree's. The daemon relays a worker's verb
 * (an instance verb to the worker that holds the instance, any other to every worker) and passes its answer back, so a
 * required verb answers -902 only while the worker does.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_HOST_VERBS(X) \
    X("add", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("remove", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("bypass", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("connect", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("param_set", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("state_load", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("state_save", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("state_tmpdir", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("feature_enable", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("bundle_add", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("bundle_remove", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("preset_load", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("preset_save", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PRESET_SHOW, MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("transport", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("transport_sync", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("cpu_load", MOD_UI, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("midi_learn", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("midi_map", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("midi_unmap", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("cv_map", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("cv_unmap", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("monitor_midi_program", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("monitor_output", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("output_data_ready", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("patch_get", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("patch_set", MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("cc_map", MOD_UI, ABSENT, ABSENT, ABSENT, ABSENT) \
    X("cc_value_set", MOD_UI, ABSENT, ABSENT, ABSENT, ABSENT) \
    X("cc_unmap", MOD_UI, ABSENT, ABSENT, ABSENT, ABSENT) \
    X("hmi_map", MOD_UI, ABSENT, ABSENT, ABSENT, ABSENT) \
    X("hmi_unmap", MOD_UI, ABSENT, ABSENT, ABSENT, ABSENT) \
    X(PHD_VERB_SHOW_EXTERNAL_UI, MOD_UI, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("set_midi_program_change_pedalboard_bank_channel", MOD_UI, ABSENT, ABSENT, ABSENT, ABSENT) \
    X("set_midi_program_change_pedalboard_snapshot_channel", MOD_UI, ABSENT, ABSENT, ABSENT, ABSENT) \
    X("disconnect", MOD_HOST, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("set_bpm", MOD_HOST, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("set_bpb", MOD_HOST, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("quit", MOD_HOST, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X("param_get", MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("param_monitor", MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("licensee", MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("monitor", MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("load", MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("save", MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X("help", MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_TRACK_INFO, MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_REMOTE_PAGES, MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_REMOTE_PAGE_GET, MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_PARAM_INFO, MOD_HOST, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_PROPERTY_LIST, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_PROPERTY_INFO, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_PROPERTY_GET, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_PROPERTY_SET, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_PRESET_LIST, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_PRESET_GET, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_NOTE_INPUT, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_NOTE_ON, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_NOTE_OFF, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_ALL_NOTES_OFF, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_HIDE_EXTERNAL_UI, DAEMON, OPTIONAL, OPTIONAL, OPTIONAL, OPTIONAL) \
    X(OMX_VERB_WORKER_LIST, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_INSTANCE_INFO, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_SUPERVISOR_RESET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_QUARANTINE_CLEAR, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_POLICY_SET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_POOL_CONFIG, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_WORKER_ENV, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PIN_SET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PIN_CLEAR, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PIN_ACCEPT, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PIN_RELOAD, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PIN_CHANGED, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_LV2_WORKER_SET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_CHAIN, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_CHAIN_CLEAR, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_CHAIN_GET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PLAN, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PLAN_GET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PLAN_CLEAR, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_DESCRIPTOR_GET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_PANEL_GET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_HISTORY_GET, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_HISTORY_CLEAR, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_ESTIMATE, DAEMON, REQUIRED, REQUIRED, REQUIRED, REQUIRED) \
    X(OMX_VERB_NODE_LABEL, DAEMON, ABSENT, OPTIONAL, OPTIONAL, OPTIONAL)

/* ---------------------------------------------------------------- host settings */

/** @brief what the daemon keeps of a command that names no instance and is broadcast to every worker: X(id, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_HOST_SETTINGS(X) \
    X(TEMPO, "the tempo, the metre and the transport a controller sets (mod-host's set_bpm, set_bpb, transport and " \
             "transport_sync) are kept, the latest line of each as it was sent, in the order they were last sent") \
    X(REPLAY, "a worker is handed them before anything else: a respawned one before its first add, and a worker " \
              "started later, of a new placement, as well; a worker's refusal of one is written to stderr and is no failure") \
    X(GRAMMAR, "a line whose words are not that command's grammar is passed on and not kept")

/* ---------------------------------------------------------------- the qualify spool (R-112)
 * One request per plugin that has no verdict, written by the daemon and read by plugin-qualify's watched service, which
 * alone writes the verdict. The directory is beside the pin store; a request is one file, written whole by a temporary
 * file in the same directory renamed over its name, its lines "uri <uri>" then one "file <path> <sha256>" per file the
 * daemon hashed. The daemon runs no probe, queue or judge and loads no plugin code. */
/** @brief the name of the spool directory, beside the pin store */
#define PHD_QUALIFY_SPOOL_DIR      "qualify"
/** @brief the suffix of a request file */
#define PHD_QUALIFY_REQUEST_SUFFIX ".request"
/** @brief the first word of a request's uri line */
#define PHD_QUALIFY_REQUEST_URI    "uri"
/** @brief the first word of a request's file lines */
#define PHD_QUALIFY_REQUEST_FILE   "file"

/* ---------------------------------------------------------------- feedback events */

/* one NUL-terminated line each on the feedback port; a worker is "w<k>" */
/** @brief the name of the feedback event worker_died
 *
 * A worker died.
 */
#define PHD_EVENT_WORKER_DIED             "worker_died"
/** @brief the name of the feedback event instance_verb_dropped
 *
 * A command is dropped from the ledger because the worker died on it.
 */
#define PHD_EVENT_INSTANCE_VERB_DROPPED   "instance_verb_dropped"
/** @brief the name of the feedback event worker_backoff
 *
 * The respawn of a worker waits this long.
 */
#define PHD_EVENT_WORKER_BACKOFF          "worker_backoff"
/** @brief the name of the feedback event worker_respawned
 *
 * A worker is back and its ledger replayed.
 */
#define PHD_EVENT_WORKER_RESPAWNED        "worker_respawned"
/** @brief the name of the feedback event instance_restored
 *
 * An instance is back in a worker.
 */
#define PHD_EVENT_INSTANCE_RESTORED       "instance_restored"
/** @brief the name of the feedback event instance_replay_refused
 *
 * A replayed add was refused, by its pin or by the worker.
 */
#define PHD_EVENT_INSTANCE_REPLAY_REFUSED "instance_replay_refused"
/** @brief the name of the feedback event instance_quarantined
 *
 * The culprit of a pool or chain death is placed own until cleared.
 */
#define PHD_EVENT_INSTANCE_QUARANTINED    "instance_quarantined"
/** @brief the name of the feedback event supervisor_gave_up
 *
 * The storm bound is spent; respawning ends.
 */
#define PHD_EVENT_SUPERVISOR_GAVE_UP      "supervisor_gave_up"
/** @brief the name of the feedback event pin_changed
 *
 * An add or a replay of a plugin was refused because its files or layout differ from its pin; it is also the word of
 * the pin_changed verb.
 */
#define PHD_EVENT_PIN_CHANGED             OMX_VERB_PIN_CHANGED
/** @brief the name of the feedback event lv2_adapter_refused
 *
 * The LV2 adapter of the lv2-clap worker refused a plugin.
 */
#define PHD_EVENT_LV2_ADAPTER_REFUSED     "lv2_adapter_refused"
/** @brief the name of the feedback event chain_formed
 *
 * A chain's worker is up with its members.
 */
#define PHD_EVENT_CHAIN_FORMED            "chain_formed"
/** @brief the name of the feedback event chain_refused
 *
 * A chain's worker would not run the members as one chain.
 */
#define PHD_EVENT_CHAIN_REFUSED           "chain_refused"
/** @brief the name of the feedback event chain_stalled
 *
 * A chain, or a plan's segment, has not formed within chain_form_timeout_ms of its declaration.
 */
#define PHD_EVENT_CHAIN_STALLED           "chain_stalled"
/** @brief the name of the feedback event plan_reason
 *
 * A plan of the chain changed: the reasons plan_get answers now.
 */
#define PHD_EVENT_PLAN_REASON             "plan_reason"
/** @brief the name of the feedback event qualify_requested: a plugin with no verdict has a request in the spool */
#define PHD_EVENT_QUALIFY_REQUESTED       "qualify_requested"
/* written by a worker, relayed as it wrote it */
/** @brief the name of the feedback event remote_pages_changed
 *
 * Relayed from a worker: the plugin changed its remote pages.
 */
#define PHD_EVENT_REMOTE_PAGES_CHANGED    "remote_pages_changed"
/** @brief the name of the feedback event remote_page_suggest
 *
 * Relayed from a worker: the plugin suggests the remote page of an id.
 */
#define PHD_EVENT_REMOTE_PAGE_SUGGEST     "remote_page_suggest"
/** @brief the name of the feedback event param_gesture
 *
 * Relayed from a worker: the user took hold of a control of the plugin's own, or let it go.
 */
#define PHD_EVENT_PARAM_GESTURE           "param_gesture"
/* a worker's own count, not an instance's: omx-clap's HOST_EVENTS word xruns (tests/verbs_declared.py holds this to it) */
/** @brief the name of the feedback event xruns
 *
 * Relayed from a worker and read by the daemon: the JACK xruns the worker has counted since it started.
 */
#define PHD_EVENT_XRUNS                   "xruns"
/** @brief the name of the feedback event abi_clobber
 *
 * Relayed from a worker and read by the daemon: the plugin returned from a call with a callee-saved register changed.
 */
#define PHD_EVENT_ABI_CLOBBER             "abi_clobber"
/* mod-host's own feedback line for a parameter, the same word as its command */
/** @brief the name of the feedback event param_set
 *
 * Relayed from a worker: parameter feedback, a value the plugin moved by itself, as mod-host writes it.
 */
#define PHD_EVENT_PARAM_SET               "param_set"

/** @brief the last word of a param_gesture line when the user took hold of a control */
#define PHD_GESTURE_BEGIN "begin"
/** @brief the last word of a param_gesture line when the user let go of a control */
#define PHD_GESTURE_END   "end"

/** @brief the prefix of the suspect word of an instance_verb_dropped line: suspect:\<ms\> */
#define PHD_EVENT_SUSPECT_PREFIX "suspect:"
/** @brief one alternative of PHD_STATE_PATTERN, the state's name and '|'
 *
 * The last alternative of the pattern, (?!), never matches, so the list needs no separator after its last name.
 *
 * @param id the id of the row, unused.
 * @param name the name of the state.
 * @param meaning the meaning of the row, unused.
 */
#define PHD_STATE_ALTERNATIVE(id, name, meaning) name "|"
/** @brief the pattern of the state type, written from PHD_WORKER_STATES: each name an alternative */
#define PHD_STATE_PATTERN "(?:" PHD_WORKER_STATES(PHD_STATE_ALTERNATIVE) "(?!))"

/** @brief how a worker ended, the third word of worker_died: exit:\<status\> or signal:\<number\> */
#define PHD_EVENT_EXIT_PREFIX   "exit:"
/** @brief the prefix of the third word of worker_died when a signal ended the worker: signal:\<number\> */
#define PHD_EVENT_SIGNAL_PREFIX "signal:"

/** @brief the types of a feedback line's arguments (PHD_EVENTS), as rows X(id, name, pattern, rest, spelling)
 *
 * Each type is a pattern its word matches whole; rest is 1 for the type of the rest of the line, its words as they were
 * sent. An argument whose type is not one of these is one of the literal words its type spells, written a|b.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_ARG_TYPES(X) \
    X(INT, "int", "-?[0-9]+", 0, "a whole number") \
    X(UINT, "uint", "[0-9]+", 0, "a whole number, not negative") \
    X(HEX, "hex", "0|0x[0-9a-f]+", 0, "a number in hexadecimal, 0x and its digits, or 0") \
    X(WORD, "word", "[^ ]+", 0, "one word") \
    X(WORKER, "worker", "w[0-9]+", 0, "a worker, w<k>, as worker_list names it") \
    X(INSTANCES, "instances", PHD_WORD_NONE "|[0-9]+(?:,[0-9]+)*", 0, \
      "instance numbers joined by ',', in order, or " PHD_WORD_NONE " for none") \
    X(INSTANCE_OR_NONE, "instance-or-none", PHD_WORD_NONE "|[0-9]+", 0, "an instance number, or " PHD_WORD_NONE " for none") \
    X(STATUS, "status", "(?:" PHD_EVENT_EXIT_PREFIX "|" PHD_EVENT_SIGNAL_PREFIX ")-?[0-9]+", 0, \
      PHD_EVENT_EXIT_PREFIX "<status> for a process that exited, " PHD_EVENT_SIGNAL_PREFIX "<number> for one a signal ended") \
    X(SUSPECT, "suspect", PHD_EVENT_SUSPECT_PREFIX "[0-9]+", 0, PHD_EVENT_SUSPECT_PREFIX "<ms>, the age of the reply") \
    X(CHAIN, "chain", "[0-9]+(?:\\" PHD_PLACE_PLAN_SEPARATOR "[0-9]+)?", 0, \
      "a chain's number, or <plan>" PHD_PLACE_PLAN_SEPARATOR "<k> for segment k of a plan") \
    X(REASONS, "reasons", PHD_WORD_NONE "|[0-9]+:[^ ,]+(?:,[0-9]+:[^ ,]+)*", 0, \
      "<instance>:<reason> joined by ',', or " PHD_WORD_NONE " for none") \
    X(PLACEMENT, "placement", PHD_PLACE_OWN "|" PHD_PLACE_DEFAULT "|" PHD_PLACE_POOL_PREFIX "[" PHD_POOL_NAME_CLASS "]{" \
      PHD_STR(PHD_POOL_NAME_MIN) "," PHD_STR(PHD_POOL_NAME_MAX) "}|" PHD_PLACE_CHAIN_PREFIX "[0-9]+", 0, \
      "a placement, " PHD_PLACEMENT_SYNTAX) \
    X(MEMBER, "member", "[0-9]+" PHD_WORKER_PIN_REFUSED "?", 0, \
      "an instance a worker holds, followed by " PHD_WORKER_PIN_REFUSED " when the pins read again refuse its files") \
    X(WORKER_OR_NONE, "worker-or-none", PHD_WORD_NONE "|w[0-9]+", 0, "a worker, w<k>, or " PHD_WORD_NONE " for none") \
    X(STATE, "state", PHD_STATE_PATTERN, 0, "a worker's state, a name of PHD_WORKER_STATES") \
    X(PLACE, "place", PHD_PLACE_OWN "|" PHD_PLACE_DEFAULT "|" PHD_PLACE_POOL_PREFIX "[" PHD_POOL_NAME_CLASS "]{" \
      PHD_STR(PHD_POOL_NAME_MIN) "," PHD_STR(PHD_POOL_NAME_MAX) "}(?:" PHD_POOL_SIBLING_SEPARATOR "[0-9]+)?|" \
      PHD_PLACE_CHAIN_PREFIX "[0-9]+(?:\\" PHD_PLACE_PLAN_SEPARATOR "[0-9]+)?", 0, \
      "where a worker runs: a placement, a full pool's sibling <name>" PHD_POOL_SIBLING_SEPARATOR "<n>, or a plan's " \
      "segment chain:<plan>" PHD_PLACE_PLAN_SEPARATOR "<k>") \
    X(AMOUNT, "amount", PHD_WORD_NONE "|[0-9]+", 0, "a whole amount (bytes), or " PHD_WORD_NONE " when there is none") \
    X(CORE, "core", PHD_WORD_NONE "|[0-9]+", 0, "an audio core, or " PHD_WORD_NONE " for a worker pinned to none") \
    X(NUMBER, "number", "-?[0-9]+(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?", 0, "a decimal number") \
    X(SHA256, "sha256", "[0-9a-f]{64}", 0, "a SHA-256 in 64 lowercase hexadecimal digits") \
    X(QUOTED, "quoted", "\"[^\"]*\"", 0, "a path in double quotes") \
    X(QUOTED_ESCAPED, "quoted-escaped", "\"(?:[^\"\\\\]|\\\\[\"\\\\])*\"", 0, \
      "text in double quotes, \\\" a quote and \\\\ a backslash inside it (a property's value)") \
    X(KEY, "key", "[a-z_]+", 0, "a key of a key=value") \
    X(VALUE, "value", "[^, ]*", 0, "a value of a key=value") \
    X(ESTIMATE_VERDICT, "estimate-verdict", PHD_ESTIMATE_VERDICT_PATTERN, 0, "a verdict word of PHD_ESTIMATE_VERDICTS") \
    X(ESTIMATE_REASON, "estimate-reason", PHD_ESTIMATE_REASON_PATTERN, 0, "a reason word of PHD_ESTIMATE_REASONS") \
    X(LINE, "line", ".*", 1, "the rest of the line, its words as they were sent")

/** @brief the forms of a command whose words the verb table's one format does not name, as rows X(verb, args)
 *
 * Each form's arguments are name:type, as PHD_EVENTS' args, a form per number of them. add is mod-host's \<uri\>
 * \<instance\>, which the daemon extends with a placement and a client name, each optional (a placement told from a
 * name by its type); supervisor_reset re-arms one worker or every one (plugin-hostd-protocol#17).
 *
 * @param X the macro each row is passed to.
 */
#define PHD_COMMAND_FORMS(X) \
    X(PHD_VERB_ADD, "uri:word instance:int") \
    X(PHD_VERB_ADD, "uri:word instance:int placement:placement") \
    X(PHD_VERB_ADD, "uri:word instance:int client:word") \
    X(PHD_VERB_ADD, "uri:word instance:int placement:placement client:word") \
    X(OMX_VERB_SUPERVISOR_RESET, "") \
    X(OMX_VERB_SUPERVISOR_RESET, "worker:worker") \
    X(OMX_VERB_SUPERVISOR_RESET, "target:" PHD_WORD_ALL) \
    X(OMX_VERB_PROPERTY_SET, "instance:int symbol:word value:quoted-escaped")

/** @brief an example word of each leaf type of PHD_ARG_TYPES, as rows X(name, example)
 *
 * A test writes sample lines and replies from them (#19).
 *
 * @param X the macro each row is passed to.
 */
#define PHD_ARG_EXAMPLES(X) \
    X("int", "3") X("uint", "2") X("hex", "0x28") X("word", "gain") X("worker", "w3") X("instances", "3,4") \
    X("instance-or-none", "8") X("status", "signal:11") X("suspect", "suspect:12") X("chain", "4.1") \
    X("reasons", "7:budget") X("placement", "own") X("member", "7" PHD_WORKER_PIN_REFUSED) X("worker-or-none", "w2") \
    X("state", "up") X("place", "chain:4.1") X("amount", "1024") X("number", "-6.02") \
    X("sha256", "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08") X("quoted", "\"/var/lib/x.json\"") X("quoted-escaped", "\"Sala \\\"A\\\" \\\\ 1\"") \
    X("key", "crashed") X("value", "0") X("line", "{\"name\":\"warm\"}") X("core", "2") \
    X("estimate-verdict", PHD_ESTIMATE_VERDICT_WARN) X("estimate-reason", PHD_ESTIMATE_REASON_RAM_UNKNOWN)

/* The composite types (#19): a list is items of one type joined by a separator, or one of its none words (a|b, "" for
 * none); a record is named fields joined by a separator, its fields name:type as PHD_EVENT_ARGS writes them. The
 * table carries each with a pattern written from its parts, so a reader of patterns alone reads it as a word.
 * X(name, item, separator, none, spelling) and X(name, separator, fields, spelling) */
/** @brief the list types of the table, as rows X(name, item, separator, none, spelling)
 *
 * A list is items of one type joined by a separator, or one of its none words.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_LIST_TYPES(X) \
    X("members", "member", ",", PHD_WORD_NONE, "the instances a worker holds, in order") \
    X("instance-list", "uint", ",", PHD_WORD_NONE, "instance numbers, in order") \
    X("core-list", "core", ",", "", "each member's core, in the segment's order") \
    X("segments", "instance-list", ";", "", "a plan's segments, each its instances") \
    X("core-segments", "core-list", ";", "", "each segment's cores") \
    X("reason-list", "reason", ",", PHD_WORD_NONE, "each member's reason") \
    X("member-codes", "member-code", ",", PHD_WORD_NONE, "each member with no figure: its position and its code") \
    X("history", "history-entry", ",", PHD_WORD_NONE "|" PHD_WORD_UNAVAILABLE, \
      "a plugin's history: digest, class, crashed, raises_xruns and the history keys; " PHD_WORD_UNAVAILABLE \
      " while the history file is blocked")
/** @brief the record types of the table, as rows X(name, separator, fields, spelling)
 *
 * A record is named fields joined by a separator.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_RECORD_TYPES(X) \
    X("worker-record", ":", "worker:worker pid:int format:" PHD_FORMAT_LV2 "|" PHD_FORMAT_CLAP "|" PHD_FORMAT_LV2_CLAP \
      " state:state core:" PHD_WORD_NONE " pool:" PHD_WORKER_POOL_ON "|" PHD_WORKER_POOL_QUALIFIED \
      " place:place instances:members", "a worker of worker_list") \
    X("reason", ":", "instance:int reason:word", "a member and its reason") \
    X("member-code", ":", "position:uint code:int", "a member's position in the line and its code") \
    X("layout", PHD_PIN_SCHEME_SEPARATOR, "scheme:word sha256:sha256", "a layout pin, <scheme>:<sha256>") \
    X("point", ",", "x:number y:number", "a point of a curve") \
    X("history-entry", "=", "key:key value:value", "a key=value of a history")

/** @brief the replies of this tree's verbs, typed and named (#19), as rows X(verb, resp, args)
 *
 * resp is 0, or count when the reply's number counts (the words a last repeated argument gives, when it has one); args
 * are written as PHD_EVENT_ARGS writes them, a last one name:type... repeated over the rest of the line.
 *
 * A verb has one row: one reply form.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_REPLY_ARGS(X) \
    X(OMX_VERB_WORKER_LIST, "count", "workers:worker-record...") \
    X(OMX_VERB_INSTANCE_INFO, "0", "worker:worker pid:int state:state crashes:uint quarantined:uint") \
    X(OMX_VERB_PIN_LAYOUT, "0", "layout:layout") \
    X(OMX_VERB_CHAIN_GET, "0", "worker:worker-or-none members:instance-list running:instance-list") \
    X(OMX_VERB_DESCRIPTOR_GET, "0", "path:quoted") \
    X(OMX_VERB_PANEL_GET, "0", "path:quoted") \
    X(OMX_VERB_PRESET_LIST, "count", "") \
    X(OMX_VERB_PRESET_GET, "0", "load_key:word name:line") \
    X(OMX_VERB_PROPERTY_INFO, "0", "symbol:word kind:word access:word name:quoted-escaped") \
    X(OMX_VERB_PROPERTY_GET, "0", "value:quoted-escaped") \
    X(OMX_VERB_PRESET_SHOW, "0", "json:line") \
    X(OMX_VERB_HISTORY_GET, "0", "history:history") \
    X(OMX_VERB_PLAN, "0", "segments:segments cores:core-segments") \
    X(OMX_VERB_PLAN_GET, "0", "segments:segments reasons:reason-list cores:core-segments") \
    X(OMX_VERB_ESTIMATE, "0", "latency_frames:uint cpu_percent:number ram_bytes:amount workers:uint unknown_count:uint " \
      "unknown:member-codes ram_used_bytes:amount ram_added_bytes:amount ram_budget_bytes:amount ram_unknown_count:uint " \
      "verdict:estimate-verdict reason:estimate-reason") \
    X(OMX_VERB_HELLO, "0", "version:int extensions:word...") \
    X(OMX_VERB_PARAM_GET_MANY, "0", "values:word...") \
    X(OMX_VERB_CURVE_POINTS, "0", "count:uint points:point...")

/** @brief the printf format of the PHD_EVENT_WORKER_DIED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_WORKER_DIED_FMT           PHD_EVENT_WORKER_DIED " w%d %d %s %s"
/** @brief the printf format of the PHD_EVENT_INSTANCE_VERB_DROPPED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_VERB_DROPPED_FMT          PHD_EVENT_INSTANCE_VERB_DROPPED " %d %s"
/** @brief the printf format of the PHD_EVENT_INSTANCE_VERB_DROPPED line, with the suspect word
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_VERB_DROPPED_SUSPECT_FMT  PHD_EVENT_INSTANCE_VERB_DROPPED " %d " PHD_EVENT_SUSPECT_PREFIX "%d %s"
/** @brief the printf format of the PHD_EVENT_WORKER_BACKOFF line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_WORKER_BACKOFF_FMT        PHD_EVENT_WORKER_BACKOFF " w%d %d"
/** @brief the printf format of the PHD_EVENT_WORKER_RESPAWNED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_WORKER_RESPAWNED_FMT      PHD_EVENT_WORKER_RESPAWNED " w%d %d %d %d"
/** @brief the printf format of the PHD_EVENT_INSTANCE_RESTORED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_INSTANCE_RESTORED_FMT     PHD_EVENT_INSTANCE_RESTORED " %d w%d"
/** @brief the printf format of the PHD_EVENT_INSTANCE_REPLAY_REFUSED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_REPLAY_REFUSED_FMT        PHD_EVENT_INSTANCE_REPLAY_REFUSED " %d %d"
/** @brief the printf format of the PHD_EVENT_INSTANCE_QUARANTINED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_INSTANCE_QUARANTINED_FMT  PHD_EVENT_INSTANCE_QUARANTINED " %d w%d"
/** @brief the printf format of the PHD_EVENT_SUPERVISOR_GAVE_UP line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_SUPERVISOR_GAVE_UP_FMT    PHD_EVENT_SUPERVISOR_GAVE_UP " w%d %d %d"
/** @brief the printf format of the PHD_EVENT_REMOTE_PAGES_CHANGED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_REMOTE_PAGES_CHANGED_FMT  PHD_EVENT_REMOTE_PAGES_CHANGED " %d"
/** @brief the printf format of the PHD_EVENT_REMOTE_PAGE_SUGGEST line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_REMOTE_PAGE_SUGGEST_FMT   PHD_EVENT_REMOTE_PAGE_SUGGEST " %d %u"
/** @brief the printf format of the PHD_EVENT_PARAM_GESTURE line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_PARAM_GESTURE_FMT         PHD_EVENT_PARAM_GESTURE " %d %s %s"
/** @brief the printf format of the PHD_EVENT_XRUNS line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_XRUNS_FMT                 PHD_EVENT_XRUNS " %llu"
/** @brief the printf format of the PHD_EVENT_PARAM_SET line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_PARAM_SET_FMT             PHD_EVENT_PARAM_SET " %d %s %s"
/** @brief the printf format of the PHD_EVENT_PIN_CHANGED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_PIN_CHANGED_FMT           PHD_EVENT_PIN_CHANGED " %s %s"
/** @brief the printf format of the PHD_EVENT_LV2_ADAPTER_REFUSED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_LV2_ADAPTER_REFUSED_FMT   PHD_EVENT_LV2_ADAPTER_REFUSED " %s %s %s"
/** @brief the printf format of the PHD_EVENT_CHAIN_FORMED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_CHAIN_FORMED_FMT          PHD_EVENT_CHAIN_FORMED " %s w%d %s"
/** @brief the printf format of the PHD_EVENT_CHAIN_REFUSED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_CHAIN_REFUSED_FMT         PHD_EVENT_CHAIN_REFUSED " %s %d"
/** @brief the printf format of the PHD_EVENT_CHAIN_STALLED line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_CHAIN_STALLED_FMT         PHD_EVENT_CHAIN_STALLED " %s %s %s %d"
/** @brief the printf format of the PHD_EVENT_PLAN_REASON line
 *
 * The event word and its arguments are in one literal.
 */
#define PHD_EVENT_PLAN_REASON_FMT           PHD_EVENT_PLAN_REASON " %d %s"
/** @brief the format of the feedback line of qualify_requested, its one word the plugin's uri */
#define PHD_EVENT_QUALIFY_REQUESTED_FMT     PHD_EVENT_QUALIFY_REQUESTED " %s"

/** @brief the table of the docs: X(name, fields, meaning), one row per shape of a line
 *
 * @param X the macro each row is passed to.
 */
#define PHD_EVENTS(X) \
    X(PHD_EVENT_WORKER_DIED, "<worker> <pid> <exit:N | signal:N> <instance>,...", \
      "a worker died; the instances it held, or - for none") \
    X(PHD_EVENT_INSTANCE_VERB_DROPPED, "<instance> <the command as sent>", \
      "the command a worker died on, dropped from the ledger; or the add it died on, the add as the worker was given it, " \
      "which names the plugin, or the " OMX_VERB_PIN_EXPECT " of that add") \
    X(PHD_EVENT_INSTANCE_VERB_DROPPED, "<instance> " PHD_EVENT_SUSPECT_PREFIX "<ms> <the command as sent>", \
      "the last verb a worker answered when it died inside suspect_window_ms, <ms> the age of the reply") \
    X(PHD_EVENT_WORKER_BACKOFF, "<worker> <ms>", "the respawn waits this long") \
    X(PHD_EVENT_WORKER_RESPAWNED, "<worker> <pid> <replayed_count> <ms>", "a worker is back and its ledger replayed") \
    X(PHD_EVENT_INSTANCE_RESTORED, "<instance> <worker>", "an instance is back in a worker") \
    X(PHD_EVENT_INSTANCE_REPLAY_REFUSED, "<instance> <code>", \
      "a replayed add was refused, by its pin or by the worker, <code> the refusal's own: no worker holds the " \
      "instance until the next replay") \
    X(PHD_EVENT_INSTANCE_QUARANTINED, "<instance> <worker>", \
      "the culprit of a pool or a chain death, placed own until cleared; a chain goes on without it") \
    X(PHD_EVENT_CHAIN_FORMED, "<chain> <worker> <instance>,...", \
      "a chain's worker is up with these members, in this order, after its declaration, a respawn or a member's " \
      "quarantine; " PHD_WORD_NONE " for none. <chain> is the number chain declared, or <plan>" PHD_PLACE_PLAN_SEPARATOR \
      "<k> for segment k of a plan") \
    X(PHD_EVENT_CHAIN_REFUSED, "<chain> <code>", \
      "a chain's worker would not run the members as one chain, <code> its own answer, and its stderr says why: " \
      "the chain is forgotten and each member runs in a worker of its own. <chain> as " PHD_EVENT_CHAIN_FORMED " names it") \
    X(PHD_EVENT_CHAIN_STALLED, "<chain> <instance | -> <step> <code>", \
      "a chain, or a plan's segment, has not formed within chain_form_timeout_ms of its declaration: the member and the " \
      "step that held it (spawn, add, pin, state, memory) and the code it answered, 0 for none, - for no one member; " \
      "said once each time it is declared or gathered again, and the daemon goes on trying") \
    X(PHD_EVENT_PLAN_REASON, "<chain> <instance>:<reason>,...", \
      "a plan of the chain changed: the reasons " OMX_VERB_PLAN_GET " answers now, after the segments, " PHD_WORD_NONE " for none") \
    X(PHD_EVENT_QUALIFY_REQUESTED, "<uri>", \
      "a plugin with no verdict was added under require_pins with pin_mode first-use: its insert is bypassed, no worker " \
      "holds it, and one request for its quick qualification is in the spool (" PHD_QUALIFY_SPOOL_DIR "); said at most " \
      "once for a plugin until a verdict lands") \
    X(PHD_EVENT_SUPERVISOR_GAVE_UP, "<worker> <deaths> <window_ms>", "the storm bound is spent; respawning ends") \
    X(PHD_EVENT_PIN_CHANGED, "<uri> " PHD_PIN_CHANGED_FILES " | " PHD_PIN_CHANGED_LAYOUT, \
      "an add or a replay of a plugin was refused because its files, or the layout the worker found, differ from its " \
      "pin; the pin is as it was until pin_accept or pin_set") \
    X(PHD_EVENT_LV2_ADAPTER_REFUSED, "<uri> <reason> " PHD_LV2_WORKER_CLAP_HOST, \
      "the LV2 adapter of the " PHD_FORMAT_LV2_CLAP " worker refused a plugin: <reason> is the hosting.* code after -102 on the " \
      "worker's reply to that add (" PHD_WORD_NONE " when it named none); the last word is the lv2_worker in force, " \
      PHD_LV2_WORKER_CLAP_HOST ", and the add is answered " PHD_STR(OMX_REPLY_PLUGIN_HOSTD_LV2_ADAPTER_REFUSED_RESP)) \
    X(PHD_EVENT_REMOTE_PAGES_CHANGED, "<instance>", \
      "relayed from a worker: the plugin changed its remote pages; read them again") \
    X(PHD_EVENT_REMOTE_PAGE_SUGGEST, "<instance> <page_id>", \
      "relayed from a worker: the plugin suggests the remote page of that id (a page_id of " OMX_VERB_REMOTE_PAGE_GET \
      "); a surface may follow it") \
    X(PHD_EVENT_PARAM_GESTURE, "<instance> <symbol> " PHD_GESTURE_BEGIN " | " PHD_GESTURE_END, \
      "relayed from a worker: the user took hold of a control of the plugin's own, or let it go; a controller writes no " \
      "automation of that parameter in between. The values the plugin moves meanwhile, or at any time by itself, are " \
      "mod-host's param_set feedback lines, relayed as written. A gesture whose worker died, or whose instance was " \
      "removed, before its " PHD_GESTURE_END " is ended by the daemon, before the worker_died event") \
    X(PHD_EVENT_XRUNS, "<count>", \
      "relayed from a worker, and read by the daemon: the JACK xruns the worker has counted since it started, written " \
      "when the count changes and at most once a second; a worker that never writes it counted none. The daemon takes " \
      "the first count of a worker as its baseline and, at the close of each history window, adds the window to " \
      "xrun_windows_solo or xrun_windows_grouped of every member of the worker when the count rose in it; a line that " \
      "is not the word and one whole number is not a count") \
    X(PHD_EVENT_ABI_CLOBBER, "<instance> <mask> <registers> <call> <block>", \
      "relayed from a worker (omx-clap-host 0.26.2 or later), and read by the daemon: the plugin returned from a call " \
      "with a callee-saved register changed, said once per instance. The worker put the registers back, so its own " \
      "frame is whole; the other members' state in the same process is not covered, so the daemon quarantines the " \
      "instance (instance_quarantined, and the history keeps it alone from then on) and, when it shares its worker or " \
      "is in a chain, moves it to a worker of its own with its state saved; one already alone is only marked") \
    X(PHD_EVENT_PARAM_SET, "<instance> <symbol> <value>", \
      "relayed from a worker: parameter feedback, a value the plugin moved by itself (its automation, an LFO, a " \
      "preset load, a MIDI map, the user's knob of the plugin's own), as mod-host writes it; a controller updates its " \
      "control to it. A worker never writes it for a value a controller's param_set gave it, and a worker that writes " \
      "none changes nothing: the daemon adds no line of its own")

/** @brief the arguments of each row of PHD_EVENTS, in its order, as rows X(name, args)
 *
 * (plugin-hostd-protocol#17) args is each argument name:type, its type one of PHD_ARG_TYPES or the literal words it is,
 * a|b. It is a table of its own, so PHD_EVENTS keeps the arguments its consumers expand it with; the generator holds
 * the two to the same rows.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_EVENT_ARGS(X) \
    X(PHD_EVENT_WORKER_DIED, "worker:worker pid:int status:status instances:instances") \
    X(PHD_EVENT_INSTANCE_VERB_DROPPED, "instance:int command:line") \
    X(PHD_EVENT_INSTANCE_VERB_DROPPED, "instance:int suspect:suspect command:line") \
    X(PHD_EVENT_WORKER_BACKOFF, "worker:worker ms:int") \
    X(PHD_EVENT_WORKER_RESPAWNED, "worker:worker pid:int replayed:int ms:int") \
    X(PHD_EVENT_INSTANCE_RESTORED, "instance:int worker:worker") \
    X(PHD_EVENT_INSTANCE_REPLAY_REFUSED, "instance:int code:int") \
    X(PHD_EVENT_INSTANCE_QUARANTINED, "instance:int worker:worker") \
    X(PHD_EVENT_CHAIN_FORMED, "chain:chain worker:worker instances:instances") \
    X(PHD_EVENT_CHAIN_REFUSED, "chain:chain code:int") \
    X(PHD_EVENT_CHAIN_STALLED, "chain:chain instance:instance-or-none step:word code:int") \
    X(PHD_EVENT_PLAN_REASON, "chain:int reasons:reasons") \
    X(PHD_EVENT_QUALIFY_REQUESTED, "uri:word") \
    X(PHD_EVENT_SUPERVISOR_GAVE_UP, "worker:worker deaths:int window_ms:int") \
    X(PHD_EVENT_PIN_CHANGED, "uri:word changed:" PHD_PIN_CHANGED_FILES "|" PHD_PIN_CHANGED_LAYOUT) \
    X(PHD_EVENT_LV2_ADAPTER_REFUSED, "uri:word reason:word lv2_worker:" PHD_LV2_WORKER_CLAP_HOST) \
    X(PHD_EVENT_REMOTE_PAGES_CHANGED, "instance:int") \
    X(PHD_EVENT_REMOTE_PAGE_SUGGEST, "instance:int page_id:uint") \
    X(PHD_EVENT_PARAM_GESTURE, "instance:int symbol:word gesture:" PHD_GESTURE_BEGIN "|" PHD_GESTURE_END) \
    X(PHD_EVENT_XRUNS, "count:uint") \
    X(PHD_EVENT_ABI_CLOBBER, "instance:int mask:hex registers:word call:word block:uint") \
    X(PHD_EVENT_PARAM_SET, "instance:int symbol:word value:word")

/* ---------------------------------------------------------------- worker feedback, relayed */

/** @brief the arguments a worker is started with
 *
 * A worker is started with a command port and a feedback port of its own, both on loopback and private to it.
 */
#define PHD_WORKER_ARGUMENTS "-n -p <command port> -f <feedback port>"
/** @brief the option a worker of a plugin whose pin carries pool=cores is started with, after those
 *
 * Every other worker keeps no option, the worker's qualified, which grants the pool to no plugin. worker_list names
 * which with these words.
 */
#define PHD_WORKER_THREAD_POOL_ON "--thread-pool=on"
/** @brief the word worker_list gives for a worker started with the thread pool on */
#define PHD_WORKER_POOL_ON        "on"
/** @brief the word worker_list gives for a worker that keeps no pool option
 *
 * It is started without the thread pool option, and the pool is granted to none of its plugins.
 */
#define PHD_WORKER_POOL_QUALIFIED "qualified"

/** @brief what the daemon does with the lines a worker writes on its feedback port: X(id, meaning)
 *
 * @param X the macro each row is passed to.
 */
#define PHD_RELAY(X) \
    X(VERBATIM, "every line a worker writes on its feedback port goes out on the daemon's feedback port as the worker " \
                "wrote it: output_set, param_set, data_finish and the rest of mod-host's feedback, and a line the daemon " \
                "does not know") \
    X(INSTANCE, "the instance number in a relayed line is already the controller's: " PHD_VERB_ADD " hands it to the " \
                "worker unchanged, so nothing in a line is rewritten") \
    X(ORDER, "a worker's lines go out in the order it wrote them, and what a worker wrote before it died goes out " \
             "before its " PHD_EVENT_WORKER_DIED " event; an instance lives in one worker at a time, so its lines keep " \
             "their order across a respawn; the lines of different workers interleave") \
    X(SUBSCRIPTION, "monitor_output is in the ledger, one line per output, until monitor_output_off or the end of " \
                    "the connection that set it takes the line out, and param_monitor as it was sent; a " \
                    "respawn replays them after the " PHD_VERB_ADD ", so a respawned instance reports the same outputs, " \
                    "each once, starting again from its first value") \
    X(HANDSHAKE, "output_data_ready names no instance and goes to every worker; each worker's data_finish is relayed") \
    X(WINDOW, PHD_VERB_SHOW_EXTERNAL_UI " and " OMX_VERB_HIDE_EXTERNAL_UI " go to the worker that holds the instance " \
              "and its resp comes back unchanged; the window is the worker's, on the display session of the daemon's " \
              "environment (WAYLAND_DISPLAY, else DISPLAY), which every worker inherits; a daemon with neither refuses " \
              "both with -902 " PHD_EXTERNAL_UI_NO_DISPLAY " and sends the worker nothing; the ledger keeps the latest " \
              "of the two per instance, so a respawn shows again a window that was shown") \
    X(NO_CONTROLLER, "with no feedback port, or no controller on it, a line is dropped, as mod-host drops it; the " \
                     "daemon reads every worker's feedback all the time, so no worker waits on it")

/* ---------------------------------------------------------------- settings */

#include <plugin-hostd/search_paths.h>

/** @brief the default of the mod_host setting */
#define PHD_DEFAULT_MOD_HOST          "mod-host"
/** @brief the default of the clap_host setting */
#define PHD_DEFAULT_CLAP_HOST         "omx-clap-host"
/** @brief the default of the lv2_worker setting, omx-clap-host
 *
 * The LV2 isolated tier is omx-clap-host's adapter; mod-host runs a plugin only when lv2_worker or lv2_worker_set names
 * it.
 */
#define PHD_DEFAULT_LV2_WORKER        PHD_LV2_WORKER_CLAP_HOST
/** @brief the default of the state_root setting */
#define PHD_DEFAULT_STATE_ROOT        "/tmp"
/** @brief the default of the ready_timeout_ms setting */
#define PHD_DEFAULT_READY_TIMEOUT_MS  5000
/** @brief the default of the rpc_timeout_ms setting */
#define PHD_DEFAULT_RPC_TIMEOUT_MS    5000
/** @brief the default of the backoff_base_ms setting */
#define PHD_DEFAULT_BACKOFF_BASE_MS   250
/** @brief the default of the backoff_max_ms setting */
#define PHD_DEFAULT_BACKOFF_MAX_MS    5000
/** @brief the default of the storm_deaths setting */
#define PHD_DEFAULT_STORM_DEATHS      5
/** @brief the default of the storm_window_ms setting */
#define PHD_DEFAULT_STORM_WINDOW_MS   60000
/** @brief the default of the suspect_window_ms setting */
#define PHD_DEFAULT_SUSPECT_WINDOW_MS 500
/** @brief the default of the checkpoint_ms setting */
#define PHD_DEFAULT_CHECKPOINT_MS     5000
/** @brief the default of the chain_form_timeout_ms setting */
#define PHD_DEFAULT_CHAIN_FORM_TIMEOUT_MS 10000
/** @brief the default of the idle_ms setting */
#define PHD_DEFAULT_IDLE_MS           25
/** @brief the default of the pool_max setting */
#define PHD_DEFAULT_POOL_MAX          8
/** @brief the default of the grouping setting */
#define PHD_DEFAULT_GROUPING          PHD_GROUPING_OFF
/** @brief the default of the placement setting */
#define PHD_DEFAULT_PLACEMENT         PHD_CORE_PLACEMENT_SPREAD
/** @brief the default of the bind_address setting */
#define PHD_DEFAULT_BIND_ADDRESS      "127.0.0.1"
/* starting values of the planner's limits; the benchmark sets the ones a release ships (the design note, The benchmark) */
/** @brief the default of the ram_budget_mb setting */
#define PHD_DEFAULT_RAM_BUDGET_MB     0
/** @brief the default of the group_max setting */
#define PHD_DEFAULT_GROUP_MAX         8
/** @brief the default of the group_cost_max setting */
#define PHD_DEFAULT_GROUP_COST_MAX    60
/** @brief the default of the group_rate setting */
#define PHD_DEFAULT_GROUP_RATE        48000
/** @brief the default of the group_quantum setting */
#define PHD_DEFAULT_GROUP_QUANTUM     128
/** @brief the default of the require_pins setting */
#define PHD_DEFAULT_REQUIRE_PINS      1
/** @brief the default of the pin_mode setting */
#define PHD_DEFAULT_PIN_MODE          PHD_PIN_MODE_FIRST_USE
/** @brief the default of the pins_dir setting */
#define PHD_DEFAULT_PINS_DIR          "/usr/share/plugin-hostd/pins.d"
/** @brief the default of the probe setting */
#define PHD_DEFAULT_PROBE             "plugin-hostd-probe"
/** @brief the default of the history_window_s setting */
#define PHD_DEFAULT_HISTORY_WINDOW_S  60
/** @brief the default of the history_save_s setting */
#define PHD_DEFAULT_HISTORY_SAVE_S    300
/** @brief the default of the history_regroup_s setting */
#define PHD_DEFAULT_HISTORY_REGROUP_S 600

/* The running history (the grouping-planner design note, The history record): what each plugin did on
 * this machine, one line per <uri> <binary digest> <host class> in a file of the daemon's own, whose keys are the words
 * of PLUGIN_HOSTD_HISTORY_KEYS (domain plugin-hostd/history, contract.d/plugin-hostd/history/history.json). The first line is PHD_HISTORY_HEADER; the file is local, mode 0600,
 * and only the daemon writes it. The summary history_get answers reads crashes within PHD_HISTORY_KEEP_DAYS of
 * last_crash, and marks a plugin raises_xruns once it has PHD_HISTORY_MIN_WINDOWS grouped windows and its share of xrun
 * windows grouped exceeds its share solo by PHD_HISTORY_XRUN_MARGIN_PCT percentage points, or exceeds
 * PHD_HISTORY_XRUN_MARGIN_PCT percent when it never ran alone. */
/** @brief the name of the history file under the state home, which the history_file setting defaults to */
#define PHD_HISTORY_NAME              "plugin-hostd/history"
/** @brief the first line of the history file */
#define PHD_HISTORY_HEADER            "# plugin-hostd history/1"
/** @brief the word each record line of the history file starts with
 *
 * The line is "history \<uri\> \<digest\> \<class\>", then its keys; plugin-hostd writes the lines and reads back only
 * lines that start with it.
 */
#define PHD_HISTORY_RECORD            "history"
/** @brief the days after last_crash within which the summary history_get answers still reads a crash */
#define PHD_HISTORY_KEEP_DAYS         30
/** @brief the grouped windows a plugin needs before it can be marked raises_xruns */
#define PHD_HISTORY_MIN_WINDOWS       30
/** @brief the percentage points of xrun windows grouped over solo that mark a plugin raises_xruns
 *
 * A plugin is marked when its share of xrun windows grouped exceeds its share solo by this many points, or exceeds this
 * many percent when it never ran alone.
 */
#define PHD_HISTORY_XRUN_MARGIN_PCT   5

/* The directories of what the scan of an add gathers: state, kept across a reboot. An empty setting is the default:
 * <state home>/<subdir>, where the state home is $XDG_STATE_HOME, else /var/lib for a daemon run as root (a system
 * service), else $HOME/.local/state. A missing directory is made, mode 0700; one that cannot be written stops the daemon with OMX_REPLY_PLUGIN_HOSTD_DIR_NOT_WRITABLE_RESP. */
/** @brief the subdirectory of the state home that descriptor_dir defaults to */
#define PHD_DIR_DESCRIPTORS_SUBDIR    "omx/descriptors"
/** @brief the state home of a daemon run as root, when XDG_STATE_HOME is not set */
#define PHD_DIR_SYSTEM_STATE_HOME     "/var/lib"
/** @brief the state home of any other daemon, relative to $HOME, when XDG_STATE_HOME is not set */
#define PHD_DIR_USER_STATE_HOME       ".local/state"
/** @brief the mode a missing directory is made with */
#define PHD_DIR_MODE                  0700
/** @brief the text of the default of a directory setting, for the subdirectory subdir
 *
 * @param subdir the subdirectory, a string literal.
 */
#define PHD_DIR_DEFAULT_TEXT(subdir) \
    "empty is $XDG_STATE_HOME/" subdir ", else " PHD_DIR_SYSTEM_STATE_HOME "/" subdir " run as root (a system " \
    "service), else $HOME/" PHD_DIR_USER_STATE_HOME "/" subdir

/* A scanned descriptor's file in descriptor_dir: <id>@<version>-<hash>.json, the rule plugin-qualify's scanners name
 * theirs by. The id is the CLAP plugin id or the LV2 URI, the version the one the descriptor states
 * (PHD_DESCRIPTOR_NO_VERSION when it states none), each byte of their UTF-8 text outside [A-Za-z0-9._-] written
 * PHD_DESCRIPTOR_SAFE_CHAR, one for each byte ("é" is "__"); the hash is the first PHD_DESCRIPTOR_HASH_LEN hex digits of the SHA-256 of the plugin's
 * binary (the .clap, or the file the LV2 bundle's manifest names with lv2:binary). Written once, atomically; a changed
 * binary gets a new name and the old file stays. */
/** @brief the name of a scanned descriptor's file in descriptor_dir: \<id\>@\<version\>-\<hash\>.json */
#define PHD_DESCRIPTOR_NAME_SYNTAX    "<id>@<version>-<hash>.json"
/** @brief the version written in the name when the descriptor states none */
#define PHD_DESCRIPTOR_NO_VERSION     "unversioned"
/** @brief the character written for each byte of the id or the version outside [A-Za-z0-9._-] */
#define PHD_DESCRIPTOR_SAFE_CHAR      '_'
/** @brief the hex digits of the SHA-256 of the plugin's binary that the name holds */
#define PHD_DESCRIPTOR_HASH_LEN       12

/** @brief the subdirectory of descriptor_dir that holds the panel files
 *
 * Each is under its descriptor's name, written by the same scan after the descriptor, once and atomically
 * (docs/panel.md).
 */
#define PHD_PANEL_SUBDIR              "panels"
/** @brief the path of a plugin's panel file in descriptor_dir: PHD_PANEL_SUBDIR and the name of its descriptor */
#define PHD_PANEL_NAME_SYNTAX         PHD_PANEL_SUBDIR "/" PHD_DESCRIPTOR_NAME_SYNTAX

/* The panel file's keys, one JSON object: X(key, required, since, meaning). A key that is not required is additive: a
 * file written before its since has none, and a reader that does not know it reads the file as before. meters holds
 * the plugin's clap.meters/1 meters whose id a display of the panel names in its meterIds, in the plugin's order, each
 * a row of the shape the descriptor's meters[] has (omx-contract docs/descriptors.md: id, symbol, kind, channels,
 * unit, min, max, scale), the same id and the same values descriptor_get's file gives it: every meter id a display
 * names is the id of one row, so the file resolves its own displays, and a reader reads one meter shape. */
/** @brief the key of the panel file that holds the plugin's meters */
#define PHD_PANEL_KEY_METERS          "meters"
/** @brief the keys of the panel file, one JSON object, as rows X(key, required, since, meaning)
 *
 * A key that is not required is additive: a file written before its since has none.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_PANEL_FILE_KEYS(X) \
    X("plugin", 1, "0.5.0", "the plugin, {\"format\": \"clap\" | \"lv2\", \"id\": <its id or URI>}") \
    X("panel", 1, "0.5.0", "the panel object (org.openmixer.panel-description/1) omx-clap-scan --json prints for the " \
      "plugin, byte for byte; null when it serves none, and for an LV2 plugin") \
    X(PHD_PANEL_KEY_METERS, 0, "0.5.10", "the clap.meters/1 meters the panel's displays index (a display's " \
      "meterIds), in the plugin's order, each a row of the descriptor's meters[] shape ({id, symbol, kind, channels, " \
      "unit, min, max, scale}), with the id and the values " OMX_VERB_DESCRIPTOR_GET "'s file gives it; empty when " \
      "the panel is null or its displays index none. A display naming a meter id no row carries is never written")

/** @brief the string settings, as rows X(key, size, default, env, meaning)
 *
 * The settings file holds one "key value" per line, and '#' starts a comment.
 *
 * env names the variable that stands in for the default when it is set and not empty, "" for none; size is path or
 * pathlist, the storage class of the daemon's copy.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_CONF_STRINGS(X) \
    X(mod_host, path, PHD_DEFAULT_MOD_HOST, "", "worker for " PHD_FORMAT_LV2 " (a name on PATH or a path)") \
    X(clap_host, path, PHD_DEFAULT_CLAP_HOST, "", "worker for " PHD_FORMAT_CLAP) \
    X(lv2_worker, word, PHD_DEFAULT_LV2_WORKER, "", "who runs an LV2 plugin: omx-clap-host (the clap_host program, through " \
      "its LV2 adapter, a plugin it cannot run refused with a code), mod-host (the mod_host program, only when named here or " \
      "by " OMX_VERB_LV2_WORKER_SET "); a plugin the one in force refuses is never handed to the other; " \
      OMX_VERB_LV2_WORKER_SET " overrides it for one plugin") \
    X(lv2_path, pathlist, PHD_DEFAULT_LV2_PATH, "LV2_PATH", "where bundles are searched") \
    X(lv2_extra, pathlist, "", "", "the site's own bundle folders, searched after lv2_path: the one declaration of them, " \
      "which plugin-qualify and omx-panel read too") \
    X(clap_path, pathlist, PHD_DEFAULT_CLAP_PATH, "", "where .clap files are searched by whoever searches (plugin-qualify, " \
      "omx-panel); an add names its file, so the daemon loads none by search; $CLAP_PATH is searched before it") \
    X(state_root, path, PHD_DEFAULT_STATE_ROOT, "XDG_RUNTIME_DIR", "the daemon's checkpoints and worker logs") \
    X(pin_mode, word, PHD_DEFAULT_PIN_MODE, "", "strict or first-use, while require_pins is 1: first-use records the pin " \
      "of a plugin on its first add, strict admits only a plugin a controller, a pin_file or pins_dir pinned") \
    X(grouping, word, PHD_DEFAULT_GROUPING, "", "off or on: whether plan applies its plan (a run of consecutive members " \
      "that may share a worker is declared as a chain), or only answers it; the default stays off until the benchmark " \
      "has published a win") \
    X(bind_address, word, PHD_DEFAULT_BIND_ADDRESS, "", "the IPv4 address the command and feedback ports listen on: this " \
      "machine alone by default; 0.0.0.0 is every address of the machine, and a controller is not authenticated, so widen " \
      "it only on a network whose hosts are trusted; --bind-address overrides it") \
    X(placement, word, PHD_DEFAULT_PLACEMENT, "", "spread or none (docs/placement.md): spread pins each new worker to the " \
      "audio core with the least load, the sum of the qualification costs of the workers already on it, or their number " \
      "while one of them has a member of unknown cost, the lowest core of a tie, and keeps the daemon, its threads and " \
      "the scans it forks on the reserved cores; a worker keeps its core across respawns, and one whose format " \
      OMX_VERB_WORKER_ENV " gave a cpu list is not placed; none pins nothing; --placement overrides it") \
    X(audio_cores, word, "", "", "the cpus the placement spreads the workers over, a cpu list inside the daemon's own " \
      "affinity (\"1-3\"); empty is that affinity less its lowest cpu; the reserved cores are the rest of it") \
    X(pin_store, path, "", "", "the file first-use pins are kept in; empty is $XDG_STATE_HOME/plugin-hostd/pins, " \
      "else $HOME/.local/state/plugin-hostd/pins") \
    X(pin_file, path, "", "", "a file of pin lines loaded at start, as plugin-qualify --all --pins writes it; empty is none") \
    X(pins_dir, path, PHD_DEFAULT_PINS_DIR, "", "the read-only pins of packages: every file in it whose name ends in .pins, read at start " \
      "in name order, under the store, the pin_file and pin_set, except that a pin of verdict=refused there holds over them " \
      "until the user's pin_accept; " \
      "empty is none") \
    X(descriptor_dir, path, "", "OMX_DESCRIPTOR_DIR", "the scanned descriptors, one file per plugin binary (" \
      PHD_DESCRIPTOR_NAME_SYNTAX ", the hash the binary's SHA-256), written by the scan of an add and read by " OMX_VERB_DESCRIPTOR_GET "; " \
      PHD_DIR_DEFAULT_TEXT(PHD_DIR_DESCRIPTORS_SUBDIR) "; its variable is for tests only") \
    X(probe, path, PHD_DEFAULT_PROBE, "", "the scanner an add runs, as <probe> describe <target>, in a child of its " \
      "own once per plugin binary; its stdout is the descriptor") \
    X(history_file, path, "", "", "the running history: what each plugin did on this machine, kept per plugin, binary and " \
      "host class; empty is $XDG_STATE_HOME/" PHD_HISTORY_NAME ", else $HOME/.local/state/" PHD_HISTORY_NAME "; local to " \
      "this machine, mode 0600, written by the daemon alone, and deleted by history_clear") \
    X(host_class, word, "", "", "the host class the history is kept under, as arch/cores/clock (x86_64/5-8/2.5-3.5GHz); " \
      "empty is the class of this machine, as the probe writes it; no white space")

/** @brief the whole-number settings, as rows X(key, default, unit, meaning)
 *
 * 0 turns the setting off where the meaning says so.
 *
 * @param X the macro each row is passed to.
 */
#define PHD_CONF_INTS(X) \
    X(ready_timeout_ms, PHD_DEFAULT_READY_TIMEOUT_MS, "ms", "a worker that does not accept in this long is a failed spawn") \
    X(rpc_timeout_ms, PHD_DEFAULT_RPC_TIMEOUT_MS, "ms", "a silent worker gets SIGTERM after this long, SIGKILL 2 s later") \
    X(backoff_base_ms, PHD_DEFAULT_BACKOFF_BASE_MS, "ms", "respawn backoff, doubling per death in the window") \
    X(backoff_max_ms, PHD_DEFAULT_BACKOFF_MAX_MS, "ms", "the most a respawn backoff grows to") \
    X(storm_deaths, PHD_DEFAULT_STORM_DEATHS, "deaths", "deaths inside the window that end respawning of a placement") \
    X(storm_window_ms, PHD_DEFAULT_STORM_WINDOW_MS, "ms", "the window storm_deaths are counted in") \
    X(suspect_window_ms, PHD_DEFAULT_SUSPECT_WINDOW_MS, "ms", \
      "a worker that dies this soon after a reply drops the verb it answered; 0 turns it off") \
    X(checkpoint_ms, PHD_DEFAULT_CHECKPOINT_MS, "ms", "a quiet interval with a changed ledger writes a checkpoint") \
    X(chain_form_timeout_ms, PHD_DEFAULT_CHAIN_FORM_TIMEOUT_MS, "ms", \
      "a chain or a plan's segment that has not formed in this long is said with chain_stalled; 0 turns it off") \
    X(idle_ms, PHD_DEFAULT_IDLE_MS, "ms", "the period of the idle tick: reap, respawn, checkpoint") \
    X(pool_max, PHD_DEFAULT_POOL_MAX, "instances", "instances in a pool before a sibling opens") \
    X(history_window_s, PHD_DEFAULT_HISTORY_WINDOW_S, "s", \
      "the length of one history window: a worker's CPU and memory are read and folded into the history of its plugins " \
      "once per window, and a window the plugin was up less than half of is not counted; 0 keeps no history") \
    X(history_save_s, PHD_DEFAULT_HISTORY_SAVE_S, "s", "the history is written at most once this often when it changed, " \
      "and at quit") \
    X(history_regroup_s, PHD_DEFAULT_HISTORY_REGROUP_S, "s", \
      "a plan whose group was split by a death that named no culprit is made again after this many seconds without " \
      "another death of its members, and the members that share are gathered in a worker again; 0 never makes it again " \
      "by itself") \
    X(ram_budget_mb, PHD_DEFAULT_RAM_BUDGET_MB, "MiB", "the memory this host gives its plugins, which estimate answers beside what they hold; 0 for no budget set") \
    X(group_max, PHD_DEFAULT_GROUP_MAX, "instances", "most members of one segment of a plan; 0 sets no limit") \
    X(group_cost_max, PHD_DEFAULT_GROUP_COST_MAX, "percent of a core", \
      "most the costs of the members of one segment of a plan add to, each a member's coreFractionP95 of its " \
      "qualification record at group_rate and group_quantum; a member over it alone stays alone; 0 sets no limit") \
    X(group_rate, PHD_DEFAULT_GROUP_RATE, "Hz", "the sample rate the cost of a member is read at") \
    X(group_quantum, PHD_DEFAULT_GROUP_QUANTUM, "frames", "the quantum the cost of a member is read at") \
    X(require_pins, PHD_DEFAULT_REQUIRE_PINS, "", \
      "1: add admits only a plugin that has a pin (see pin_mode), its files hashed before any worker sees it, and a plugin of a " \
      "format whose pin holds only in a world of its own gets a worker of its own, its world the plugin's files (a " \
      PHD_PLACE_DEFAULT " that resolves to a pool is placed " PHD_PLACE_OWN "); 0: no pin is checked")

#endif
