/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
 *
 * omx_chorus_instance.h — the native chorus as a plugin instance: the shell's core, with no
 * format in it. The same shape as omx-plugins' omx_delay_instance.h (one C core, N shells): the core is
 * `omx_chorus.h`'s `omx_chorus_process`, THE SAME INLINE the console's chorus stage runs, and
 * this file adds no DSP to it. It adds what a host's port model needs and the atom does not carry:
 *
 *   1. RINGS. `struct omx_chorus_state` reads two rings; the instance OWNS them, inline, sized for
 *      the deepest sweep at the highest rate the kernel admits (OMX_CHORUS_CAP per leg), and arms
 *      the kernel over the first omx_chorus_instance_cap_for(sr) floats of each. Nothing is
 *      allocated, at init or after; a rate the console does not declare is refused at init.
 *   2. RESOLVE. omx_chorus_instance_resolve() takes the kernel's contract controls in their
 *      declared order and user units (turns, Hz, ms, a voice count, percent) and turns them into
 *      the atom, the same conversions resolve_fx_chorus (mixer_rt.c) makes, with every knob
 *      clamped through omx_param into the declared travel (CHORUS_*_RANGE,
 *      omxdsp_definitions.h): a foreign host's port is not the console's codec, and a non-finite
 *      word reads as the declared default.
 *   3. IN -> OUT. The kernel works IN PLACE; run() copies in to out where they differ (they may
 *      alias) and runs the kernel on out. Identity when bypassed or not ready.
 *
 * Re-engaging from bypass CLEARS the rings and restarts the oscillator, so a re-enabled chorus
 * does not replay a tail buffered before the bypass. LATENCY IS ZERO: the dry path is
 * frame-aligned with the input.
 *
 * No mutable globals: every word of state is in the caller's {@link OmxChorusInstance}. The state
 * points into the instance's own rings, so an instance is initialised where it lives and is never
 * copied after init.
 */
/**
 * @file omx_chorus_instance.h
 * @brief the native chorus as a plugin instance: the shell's core, with no format in it. The same shape as omx-plugins' omx_delay_instance.h (one C core, N shells): the core is `omx_chorus.h`'s `omx_chorus_process`, THE SAME INLINE the console's chorus stage runs, and this file adds no DSP to it.
 */
#ifndef OMX_CHORUS_INSTANCE_H
#define OMX_CHORUS_INSTANCE_H

#include <stdint.h>
#include <string.h>

#include <omxdsp/fx/omx_chorus.h>
#include <omxdsp/fx/omx_instance_io.h>
#include <omxdsp/omx_param.h>

/** The face's channel count: a stereo pair over one atom. */
#define OMX_CHORUS_INSTANCE_CHANNELS 2
/** The frames of latency the face introduces: none. */
#define OMX_CHORUS_INSTANCE_LATENCY_FRAMES 0.0f

/* Port defaults: the declaration's (CHORUS_*_RANGE.default). */
/** The voice count a non-finite word reads as: CHORUS_VOICES_RANGE's default. */
#define OMX_CHORUS_INSTANCE_VOICES_DEFAULT ((float)OMX_CHORUS_VOICES_RANGE_DEFAULT)
/** The depth a non-finite word reads as, ms: CHORUS_DEPTH_RANGE's default. */
#define OMX_CHORUS_INSTANCE_DEPTH_MS_DEFAULT ((float)OMX_CHORUS_DEPTH_RANGE_DEFAULT)
/** The rate a non-finite word reads as, Hz: CHORUS_RATE_RANGE's default. */
#define OMX_CHORUS_INSTANCE_RATE_HZ_DEFAULT ((float)OMX_CHORUS_RATE_RANGE_DEFAULT)
/** The mix a non-finite word reads as, percent: CHORUS_MIX_RANGE's default. */
#define OMX_CHORUS_INSTANCE_MIX_PCT_DEFAULT ((float)OMX_CHORUS_MIX_RANGE_DEFAULT)
/** The spread a non-finite word reads as, turns: CHORUS_SPREAD_RANGE's default. */
#define OMX_CHORUS_INSTANCE_SPREAD_DEFAULT ((float)OMX_CHORUS_SPREAD_RANGE_DEFAULT)

/** One instance. It owns its rings; the kernel is armed over the first `cap` floats of each. */
typedef struct {
  float sr;                      /**< The sample rate the instance is bound to, Hz. */
  struct omx_chorus atom;        /**< The kernel's atom as last resolved. */
  struct omx_chorus_state state; /**< The kernel's state over the instance's rings. */
  float ring_l[OMX_CHORUS_CAP];  /**< The left delay line, the instance's own. */
  float ring_r[OMX_CHORUS_CAP];  /**< The right delay line, the instance's own. */
  uint32_t cap;                  /**< How many floats of each ring the kernel is armed over: omx_chorus_instance_cap_for(). */
  /** The previous cycle's engaged flag, so a bypass->engaged edge can clear the rings. */
  int was_engaged;
  int ready;                     /**< 1 after a successful omx_chorus_instance_init(); 0 makes run() the identity. */
} OmxChorusInstance;

/** @brief The ring, per leg, the deepest sweep needs at `sr`: the floats of each inline ring the kernel uses.
 * @param sr The sample rate, Hz.
 * @return The ring length, floats; above OMX_CHORUS_CAP when the inline rings cannot hold the sweep.
 * @thread audio */
static inline uint32_t omx_chorus_instance_cap_for(float sr) {
  return omx_fdelay_cap_for((OMX_CHORUS_BASE_MS + OMX_CHORUS_MAX_DEPTH_MS) * 0.001f * sr,
                            OMX_CHORUS_ORDER);
}

/**
 * @brief Bind an instance to its rate, over its own rings. Allocates nothing.
 * @param s The instance; every word of it is written.
 * @param sr The sample rate, Hz, one the console declares.
 * @return 1 when usable, 0 when not: a rate that is not declared, or whose sweep the inline rings
 *         cannot hold, is refused, `ready` stays clear and run() is the identity.
 * @thread control
 */
static inline int omx_chorus_instance_init(OmxChorusInstance *s, float sr) {
  if (!omx_instance_bind(s, sizeof(*s), sr)) return 0;
  const uint32_t cap = omx_chorus_instance_cap_for(sr);
  if (cap > OMX_CHORUS_CAP) return 0;
  s->sr = sr;
  s->cap = cap;
  s->ready = omx_chorus_state_init(&s->state, s->ring_l, s->ring_r, cap) == OMX_FDELAY_OK;
  return s->ready;
}

#define OMX_CONTRACT_STAGE "chorus/instance-clear"
/** @brief Clear the rings and restart the oscillator — the re-enable recipe. A bounded memset over the
 * instance's own rings, no allocation.
 * @param s The instance; null or not ready is ignored.
 * @thread audio */
static inline void omx_chorus_instance_clear(OmxChorusInstance *s) {
  if (!s || !s->ready) return;
  omx_instance_rings_clear(s->ring_l, s->ring_r, s->cap);
  (void)omx_chorus_state_init(&s->state, s->ring_l, s->ring_r, s->cap);
  OMX_POST(s->ring_l[0] == 0.0f && s->ring_r[s->cap - 1u] == 0.0f && s->state.lfo.phase == 0.0f,
           "cleared-ring-is-silent");
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "chorus/instance-resolve"
/**
 * @brief Resolve the host's control-port values into the kernel's atom for one cycle. The arguments are
 * the kernel's contract controls, in their declared order and user units, each clamped into its
 * declared travel, a non-finite word reading as the declared default. A null or not-ready instance is
 * refused and nothing changes.
 * @param s The instance.
 * @param bypass Non-zero disables the atom: run() is then the identity.
 * @param spread The voices' phase spread, turns, inside CHORUS_SPREAD_RANGE.
 * @param rate The modulation rate, Hz, inside CHORUS_RATE_RANGE.
 * @param depth The modulation depth, ms, inside CHORUS_DEPTH_RANGE.
 * @param voices The voice count, rounded to 1..OMX_CHORUS_MAX_VOICES.
 * @param mix The wet share, percent, inside CHORUS_MIX_RANGE.
 * @post The atom satisfies every precondition of the chorus kernel.
 * @thread audio
 */
static inline void omx_chorus_instance_resolve(OmxChorusInstance *s, int bypass, float spread,
                                               float rate, float depth, float voices, float mix) {
  if (!s || !s->ready) return;
  /* CONTRACT (omx_contract.h). The atom this leaves behind satisfies every PRE
   * omx_chorus_process states, whatever the host's ports held. */
  const int engaged = bypass ? 0 : 1;
  if (engaged && !s->was_engaged) omx_chorus_instance_clear(s);
  s->was_engaged = engaged;
  struct omx_chorus *o = &s->atom;
  o->enabled = engaged;
  const float v = omx_clamp_or(voices, (float)OMX_CHORUS_VOICES_RANGE_MIN,
                               (float)OMX_CHORUS_VOICES_RANGE_MAX, OMX_CHORUS_INSTANCE_VOICES_DEFAULT);
  o->voices = (int)(v + 0.5f);
  o->base_samples = OMX_CHORUS_BASE_MS * 0.001f * s->sr;
  o->depth_samples = omx_clamp_or(depth, (float)OMX_CHORUS_DEPTH_RANGE_MIN,
                                  (float)OMX_CHORUS_DEPTH_RANGE_MAX,
                                  OMX_CHORUS_INSTANCE_DEPTH_MS_DEFAULT) *
                     0.001f * s->sr;
  o->lfo_inc = omx_lfo_inc(omx_clamp_or(rate, (float)OMX_CHORUS_RATE_RANGE_MIN,
                                        (float)OMX_CHORUS_RATE_RANGE_MAX,
                                        OMX_CHORUS_INSTANCE_RATE_HZ_DEFAULT),
                           s->sr);
  o->mix = 0.01f * omx_clamp_or(mix, (float)OMX_CHORUS_MIX_RANGE_MIN,
                                (float)OMX_CHORUS_MIX_RANGE_MAX, OMX_CHORUS_INSTANCE_MIX_PCT_DEFAULT);
  o->spread = omx_clamp_or(spread, (float)OMX_CHORUS_SPREAD_RANGE_MIN, OMX_CHORUS_SPREAD_MAX,
                           OMX_CHORUS_INSTANCE_SPREAD_DEFAULT);
  OMX_POST(o->voices >= 1 && o->voices <= OMX_CHORUS_MAX_VOICES && o->mix >= 0.0f &&
               o->mix <= 1.0f && o->spread >= 0.0f && o->spread <= OMX_CHORUS_SPREAD_MAX &&
               o->depth_samples >= 0.0f && o->lfo_inc >= 0.0f && o->lfo_inc < 1.0f &&
               o->base_samples + o->depth_samples <=
                   omx_fdelay_max_delay(s->state.line_l.cap, s->state.line_l.order),
           "atom-meets-the-kernel-preconditions");
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "chorus/instance-run"
/**
 * @brief THE AUDIO CALLBACK'S WHOLE SHARE: copy in to out where they differ, run the console's kernel
 * in place on out. `in_*` and `out_*` may alias. Not ready, or bypassed, is the identity.
 * @param s The instance; null, not ready or bypassed copies in to out.
 * @param in_l The left input, `n` frames.
 * @param in_r The right input, `n` frames.
 * @param out_l The left output, `n` frames, may be `in_l`.
 * @param out_r The right output, `n` frames, may be `in_r`.
 * @param n The block length, frames; a null port or 0 touches nothing.
 * @thread audio
 */
static inline void omx_chorus_instance_run(OmxChorusInstance *s, const float *in_l,
                                           const float *in_r, float *out_l, float *out_r,
                                           uint32_t n) {
  OMX_INSTANCE_RUN_IN_PLACE(s, in_l, in_r, out_l, out_r, n, omx_chorus_process(out_l, out_r, n, &s->atom, &s->state));
}
#undef OMX_CONTRACT_STAGE

#endif /* OMX_CHORUS_INSTANCE_H */
