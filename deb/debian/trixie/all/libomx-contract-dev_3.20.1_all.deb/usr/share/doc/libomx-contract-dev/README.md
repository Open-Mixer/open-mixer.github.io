<!-- SPDX-License-Identifier: GPL-3.0-or-later -->
<!-- Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com> -->
# omx-contract

The OpenMixer declarations as data: what a value may be (a travel, a default, a kernel constant, a list),
written once as JSON, checked by a JSON Schema and rendered into the languages that read it (a C header,
TypeScript, resolved JSON). The mixer engine, the DSP library and the plugins all take their ranges, defaults and
constants from the same definitions, so a knob means the same thing on the console, in a plugin and in a test.

## Install

Fedora 44:

```
sudo dnf install https://www.openmixer.org/rpm/openmixer-release.noarch.rpm
sudo dnf install omx-contract-devel
```

Debian bookworm and trixie (also Raspberry Pi OS and Zynthian):

```
cd /tmp && curl -fsSLO https://www.openmixer.org/deb/openmixer-release.deb && sudo apt install ./openmixer-release.deb
sudo apt update && sudo apt install libomx-contract-dev
```

JavaScript and TypeScript: `npm install @openmixer/omx-contract` (the CLI is `omx-contract`).

Python: `python3-omx-contract` (rpm and deb), the package `omx_contract` with the catalog, scale and CLAP readers.

## Start

```c
#include <omxcontract/omx_contract_limits.h>
```

```
cc -c app.c $(pkg-config --cflags omx-contract)
omx-contract render --target json --installed     # every declaration in the contract directory
```

```python
import omx_contract.catalog
import omx_contract.scale

ca = omx_contract.catalog.load_catalog("plugin-db", "ca")   # an owner's installed Catalan catalog
omx_contract.scale.scale_position({"scale": "log", "min": 20, "max": 20000}, 1000)   # 0.5663
```

## Documentation

<https://www.openmixer.org/projects/omx-contract>, `man omx-contract`, and in this repository: what the package
holds, pinning a version and where each subject is ([docs/overview.md](docs/overview.md)); building
([BUILDING.md](BUILDING.md)). The installed C headers are documented for doxygen, every public declaration from the
item that declares it; `make doxygen-check` holds the undocumented ones to a baseline that only shrinks
([docs/render.md](docs/render.md) "Documentation").

## Licence

GPL-3.0-or-later. See [LICENSE](LICENSE).
