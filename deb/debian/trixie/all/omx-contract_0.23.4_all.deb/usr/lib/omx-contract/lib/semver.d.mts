/**
 * The development-phase rule: while every consumer of
 * omx-contract is an OpenMixer repository named here, removing an item is MINOR. The rule ends, and
 * this becomes null so a removal is MAJOR again, in the release that names the first consumer
 * outside the list. Until then a MAJOR class is released as a minor bump (see refusal).
 */
export declare const DEVELOPMENT_PHASE: Readonly<{
    consumers: readonly string[];
}>;
/** `{ level, changes: [{ level, item, what }] }` from `prev` to `next` (Maps name -> resolved item). */
export declare function classify(prev: any, next: any, { developmentPhase }?: {
    developmentPhase?: Readonly<{
        consumers: readonly string[];
    }> | undefined;
}): {
    level: any;
    changes: any[];
};
/**
 * The changes between two schema documents (parsed JSON), `{ level, changes }` with changes `{ level, item: 'schema', what }`.
 * A file that was valid must stay valid under the same major: a property, definition or enum member removed, a
 * required member added, a constraint added or changed (pattern, const, type, bounds, additionalProperties) is
 * major (MINOR in the development phase, as an item's removal is, see refusal); a property, definition or enum
 * member added, or a required member dropped, is minor; a description is patch. `x-omx-schema-version` is the
 * version, not a change.
 */
export declare function classifySchema(prev: any, next: any): {
    level: any;
    changes: any[];
};
/** The class of the bump from version `from` to `to`: 'major' | 'minor' | 'patch' | 'none'; throws if `to` is lower. */
export declare function bumpOf(from: any, to: any): string;
/**
 * null when bumping `from` -> `to` covers `level`, else the refusal. In the development phase no
 * release takes a major bump (decided 2026-10-13: majors wait for the first public
 * release), so a MAJOR class is covered by a minor bump; the classes are still reported as found.
 */
export declare function refusal(level: any, from: any, to: any, { developmentPhase }?: {
    developmentPhase?: Readonly<{
        consumers: readonly string[];
    }> | undefined;
}): string | null;
/**
 * What is wrong with the version a schema states, against the schema at the last tag: `x-omx-schema-version` is the
 * omx-contract release that last changed the vocabulary (docs/contract-dir.md), so a changed schema states a newer one, by
 * what its changes need, in the commit that changes it. null when it is right.
 */
export declare function schemaVersionProblem(prev: any, next: any): string | null;
