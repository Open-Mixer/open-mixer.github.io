/** The contract directories, in the order they are read: `$OMX_CONTRACT_PATH`, else omx-contract's `contractdir`,
 * else the default. */
export function contractDirs(): string[];
/** The directory `<contractdir>/3/<package>` of the first contract directory that holds it, or undefined. */
export function packageDir(pkg: any): string | undefined;
/** The directories the panel domain is opened from: `$OMX_CONTRACT_PATH`, this tree's `contract.d`, then omx-contract's
 * `contractdir` (where omx-panel-contract installs it); the first that holds `panel/panel.json` wins. */
export function panelDomainDirs(): string[];
/** omx-contract's own data directory: its pkg-config `datadir`, else the default. */
export function contractDataDir(): string;
/** The installed omx-contract schema, where the descriptor words are declared. */
export function contractSchemaFile(): string;
/** The meaning role `role` plays, or undefined: a role no package declares, one declared `unknown`, or one whose meaning
 * the installed schema does not list plays none, whatever its name (a role is looked up, never read as a meaning). */
export function meaningOfRole(role: any): any;
/** omx-contract's param domain document, `<contractdir>/param/param.json`, from the first contract directory holding it. */
export function paramDomainFile(): string | undefined;
/** The file that declares it: the first JSON file of the merged contract directory that holds the item (omx-contract's
 * `3/omx-contract/param-contract.json`, from omx-contract-data 3.6.0), found like every other item. */
export function paramUnitsFile(): string | undefined;
/** A standard id the param-contract extension serves (`none` is): the sheet gives its LV2 term a value, or, as main read
 * a unit of the extension's own, the id by name (dBFS -> DBFS) is a unit of its vendor block. An id's `-` is its symbol's
 * `/`, read "per" as the sheet spells it (dB-oct -> DBPEROCT, the sheet's dbPerOct). */
export function servedUnit(id: any): boolean;
/** The descriptor file a package installed into omx-contract's contract directory, `<package>/<name>`:
 * `<contractdir>/3/<package>/plugins/<name>.json`. */
export function installedDescriptorFile(ref: any): string;
/** Every descriptor file installed under the contract directories, sorted: `<contractdir>/<major>/<package>/plugins/*.json`,
 * whatever majors are installed. A `<package>/<name>` installed under several majors or directories is listed once,
 * from the highest major of the first contract directory that holds it. */
export function installedDescriptorFiles(): any[];
/** A panel domain item's words by title (`PANEL_GROUP_REASONS` -> `{ noControls: 'no-controls', ... }`): the codes and
 * words the tools emit, read from the panel domain; a title the item lacks is refused by name, never undefined. */
export function panelCodes(item: any): Readonly<{
    [k: string]: string;
}>;
/** Where omx-contract-data installs its files and the contract directory, for an install with no omx-contract.pc. */
export const DEFAULT_DATADIR: "/usr/share/omx-contract";
export const DEFAULT_CONTRACTDIR: "/usr/share/omx-contract/contract.d";
export function panelWords(item: any): string[];
export function meanings(): any;
export function roleMeanings(): any;
export function standardUnits(): any;
export function unitIdOf(unit: any): any;
export function unitsOfDimensions(dimensions: any): any[];
/** The sheet of the param-contract units is omx-contract's: OMX_PARAM_CONTRACT_UNITS, in its param-contract.json. */
export const PARAM_UNITS_ITEM: "OMX_PARAM_CONTRACT_UNITS";
export function paramUnits(): any;
export function lv2UnitTerms(): any;
