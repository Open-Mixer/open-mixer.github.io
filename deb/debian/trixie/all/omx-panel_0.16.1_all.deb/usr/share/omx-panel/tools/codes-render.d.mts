/** Every rendered file of the domain at `dir` (a contract directory holding panel/): `{ <path in the tree>: <text> }`. */
export function renderAll(dir?: string): {
    'schema/codes.json': string;
};
export const CONTRACT_DIR: string;
/** The items the sheet is made of, in the sheet's order. */
export const SHEET_ITEMS: string[];
