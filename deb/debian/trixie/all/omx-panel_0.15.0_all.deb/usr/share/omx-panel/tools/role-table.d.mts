/**
 * Each family's roles and the unit tokens each accepts (the param-contract extension's tokens).
 * @type {Readonly<Record<PanelFamily, Readonly<Record<string, readonly string[]>>>>}
 */
export const ROLES: Readonly<Record<PanelFamily, Readonly<Record<string, readonly string[]>>>>;
/**
 * The roles that repeat by index, one control per band: schema/panel.schema.json's `$defs.indexedRole`.
 * @type {readonly string[]}
 */
export const INDEXED_ROLES: readonly string[];
/**
 * The roles each family needs mapped (at index 0) before a host draws its family view: a list of
 * alternatives, each met by any ONE of its roles. `none` draws no family view.
 * @type {Readonly<Record<PanelFamily, readonly (readonly string[])[]>>}
 */
export const REQUIRED_ROLES: Readonly<Record<PanelFamily, readonly (readonly string[])[]>>;
/** The dynamics family's roles, the words of a dynamics control (`threshold`, `ratio`, `attack`, `release`): from REQUIRED_ROLES, never typed twice. */
export const DYNAMICS_ROLES: readonly string[];
/** The words a dynamics control is called by in a name: the roles, and the knee and the short forms (`thresh`, `comp`). The group model reads them. */
export const DYNAMICS_WORDS: readonly string[];
export type PanelFamily = "none" | "gate" | "dynamics" | "limiter" | "deesser" | "eq" | "filter" | "drive" | "modulation" | "delay" | "reverb" | "pitch";
