/**
 * The path and text parameters a descriptor declares (#17): an LV2 plugin's patch:writable lv2:Parameters, as a scan
 * writes them under `extensions.lv2["patch:writable"]` ({ uri, label, range }, and a `symbol` where a host names it), served
 * as `{ kind: 'path' | 'text', symbol, name, default }`: the symbol is the one stated, else the parameter URI's fragment
 * (else its last segment), the name its label, the
 * default empty. One of another range is not served: it is listed apart (`unserved`, its symbol and range), for a refusal.
 */
export function textParamsOf(descriptor: any): {
    served: {
        kind: any;
        symbol: any;
        name: any;
        default: string;
    }[];
    unserved: {
        symbol: any;
        range: any;
    }[];
};
/**
 * The classes and features the descriptor carries as the plugin states them: its extension bag, `extensions.lv2` (a class
 * as a field, `lv2:CompressorPlugin`, or among `rdf:type`'s values) and `extensions.clap`
 * (`clap_plugin_descriptor.features`). A scan spells a CLAP feature by its macro (`CLAP_PLUGIN_FEATURE_EQUALIZER`, the format
 * table's term), a declaration by its string (`equalizer`): the macro is read as the string it stands for.
 */
export function declaredOf(descriptor: any): string[];
/**
 * One control as the contract facts the description serves (§3.1 `params`). `factor`: the band inference reads it as a gain
 * in a linear factor, so a unit the descriptor leaves unstated is `coef`.
 */
export function servedParamOf(c: any, { factor }?: {
    factor?: boolean | undefined;
}): {
    kind: string;
    symbol: any;
    name: any;
    min: number;
    max: number;
} | {
    enumLabels?: any[] | undefined;
    kind: string;
    symbol: any;
    name: any;
    unit: string;
    scale: string;
    step: number;
    min: number;
    max: number;
    default: number;
} | {
    scale: string;
    step: number;
    min: any;
    max: any;
    default: any;
    unitText?: any;
    kind: string;
    symbol: any;
    name: any;
    unit: any;
};
/**
 * The family and layout of a plugin that declares no panel and has no override naming one (§3.1.1). One candidate from the
 * plugin's declarations, kept when the layout under it maps every required role; two or more candidates give a family only
 * when exactly one of them is kept; none, or no kept one, is `none`.
 */
export function familyRule(descriptor: any, options: any): {
    family: any;
    layout: {
        origin: any;
        family: any;
        sections: any;
        controls: any;
        roles: any[];
        unpublished: {
            role: string | undefined;
            symbol: any;
            why: string;
        }[];
        displays: any;
        defaults: any;
        ports: {
            inputs: {
                id: any;
                name: any;
                role: any;
                channels: any;
            }[];
            outputs: {
                id: any;
                name: any;
                role: any;
                channels: any;
            }[];
            sidechain: boolean;
            notes: boolean;
        };
        easy: any[];
        meters: {
            declared: boolean;
            symbol: any;
            widget: string;
            kind: any;
            measurement: any;
            unit: any;
            min: any;
            max: any;
            channels: any;
            held: boolean;
            clip: boolean;
            label: any;
            labelKey: any;
        }[];
        meterRefusals: any[];
    };
} | undefined;
/**
 * The description of `descriptor` and the refusals, as the header says. `description` is null when no panel can be made
 * (no control, an invalid layout); a declared family the controls do not back is `none` with its refusal.
 */
export function describe(descriptor: any, { overrides, applyOverride, skin, panel, ns, where, perPage, remote, withLayout }?: {
    overrides?: never[] | undefined;
    withLayout?: boolean | undefined;
}): {
    description: null;
    refusals: {
        code: any;
        args: {};
    }[];
    layout?: undefined;
} | {
    description: {
        family: any;
        fingerprint: string;
        easy: any;
        params: any[];
        sections: any;
        controls: any[];
        meters: any;
        roles: any;
        displays: any;
    };
    refusals: {
        code: any;
        args: {};
    }[];
    layout: any;
} | {
    description: {
        family: any;
        fingerprint: string;
        easy: any;
        params: any[];
        sections: any;
        controls: any[];
        meters: any;
        roles: any;
        displays: any;
    };
    refusals: {
        code: any;
        args: {};
    }[];
    layout?: undefined;
};
export namespace DESCRIBE_CODES {
    let noControls: string;
    let familyNotBacked: string;
    let layoutInvalid: string;
    let overrideUnavailable: string;
    let overrideRefused: string;
    let overrideDropped: string;
    let roleDropped: string;
    let skinDropped: string;
    let meterRefused: string;
    let paramUnserved: string;
}
/** What a plugin declares about itself (an LV2 class, a CLAP feature) -> the family whose closed form omx-panel knows. */
export const FAMILY_OF_DECLARED: {
    'lv2:EQPlugin': string;
    'lv2:ParaEQPlugin': string;
    equalizer: string;
    'lv2:CompressorPlugin': string;
    compressor: string;
    'lv2:GatePlugin': string;
    'lv2:ExpanderPlugin': string;
    gate: string;
    'lv2:DistortionPlugin': string;
    distortion: string;
};
export function candidatesOf(descriptor: any): any[];
export function servedSymbolOf(c: any): any;
