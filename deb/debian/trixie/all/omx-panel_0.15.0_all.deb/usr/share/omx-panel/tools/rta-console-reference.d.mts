export const BANDS: {
    hz: number;
    db: number;
    peakDb: number;
}[];
export const CURVE: {
    hz: number;
    gain: number;
}[];
