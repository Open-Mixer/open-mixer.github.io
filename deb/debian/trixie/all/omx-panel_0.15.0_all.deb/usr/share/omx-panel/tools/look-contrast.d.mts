/** The selectors of `css` that set a text colour (`color`, or `fill` of a text element), the pedal's own scope removed. */
export function textRules(css: any): any[];
/**
 * The table: `{ look, rule, fg, plate, before, after }` per look and rule. `before` is the ratio in the console's flat look
 * (or the FLOOR for a strip that had none), `after` the lowest ratio of the look's text colour over every colour of its plate.
 * `override` ({plate: '#rrggbb'}) swaps a plate's colours, for a test. Colours are tools/look.json's, resolved.
 */
export function contrastTable({ override, looks, roles }?: {
    override?: {} | undefined;
    looks?: any;
    roles?: any;
}): {
    look: string;
    rule: string;
    fg: string;
    plate: string;
    stops: any;
    before: number;
    after: number;
}[];
/**
 * Every text rule: its selector (without the pedal's scope), the look token that sets its colour, the colour role it had in
 * the console's flat look, the plate it sits on and the role that plate was. A plate with no flat counterpart (the scribble
 * strip, new) is held to FLOOR, WCAG's AA for text.
 */
export const PAIRS: readonly ({
    rule: string;
    fg: string;
    fgWas: string;
    plate: string;
    was: string;
    floor?: undefined;
} | {
    rule: string;
    fg: string;
    plate: string;
    floor: number;
    fgWas?: undefined;
    was?: undefined;
})[];
/** WCAG AA for normal text. */
export const FLOOR: 4.5;
