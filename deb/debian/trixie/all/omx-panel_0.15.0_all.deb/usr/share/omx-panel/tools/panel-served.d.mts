/** Whether `x` is a served panel: the probe's file, or the scan's `panel` object (a fingerprint and control rows by paramId). */
export function isServedPanel(x: any): any;
/**
 * The declared panel the served panel `x` states, over `descriptor` (its parameters, keyed by `keyOf`); `indexedRoles`
 * are the roles that repeat by index (role-table.mjs INDEXED_ROLES). Throws, naming the fault, for what the header lists.
 */
export function declaredFromServed(x: any, descriptor: any, { where, keyOf, indexedRoles }: {
    where?: string | undefined;
    keyOf: any;
    indexedRoles?: never[] | undefined;
}): {
    visibleWhen?: {} | undefined;
    widgets?: {} | undefined;
    sections: {
        key: any;
        label: any;
        controls: any[];
    }[];
    roles: {};
    family?: any;
};
