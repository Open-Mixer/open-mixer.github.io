/** The four tokens of the console's vintage dark theme, read out of `css`: the first `--glass`, `--glass-grid` and `--legend` of the dark palette, and the orange accent (the default accent). */
export function extractTokens(css: any): {
    '--glass': any;
    '--glass-grid': any;
    '--legend': any;
    '--accent': any;
};
/** The finish blocks of `css`, each finish's metal: the aluminium one is `:root, :root[data-finish="aluminium"]`. */
export function extractFinishes(css: any): {
    [k: string]: {
        [k: string]: any;
    };
};
/** The console's default finish, read where the console sets it: the finish block whose selector is the bare `:root` too (`:root, :root[data-finish="x"]`). */
export function extractDefaultFinish(css: any): any;
/** The light theme's text inks, read out of `css`: `:root[data-theme="light"] { … }`. */
export function extractLight(css: any): {
    [k: string]: any;
};
/** Everything the pin keeps, read out of `css`: the glass, the relief, the base paint and every finish. */
export function extractPin(css: any): {
    tokens: {
        '--glass': any;
        '--glass-grid': any;
        '--legend': any;
        '--accent': any;
    };
    relief: {
        [k: string]: any;
    };
    base: {
        [k: string]: any;
    };
    light: {
        [k: string]: any;
    };
    defaultFinish: any;
    finish: {
        [k: string]: {
            [k: string]: any;
        };
    };
};
/** The faults of the pin against ITSELF, as sentences, or none: its values hash to the seal a re-pin wrote (`source.valuesSha256`). Needs no console and no network. */
export function checkSelf(pin?: any): string[];
/** Where a pinned token lives, for a sentence: a `[section, finish?, key]` of every value the pin keeps. */
export function pinnedValues(pin: any): {
    id: string;
    value: any;
}[];
/** The faults of the pin's VALUES against the tokens.css text `css`, as sentences, or none (the hash is checkPin's). */
export function diffPin(css: any, pin?: any): string[];
/** The faults of the pin against the tokens.css text `css`, as sentences, or none. */
export function checkPin(css: any, pin?: any): string[];
export const PIN_JSON: string;
/** The four tokens of the vintage glass the first pin carried (the pin's `tokens`). */
export const PINNED: string[];
/** The relief the console draws depth with (`:root`: the drop shadows, the inset track, the one black every shadow mixes toward). */
export const RELIEF: string[];
/** The base-layer control paint that no finish changes: the carved pointer, the fader's cream line, the cream legend on a cap. */
export const BASE: string[];
/** The hardware metal a finish block sets, and the finishes of the console (aluminium is the default, the bare `:root`). */
export const FINISH_KEYS: string[];
export const FINISHES: string[];
/** The console's text ink on a LIGHT plate (its light theme's `--ink` and `--ink-dim`): the vintage enclosure is a light plate, and its text is set in these. */
export const LIGHT_INK: string[];
export function loadPin(file?: string): any;
export function consoleTokens(pin?: any): any;
export function finishTokens(name: any, pin?: any): any;
export function valuesSha(pin: any): string;
