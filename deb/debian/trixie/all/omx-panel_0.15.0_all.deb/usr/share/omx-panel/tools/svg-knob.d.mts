/**
 * `text` with every placeholder set: `{--role}` from the look's tokens, `{console:--x}` and `{finish:--x}` from the console's pin
 * (`pinned`, as tools/look.json carries it, the finish being the look's own), `{angle}` and any other `{name}` of `extra`
 * (a fader's `capY`, and `{capY+n}` a point n below it) from the frame.
 */
export function resolveSvg(text: any, tokens: any, angle: any, pinned: any, extra?: {}): any;
/** The scene of an SVG text: gradients by id, and shapes in paint order with the rotations over them. */
export function parseSvg(source: any): {
    grads: Map<any, any>;
    shapes: {
        tag: any;
        a: any;
        rot: {
            a: number;
            cx: number;
            cy: number;
        }[];
    }[];
};
/**
 * The scene of a drawing of look.json (`drawings`, a JSON scene whose colours and angle are placeholders) for one frame, in the
 * shape parseSvg gives an SVG's: the placeholders set from the look's tokens, the console's pin and the frame's angle.
 */
export function resolveScene(drawing: any, tokens: any, angle: any, pinned: any): {
    grads: Map<any, any>;
    shapes: any;
};
/** The scene of `drawing` for one frame: a JSON scene of look.json, or the text of an SVG file (the drawings not moved there yet). */
export function sceneAt(drawing: any, tokens: any, angle: any, pinned: any, extra?: {}): {
    grads: Map<any, any>;
    shapes: any;
};
/** Paint the scene onto `c`, its origin at (ox, oy), `k` px per SVG unit. */
export function paintScene(c: any, scene: any, ox: any, oy: any, k: any): void;
/** A film strip: `frames` frames of `size` px, the knob of `drawing` (a scene, or SVG text) from -135 to +135 degrees, as a PNG. */
export function renderSvgFilm(drawing: any, tokens: any, frames: any, size: any, viewBox: number | undefined, pinned: any, extraOf?: () => {}): Buffer<ArrayBuffer>;
export function knobSvgFile(name: any): string;
export function drawingOf(look: any, name: any): any;
export function readKnobSvg(name: any): string;
