/** The band role a control plays, from its metadata alone; null for a control that is not a band control. */
export function bandRoleOf(c: any): "gain" | "type" | "freq" | "q" | "enable" | null;
/** A band's shape from its key and the names of its controls: an edge's long words in the names, its abbreviation as the key's prefix. */
export function shapeOfNames(key: any, names: any): string;
/** A shape word from a filter-type choice's label; undefined when the label is none of them. */
export function shapeOfLabel(label: any): string | undefined;
/**
 * A choice control's `shapes`: one shape word per choice value from 0 (`-` for a value whose label is none of
 * them), or undefined when none of its labels is a shape. A choice's value is its entry in `values`, else its place.
 */
export function shapesOf(c: any): string[] | undefined;
/** Infer `controls`' EQ bands. See the file's header for the verdict. */
export function inferBands(controls: any): {
    outcome: string;
    reason: string;
    roles?: undefined;
} | {
    outcome: string;
    roles: {
        inferred: boolean;
        role: string;
        index: number;
        symbol: any;
        unit: string;
    }[];
    reason?: undefined;
};
/** The band shapes a curve function knows, and `-` for a choice value that is none of them. */
export const SHAPES: string[];
/**
 * The EQ's words, ONE table (omx-panel#75): each parameter role's name words and each edge's (the filters and shelves an
 * EQ's outer columns are). This file owns it; the band inference here and the group model's rows and edges
 * (tools/group-model.mjs, docs/group-model.md S8, S9) both read it, and neither keeps a list of its own. A word of two
 * letters is an abbreviation: in the band inference an edge's is read as a symbol prefix (`hp_freq`), its longer words in the names.
 */
export const EQ_WORDS: Readonly<{
    roles: Readonly<{
        type: readonly string[];
        slope: readonly string[];
        freq: readonly string[];
        gain: readonly string[];
        q: readonly string[];
    }>;
    fallback: Readonly<{
        type: readonly string[];
        q: readonly string[];
    }>;
    edges: readonly (Readonly<{
        edge: "hpf";
        shape: "highpass";
        side: "left";
        words: readonly string[];
    }> | Readonly<{
        edge: "lowshelf";
        shape: "lowshelf";
        side: "left";
        words: readonly string[];
    }> | Readonly<{
        edge: "highshelf";
        shape: "highshelf";
        side: "right";
        words: readonly string[];
    }> | Readonly<{
        edge: "lpf";
        shape: "lowpass";
        side: "right";
        words: readonly string[];
    }>)[];
}>;
export function statesMeaning(c: any): boolean;
export namespace AFFIX {
    let enable: string[];
}
