// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
/*
 * panel-description.mjs — a plugin's panel laid out from its DESCRIPTOR (omx-contract's descriptor
 * words: each control's kind, travel with its unit and scale, choice ids, label, group and meaning, the
 * ports, the origin), so a plugin from any origin gets a layout (docs/panel-layout.md). A declared
 * panel, ours, adds the family, the sections, the order, the roles, the widgets, the graphs and the
 * per-placement come-up values on top. The result is org.openmixer.panel-description/1:
 * the family, the sections in order, one control per listed parameter, the roles its family takes, a
 * display per section `graph` the extension names, and the canonical serialisation whose SHA-256 is
 * the fingerprint. omx-plugins writes the rows its faces serve from it (its include/omx_panel_description.h)
 * and reads what a built face serves back against it. The descriptor is the only input: a declaration is
 * rendered to its descriptor by its owner first.
 *
 * The vocabulary below is the extension's: its families, each family's roles with the units a role
 * accepts, and the displays a family draws in closed form. A declaration's role the family has no
 * place for, or whose parameter's unit the role does not take, is not published (a host would drop
 * it and the fingerprint would no longer be what it reads); the generated header names each one.
 */
import { createHash } from 'node:crypto';
import { easyOf } from './easy.mjs';
import { barsOf } from './bars.mjs';
import { shapesOf, statesMeaning } from './meaning-infer.mjs';
import { declaredFromServed, isServedPanel } from './panel-served.mjs';
import { INDEXED_ROLES, REQUIRED_ROLES, ROLES } from './role-table.mjs';
import { meaningOfRole, servedToken, SLOPE_UNITS } from './vocabulary.mjs';

export const PANEL_ID = 'org.openmixer.panel-description/1';

/** The extension's families, by enum value. */
export const FAMILIES = ['none', 'gate', 'dynamics', 'limiter', 'deesser', 'eq', 'filter', 'drive', 'modulation', 'delay', 'reverb', 'pitch', 'utility'];

/** The widgets a face serves, by enum value. */
export const WIDGETS = ['auto', 'knob', 'fader', 'switch', 'selector'];

/** The standard widgets a panel picks from a descriptor; a representation (a skin) draws each. */
export const STANDARD_WIDGETS = ['knob', 'fader', 'switch', 'selector', 'meter', 'curve', 'xy', 'display'];
/** What a meter measures, the level kinds the descriptor spells (contract §7.9): `rms`, `vu` and
 * `ppm` are not words. */
export const MEASUREMENTS = ['peak', 'true-peak', 'lufs-m', 'lufs-s', 'lufs-i', 'lra'];
/** The units a read-only travel is a level meter in. */
const LEVEL_UNITS = ['dB', 'dBFS', 'dBTP', 'dBu', 'LUFS', 'LU'];
/** The units a level meter's clip word can be in: a digital clip, never a modelled one (contract §7.9). */
const CLIP_UNITS = ['dBFS', 'dBTP'];
/** A word that names the state of an analogue input stage (phantom power, a pad, a head amp): a meter is a measurement,
 * and a modelled value is never drawn as one, so a meter or a read-only control with such a name is refused by code. */
const ANALOGUE_WORD = /phantom|(^|[^a-z])pad([^a-z]|$)|head[-_ ]?amp|headamp/;
/** Whether `text` (a meaning in camelCase, a symbol, a name) names such a state, whole words only. */
export const namesAnalogueState = (text) => ANALOGUE_WORD.test(text.replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase());
export const METER_REFUSED = 'PANEL_METER_REFUSED';
/** A declared panel's widget names -> the standard widget. */
const DECLARED_WIDGET = { knob: 'knob', fader: 'fader', switch: 'switch', selector: 'selector' };
/** A standard widget -> the widget a face serves: a selector is AUTO (it needs CLAP_PARAM_IS_ENUM,
 * which the faces do not set), and so is any widget the extension has no value for. */
const SERVED_WIDGET = { knob: 'knob', fader: 'fader', switch: 'switch' };

/**
 * The standard widget control `c` (a descriptor control) is drawn with: `{ widget }`, a meter's with
 * its `measurement`, `held` and `clip`, a trigger's switch `momentary`. A declared widget wins; else a
 * read-only travel in a level unit is a meter and any other read-only control a display, a toggle or a
 * trigger a switch, a choice a selector, a travel a knob. A foreign meter (one inferred here, not read
 * from the descriptor's `meters` word) never guesses its measurement from the unit, and holds nothing
 * and clips nothing of its own (contract §7.9).
 */
export function widgetOf(c, declared) {
  if (declared !== undefined) return { widget: DECLARED_WIDGET[declared] ?? declared };
  if (c.readonly) {
    const unit = c.travel?.unit;
    return LEVEL_UNITS.includes(unit) ? { widget: 'meter', measurement: null, held: false, clip: false } : { widget: 'display' };
  }
  if (c.kind === 'toggle') return { widget: 'switch' };
  if (c.kind === 'trigger') return { widget: 'switch', momentary: true };
  if (c.kind === 'choice') return { widget: 'selector' };
  return { widget: 'knob' };
}

/** The widget a face serves for a standard widget. */
export const servedWidget = (standard) => SERVED_WIDGET[standard] ?? 'auto';

/** The display kinds and sources, by enum value. */
export const DISPLAY_KINDS = ['gain_reduction_bar', 'transfer_curve', 'eq_response', 'meter', 'time_response'];
export const DISPLAY_SOURCES = ['family', 'meters', 'gain_adjustment', 'curve'];
/** The origins a band may be planted under besides the operator's `user`: the closed set the console's band origins name. */
export const BAND_ORIGINS = ['fbs-fixed', 'fbs-live', 'hrp', 'room-mode'];
export const PLACEMENTS = ['insert', 'return', 'bus', 'master'];

/** A section `graph` -> the display the extension names for it; a graph word with none here is
 * refused by name when the panel is described (a declaration error, never a silent drop). */
export const DISPLAY_OF_GRAPH = {
  'eq-curve': 'eq_response', 'dynamics-curve': 'transfer_curve', 'transfer-curve': 'transfer_curve',
  // the time response (the processing-view spec, amendment 2026-09-16h): a delay's tap train and a reverb's decay envelope
  // are one kind, x time in ms from 0, y level in dB with the floor at -60; the graph words stay the section's vocabulary
  'delay-taps': 'time_response', 'decay-envelope': 'time_response',
};
/** The basis of a declared section's graph: `exact` only when an authored descriptor says so (the one-panel spec §5.3), else `modelled`. */
export const basisOf = (descriptor, section) => (section.basis === 'exact' && descriptor.origin === 'authored' ? 'exact' : 'modelled');

/** The displays a host computes from a family's roles in closed form. */
const CLOSED_FORMS = { gate: ['transfer_curve'], dynamics: ['transfer_curve'], eq: ['eq_response'], drive: ['transfer_curve'], delay: ['time_response'], reverb: ['time_response'] };

/** A descriptor unit -> the token a role checks it against: the param-contract extension's own table,
 * so a unit it serves is a unit a role can take. A unit it has no token for (`unknown` among them) is
 * a plain number and takes no role. */
export const unitToken = (unit) => servedToken(unit);

/** Each family's roles and the units each accepts, and the roles that repeat by index: tools/role-table.mjs's, the
 * one table, data a browser loads as it is. */
export { INDEXED_ROLES, ROLES };

/**
 * The meanings each family stands on, in the order inference tries them: `backs`, one of which a
 * declared family needs among its controls' meanings (null: none yet has a word, a rotor's speeds and
 * an LFO's shape have no meaning); `infer`, the sets of meanings any one of which, all present, makes
 * a plugin with no declared panel that family.
 */
export const FAMILY_MEANINGS = {
  limiter: { backs: ['ceiling'], infer: [['ceiling']] },
  deesser: { backs: ['frequency', 'threshold'], infer: [['frequency', 'threshold', 'listen']] },
  gate: { backs: ['threshold'], infer: [['threshold', 'range']] },
  dynamics: { backs: ['threshold', 'ratio'], infer: [['threshold', 'ratio']] },
  eq: { backs: ['gain', 'frequency'], infer: [['frequency', 'gain', 'q']] },
  filter: { backs: ['cutoffFrequency'], infer: [['cutoffFrequency']] },
  drive: { backs: ['drive'], infer: [['drive']] },
  delay: { backs: ['delay'], infer: [['delay', 'feedback']] },
  reverb: { backs: ['size', 'decay'], infer: [['size'], ['decay']] },
  pitch: { backs: ['shift'], infer: [['shift']] },
  modulation: { backs: null, infer: [['rate', 'depth']] },
};

/**
 * The family of a plugin whose controls are `controls` (descriptor controls): `{ family }`, and for a
 * declared family none of its controls' meanings backs, `{ family, needs }` naming what it lacks. With
 * no declared family, an effect takes the first family whose meanings it carries; an instrument, or a
 * plugin no family fits, is none.
 */
export function familyOf(controls, declared, features = [], roles = {}) {
  const have = new Set(controls.filter(statesMeaning).map((c) => c.meaning));
  // a declared panel's roles back the family too (#43): a control the panel binds to a role, whose own meaning the
  // descriptor leaves unstated (a scan writes `unknown`), carries the role's meaning; a stated meaning is the descriptor's
  for (const [role, syms] of Object.entries(roles ?? {})) {
    const m = meaningOfRole(role);
    if (!m) continue;
    for (const sym of [syms].flat()) {
      const c = controls.find((x) => keyOf(x) === sym);
      if (c && !statesMeaning(c)) have.add(m);
    }
  }
  if (declared !== undefined) {
    // the declaration's family is one of the extension's (the schema's $defs.family is the same closed
    // set); a family the extension has no place for is none: no house view
    const family = FAMILIES.includes(declared) ? declared : 'none';
    const backs = FAMILY_MEANINGS[family]?.backs;
    return backs && !backs.some((m) => have.has(m)) ? { family, needs: backs } : { family };
  }
  if (features.includes('instrument')) return { family: 'none' };
  for (const [family, { infer }] of Object.entries(FAMILY_MEANINGS)) if (infer.some((all) => all.every((m) => have.has(m)))) return { family };
  return { family: 'none' };
}

/** The roles of `family` that meaning `m` names: each role of the family whose meaning is `m`. */
const rolesOfMeaning = (family, m) => Object.keys(ROLES[family]).filter((role) => meaningOfRole(role) === m);

const KEY = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/;
const KEY_MAX = 63, LABEL_MAX = 255;

/** camelCase -> snake_case, the key grammar's spelling of a symbol or section key. */
export const snake = (s) => s.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase();

/** A free text (a group's name) in the key grammar: snake_case, any other character an underscore. */
const keyOfText = (s) => {
  const k = snake(s).replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return /^[a-z]/.test(k) ? k : `s_${k}`;
};

/** A descriptor with no control to lay out (none stated, or every one hidden): there is no panel to make, and the
 * layout says so by code instead of answering an empty one. */
export class NoControls extends Error {
  code = 'panel.describe.no-controls';
}

/** A declared family none of whose meanings the controls carry: a transient designer is no compressor (#138). */
export class FamilyNotBacked extends Error {
  code = 'panel.describe.family-not-backed';
}

/** A section's declared `bars: true` that fails a check of the bar rule, by the check's code (tools/bars.mjs). */
export class BarsRefused extends Error {
  constructor(message, code) {
    super(message);
    this.code = code;
  }
}

/** Whether every required role of `family` (role-table.mjs REQUIRED_ROLES) is mapped at index 0 in `roles`: the one check that
 * decides whether a family's view is drawn, for a declared family and a derived one alike. `none` needs nothing. */
export function requiredRolesMapped(family, roles) {
  return (REQUIRED_ROLES[family] ?? []).every((alt) => alt.some((role) => roles.some((r) => r.role === role && r.index === 0)));
}

/**
 * The key a layout names a control by: its symbol, else an LV2 control's id (its port symbol), else a CLAP
 * control's numeric id as `p<id>` (the id is the one thing a CLAP plugin keeps unique and stable, and a bare
 * number is not in the key grammar), else its name.
 */
export const keyOf = (c) => c.symbol ?? (typeof c.id === 'string' ? c.id : Number.isInteger(c.id) ? `p${c.id}` : c.name);

/** The ports a layout carries: the audio inputs and outputs with their channels, the side-chain, the notes in. */
function portsOf(ports = []) {
  const audio = (direction) => ports.filter((p) => p.kind === 'audio' && p.direction === direction).map((p) => ({ id: p.id, name: p.name, role: p.role ?? 'main', channels: p.channels ?? null }));
  return { inputs: audio('in'), outputs: audio('out'), sidechain: ports.some((p) => p.kind === 'audio' && p.direction === 'in' && p.role === 'sidechain'), notes: ports.some((p) => (p.kind === 'note' || p.kind === 'midi') && p.direction === 'in') };
}

/**
 * The panel of `descriptor`, of any origin. `panel` (a declaration's) gives the family, sections,
 * order, roles, widgets and graphs; with none, the sections are the controls' groups, the family the
 * one their meanings make and the roles the ones their meanings play. `ns` is the label-key namespace
 * (without one the label keys are null); `choiceUnits` and `byKind` are a declaration's extras.
 */
export function panelLayout(descriptor, { panel, ns, where = `descriptor ${descriptor.plugin?.id}`, choiceUnits = {}, byKind = {}, family: forced, inferredRoles, completingRoles, derive = false } = {}) {
  // the panel a plugin serves (plugin-hostd-probe panel: omx-clap-scan's object, parameters by id) is read as the
  // declared form over this descriptor's keys (tools/panel-served.mjs, #43)
  if (panel && isServedPanel(panel)) panel = declaredFromServed(panel, descriptor, { where, keyOf, indexedRoles: INDEXED_ROLES });
  const all = descriptor.controls;
  const byKey = new Map(all.map((c, i) => [keyOf(c), i]));
  const control = (sym) => all[byKey.get(sym)];
  const unitOf = (c) => c.travel?.unit ?? choiceUnits[keyOf(c)] ?? '';
  const key = (k, what) => {
    if (!KEY.test(k) || k.length > KEY_MAX) throw new Error(`${where}: ${what} '${k}' is not a key of ${PANEL_ID} ([a-z][a-z0-9_]*, dotted, at most ${KEY_MAX} bytes)`);
    return k;
  };
  const labelKey = (k, what) => (ns ? key(`${ns}.${k}`, what) : null);
  const label = (s, what) => {
    if (Buffer.byteLength(s) > LABEL_MAX) throw new Error(`${where}: ${what} label is longer than ${LABEL_MAX} bytes`);
    return s;
  };

  const { family, needs } = forced !== undefined ? { family: forced } : familyOf(all, panel ? panel.family : undefined, descriptor.plugin?.features, panel?.roles);
  // a declared family stands on its controls' meanings: a transient designer is no compressor
  if (needs) {
    const have = [...new Set(all.map((c) => c.meaning).filter(Boolean))];
    throw new FamilyNotBacked(`${where}: the ${family} family needs a control meaning ${needs.join(' or ')}, and its meanings are ${have.join(', ') || 'none'}: its family is none`);
  }

  // the sections, each with the controls it lists: the declared panel's, else one per group path
  let listed;
  if (panel) listed = panel.sections.map((s) => ({ key: snake(s.key), label: s.label, controls: s.controls, graph: s.graph, bars: s.bars, basis: s.basis }));
  else {
    const groups = new Map();
    for (const c of all) {
      // a bypass is the header's, which draws one per panel: not drawn a second time (as easy.mjs and modgui-gen.mjs)
      if (c.hidden || c.meaning === 'bypass') continue;
      const path = c.group?.length ? c.group : ['Controls'];
      const k = path.map(keyOfText).join('.');
      if (!groups.has(k)) groups.set(k, { key: k, label: path.join(' / '), controls: [] });
      groups.get(k).controls.push(keyOf(c));
    }
    listed = [...groups.values()];
  }
  const sections = listed.map((s) => {
    const k = key(s.key, 'section key');
    return { key: k, labelKey: labelKey(`section.${k}`, 'section label key'), label: label(s.label, `section '${s.key}'`) };
  });
  if (new Set(sections.map((s) => s.key)).size !== sections.length) throw new Error(`${where}: two panel sections share a key`);
  for (const sym of Object.keys(panel?.visibleWhen ?? {})) if (!listed.some((s) => s.controls.includes(sym))) throw new Error(`${where}: visibleWhen names '${sym}', which no panel section lists`);

  // the declared visibility: each governed control's governing parameter (its id, as the ABI's visible_param_id) and
  // the mask of the values that show it, bit v for value v
  const visibility = new Map(Object.entries(panel?.visibleWhen ?? {}).map(([sym, rule]) => [sym, visibilityOf(sym, rule, control, where)]));
  const seen = new Set();
  const controls = listed.flatMap((s, section) =>
    s.controls.map((sym) => {
      const c = control(sym);
      if (!c) throw new Error(`${where}: panel section '${s.key}' lists '${sym}', no parameter`);
      if (seen.has(sym)) throw new Error(`${where}: '${sym}' is a control twice`);
      seen.add(sym);
      const shown = visibility.get(sym);
      const standard = widgetOf(c, panel?.widgets?.[sym]);
      if (standard.widget === 'switch' && c.kind !== 'toggle' && c.kind !== 'trigger') throw new Error(`${where}: '${sym}' is drawn as a switch and is not a toggle`);
      return {
        symbol: sym, param: c.id, section, sectionKey: sections[section].key, widget: servedWidget(standard.widget), standard,
        labelKey: labelKey(snake(sym), 'control label key'), label: label(c.label ?? c.name, `'${sym}'`), visible: shown?.visible ?? null, mask: shown?.mask ?? 0n,
        unit: unitOf(c), meaning: c.meaning ?? null,
        // what a renderer and the page cut read the mask against: the governing control's symbol and its come-up value
        ...(shown ? { visibleWhen: { symbol: shown.symbol, default: shown.default } } : {}),
        // the group is read by the page cut only: it stays out of the JSON and the canonical form
        ...(c.group?.length ? { [GROUP]: c.group.join(' / ') } : {}),
      };
    }),
  );

  const table = ROLES[family];
  const roles = [], unpublished = [];
  // `extra` is what an inference states about a role it binds: `inferred`, the `token` it reads the control in, a band's `shape`
  // `extra` is what an inference states about a role it binds (`inferred`, the `token` it reads the control in, a band's
  // `shape`), kept on the row; `declared` marks a declared panel's binding and is not
  const bind = (role, index, sym, extra = {}) => {
    const { declared = false, ...rest } = extra;
    const c = control(sym);
    if (!c) throw new Error(`${where}: role '${role}' names '${sym}', no parameter`);
    const unit = unitOf(c);
    const token = rest.token ?? (/^(hpf|lpf)_slope$/.test(role) ? SLOPE_UNITS[unit] : undefined) ?? unitToken(unit);
    const plays = meaningOfRole(role);
    if (!table[role]) unpublished.push({ role, symbol: sym, why: `not a role of the ${family} family` });
    else if (!table[role].includes(token)) unpublished.push({ role, symbol: sym, why: `the ${role} role takes ${table[role].join(', ')}, not ${unit || 'no unit'}` });
    // a declared role over a control whose descriptor states another meaning (#43): the words disagree, and the role is named, not bound
    else if (declared && plays && statesMeaning(c) && c.meaning !== plays) unpublished.push({ role, symbol: sym, why: `the descriptor says it means ${c.meaning}, not ${plays}, the ${role} role's` });
    else {
      // a band-type role names the shape of each of its choice values, from the choice's own labels
      const shapes = rest.shapes ?? (role === 'band_type' ? shapesOf(c) : undefined);
      roles.push({ role, index, symbol: sym, param: c.id, unit, ...rest, ...(shapes ? { shapes } : {}) });
    }
  };
  if (panel) {
    // an indexed role (an EQ band's) names every band's symbol in order: one row per band, its index the band's
    for (const [role, syms] of Object.entries(panel.roles ?? {})) [syms].flat().forEach((sym, index) => bind(role, index, sym, { declared: true }));
    // a control the panel binds to a role, whose own meaning the descriptor leaves unstated (a scan's `unknown`), serves
    // the role's meaning (#43): the panel's declaration over the scan's unknown; a stated meaning stays the descriptor's
    for (const r of roles) {
      const c = controls.find((x) => x.symbol === r.symbol);
      const m = meaningOfRole(r.role);
      if (c && m && !statesMeaning({ meaning: c.meaning })) c.meaning = m;
    }
  } else {
    // each meaning plays the one role of the family it names; an indexed role takes every control of
    // its meaning, any other its first, and a second is named
    const played = new Map();
    for (const c of all) {
      if (c.hidden || c.readonly || !c.meaning) continue;
      const named = rolesOfMeaning(family, c.meaning);
      if (named.length !== 1) continue;
      const [role] = named;
      const n = played.get(role) ?? 0;
      if (n && !INDEXED_ROLES.includes(role)) unpublished.push({ role, symbol: keyOf(c), why: `the ${role} role is played by ${roles.find((r) => r.role === role)?.symbol ?? 'another control'}` });
      else bind(role, n, keyOf(c));
      played.set(role, n + 1);
    }
    // the bands the descriptor's words do not give: the inference's (tools/meaning-infer.mjs), only while the words leave the
    // family's required roles unmapped, and then in place of the words' band roles
    if (inferredRoles?.length && !requiredRolesMapped(family, roles)) {
      const BAND = /^(band_|hpf_|lpf_)/;
      for (let i = roles.length - 1; i >= 0; i--) if (BAND.test(roles[i].role)) roles.splice(i, 1);
      for (const r of inferredRoles) bind(r.role, r.index, r.symbol, { inferred: true, token: r.unit, ...(r.shape ? { shape: r.shape } : {}), ...(r.shapes ? { shapes: r.shapes } : {}) });
    } else if (completingRoles?.length) {
      // the words name a band's frequency and gain and leave its Q, type and switch unnamed (an LV2 port states no Q): the
      // inference over the controls with their meanings set aside (`completingRoles`) completes each band the words named,
      // at the words' index, by its band_freq symbol; a role the words bind stays theirs, and a band they do not name is not added
      const wordsIndex = new Map(roles.filter((r) => r.role === 'band_freq').map((r) => [r.symbol, r.index]));
      const inferredFreq = new Map(completingRoles.filter((r) => r.role === 'band_freq').map((r) => [r.index, r.symbol]));
      const bound = new Set(roles.map((r) => `${r.role}.${r.index}`));
      for (const r of completingRoles) {
        if (!['band_q', 'band_type', 'band_on'].includes(r.role)) continue;
        const index = wordsIndex.get(inferredFreq.get(r.index));
        if (index === undefined || bound.has(`${r.role}.${index}`)) continue;
        bind(r.role, index, r.symbol, { inferred: true, token: r.unit, ...(r.shapes ? { shapes: r.shapes } : {}) });
        bound.add(`${r.role}.${index}`);
      }
    }
  }

  // the origin of a band a planter owns (spec 7.6, 7.7): a declared panel's `origins`, band_freq symbol -> origin word, an authored
  // descriptor's alone; a descriptor has none of its own and nothing is inferred
  for (const [sym, origin] of Object.entries(panel?.origins ?? {})) {
    if (descriptor.origin !== 'authored') throw new Error(`${where}: origins names '${sym}', and only an authored descriptor declares an origin`);
    if (!BAND_ORIGINS.includes(origin)) throw new Error(`${where}: '${sym}' has the origin '${origin}', none of ${BAND_ORIGINS.join(', ')}`);
    const r = roles.find((x) => x.role === 'band_freq' && x.symbol === sym);
    if (!r) throw new Error(`${where}: origins names '${sym}', which is no band_freq role of the panel`);
    r.origin = origin;
  }

  const displays = listed.flatMap((s, section) => {
    if (s.graph === undefined) return [];
    const kind = DISPLAY_OF_GRAPH[s.graph];
    // a graph word that names no kind is a declaration error, named; dropping it drew nothing and said nothing (ruling 6)
    if (!kind) throw new Error(`${where}: section '${s.key}' draws ${s.graph}, which names no display kind (${Object.keys(DISPLAY_OF_GRAPH).join(', ')})`);
    if (!CLOSED_FORMS[family]?.includes(kind)) throw new Error(`${where}: section '${s.key}' draws ${s.graph}, and the ${family} family has no ${kind} a host computes`);
    // `exact` only when an authored descriptor declares it (the one-panel spec §5.3); any other curve is modelled
    const basis = basisOf(descriptor, s);
    return [{ kind, section, sectionKey: sections[section].key, source: 'family', meters: [null, null], curve: null, floor: null, labelKey: labelKey(`display.${kind}`, 'display label key'), label: label(s.label, `section '${s.key}'`), basis }];
  });
  // a derived panel (derive: true): a family whose closed form is known draws it on the section holding its first required role, once
  // every required role is mapped (the one-panel spec §3.1)
  if (derive && !panel && CLOSED_FORMS[family] && requiredRolesMapped(family, roles)) {
    const first = REQUIRED_ROLES[family][0].map((role) => roles.find((r) => r.role === role && r.index === 0)).find(Boolean);
    const section = controls.find((c) => c.symbol === first.symbol)?.section;
    if (section !== undefined) {
      const kind = CLOSED_FORMS[family][0];
      displays.push({ kind, section, sectionKey: sections[section].key, source: 'family', meters: [null, null], curve: null, floor: null, labelKey: labelKey(`display.${kind}`, 'display label key'), label: label(listed[section].label, `section '${listed[section].key}'`), basis: 'modelled' });
    }
  }

  // the bar groups of each section (tools/bars.mjs): a declared `bars` word wins; a view of the panel, so out of the canonical form
  listed.forEach((s, section) => {
    const items = controls.filter((c) => c.section === section).map((c) => ({ symbol: c.symbol, label: c.label, control: control(c.symbol) }));
    const { runs, refusal } = barsOf(items, s.bars);
    if (refusal) throw new BarsRefused(`${where}: section '${s.key}' declares bars: ${refusal.why}`, refusal.code);
    if (runs.length) sections[section].bars = runs;
  });

  // the contract's per-kind defaults: each channel kind the placement it is, the value inside the travel
  const defaults = all.flatMap((c, i) =>
    Object.entries(byKind[keyOf(c)] ?? {}).map(([kind, value]) => {
      const placement = PLACEMENT_OF_KIND[kind];
      if (!placement) throw new Error(`${where}: '${keyOf(c)}' comes up differently on a ${kind} channel, which has no placement of ${PANEL_ID}; add it to PLACEMENT_OF_KIND`);
      const [min, max] = c.travel ? [c.travel.min, c.travel.max] : c.values ? [Math.min(...c.values), Math.max(...c.values)] : [0, 1];
      const integer = c.kind !== 'travel' || c.travel.step === 1;
      if (!(value >= min && value <= max) || (integer && !Number.isInteger(value))) throw new Error(`${where}: '${keyOf(c)}' on ${kind} comes up at ${value}, outside its travel`);
      return { placement, symbol: keyOf(c), param: i, value };
    }),
  );

  // the meters (contract §7.9): the descriptor's `meters` word, each a meter control; a foreign read-only control in a level
  // unit stays a meter with no measurement. A view of the panel: out of the canonical form and the fingerprint.
  const meterRefusals = [];
  const meters = [];
  const refuseMeter = (symbol, why) => meterRefusals.push({ symbol, reason: why });
  for (const m of descriptor.meters ?? []) {
    const named = [m.id, m.symbol, m.name, m.doc].filter((t) => typeof t === 'string').find(namesAnalogueState);
    if (named !== undefined) { refuseMeter(m.symbol, `a meter is a measurement; '${named}' names an analogue input state`); continue; }
    const level = m.kind === 'level';
    meters.push({
      declared: true, symbol: m.symbol, widget: 'meter', kind: m.kind, measurement: m.measurement ?? (level ? null : 'gain-reduction'), unit: m.unit, min: m.min, max: m.max,
      channels: m.channels, held: m.held === true, clip: level && m.clip === true && CLIP_UNITS.includes(m.unit),
      label: label(m.name ?? m.symbol, `meter '${m.symbol}'`), labelKey: labelKey(`meter.${snake(m.symbol)}`, 'meter label key'),
    });
  }
  const have = new Set(meters.map((m) => m.symbol));
  for (const c of all) {
    if (!c.readonly || have.has(keyOf(c)) || !LEVEL_UNITS.includes(c.travel?.unit)) continue;
    const named = [c.meaning, keyOf(c), c.name].filter((t) => typeof t === 'string').find(namesAnalogueState);
    if (named !== undefined) { refuseMeter(keyOf(c), `a meter is a measurement; '${named}' names an analogue input state`); continue; }
    meters.push({ declared: false, symbol: keyOf(c), widget: 'meter', kind: 'level', measurement: null, unit: c.travel.unit, min: c.travel.min, max: c.travel.max, channels: 1, held: false, clip: false, label: label(c.label ?? c.name, `'${keyOf(c)}'`), labelKey: labelKey(snake(keyOf(c)), 'control label key') });
  }
  // a dynamics family's gain reduction is its section's bar; the curve's operating point reads the input and output meters
  // a symbol's words, snake_case or camelCase alike (`in_level`, `compIn`): the operating point is a whole word `in`/`input`, `out`/`output`
  const wordsOf = (symbol) => symbol.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase().split(/[^a-z0-9]+/);
  // a level the descriptor's meters[] declares, with or without its `measurement` (clap.meters/1 states none, so a CLAP
  // meter plugin-hostd describes carries none); a foreign read-only control is never the operating point
  const levelAt = (...names) => meters.findIndex((m) => m.kind === 'level' && m.declared && wordsOf(m.symbol).some((w) => names.includes(w)));
  const inAt = levelAt('in', 'input'), outAt = levelAt('out', 'output');
  for (const d of displays) if (d.kind === 'transfer_curve' && inAt >= 0 && outAt >= 0) d.meters = [inAt, outAt];
  const grAt = meters.findIndex((m) => m.kind === 'gain-reduction');
  if (grAt >= 0 && ['dynamics', 'gate', 'limiter', 'deesser'].includes(family) && sections.length > 0) {
    const first = (REQUIRED_ROLES[family] ?? [])[0]?.map((role) => roles.find((r) => r.role === role && r.index === 0)).find(Boolean);
    const at = first ? (controls.find((c) => c.symbol === first.symbol)?.section ?? 0) : 0;
    displays.push({ kind: 'gain_reduction_bar', section: at, sectionKey: sections[at].key, source: 'meters', meters: [grAt, null], curve: null, floor: null, labelKey: labelKey('display.gain_reduction_bar', 'display label key'), label: label('Gain reduction', 'gain reduction bar'), basis: 'modelled' });
  }
  // each meter's section: a foreign meter its control's; a descriptor meter the gain-reduction bar's, else the last section (the output end)
  const barAt = displays.find((d) => d.kind === 'gain_reduction_bar')?.section;
  for (const m of meters) {
    const own = controls.find((c) => c.symbol === m.symbol)?.section;
    m.section = own ?? barAt ?? Math.max(0, sections.length - 1);
    m.sectionKey = sections[m.section]?.key ?? null;
  }

  if (controls.length === 0) {
    const listsPrograms = ['programs', 'presets'].map((k) => [k, descriptor[k]]).find(([, v]) => Array.isArray(v) && v.length > 0);
    throw new NoControls(`${where}: no control to lay out (${all.length === 0 ? 'the descriptor states no controls' : `its ${all.length} controls are all hidden`})${listsPrograms ? `; its ${listsPrograms[1].length} ${listsPrograms[0]} are not drawn, a program list is not a control` : ''}`);
  }
  // The Easy face: a view of the panel, so it stays out of the canonical form and the fingerprint
  const easy = easyOf({ family, roles, controls }, { declared: panel?.easy ?? descriptor.easy, where });
  return { origin: descriptor.origin, family, sections, controls, roles, unpublished, displays, defaults, ports: portsOf(descriptor.ports), easy, meters, meterRefusals };
}

/** The highest value a visibility mask has a bit for: the ABI's visible_mask is 64 bits. */
export const VISIBLE_MAX = 63;
const ALL_BITS = (1n << BigInt(VISIBLE_MAX + 1)) - 1n;

/** The integer a control holds at come-up, or undefined for one that holds no integer (a travel that is not whole). */
function integerDefault(c) {
  if (c.kind === 'toggle') return c.default ? 1 : 0;
  if (c.kind === 'choice' && Array.isArray(c.values)) {
    const at = (c.ids ?? []).indexOf(c.default);
    return at >= 0 ? c.values[at] : Number.isInteger(c.default) ? c.default : c.values[0];
  }
  if (c.kind === 'travel' && c.travel?.step === 1) return c.travel.default ?? c.travel.min;
  return undefined;
}

/** The mask of a visibility rule: `values` sets bit v for each value v; `atLeast: n` sets bits n..63 (a count: band n
 * shows while the count is n or more). */
export function visibilityMask(rule) {
  if (rule.atLeast !== undefined) return ALL_BITS ^ ((1n << BigInt(rule.atLeast)) - 1n);
  return rule.values.reduce((m, v) => m | (1n << BigInt(v)), 0n);
}

/** A declared `visibleWhen` entry for control `sym`, checked: `{ param, values }` or `{ param, atLeast }`, its param an
 * integer or toggle control of the plugin, every value inside 0..63. */
function visibilityOf(sym, rule, control, where) {
  const what = `visibleWhen of '${sym}'`;
  if (rule === null || typeof rule !== 'object' || typeof rule.param !== 'string') throw new Error(`${where}: ${what} names no param`);
  const hasValues = rule.values !== undefined, hasAtLeast = rule.atLeast !== undefined;
  if (hasValues === hasAtLeast) throw new Error(`${where}: ${what} states one of values or atLeast`);
  const inRange = (v) => Number.isInteger(v) && v >= 0 && v <= VISIBLE_MAX;
  if (hasValues && (!Array.isArray(rule.values) || rule.values.length === 0 || !rule.values.every(inRange))) throw new Error(`${where}: ${what}: values are integers 0..${VISIBLE_MAX}`);
  if (hasAtLeast && !inRange(rule.atLeast)) throw new Error(`${where}: ${what}: atLeast is an integer 0..${VISIBLE_MAX}`);
  if (rule.param === sym) throw new Error(`${where}: ${what} is governed by itself`);
  const g = control(rule.param);
  if (!g) throw new Error(`${where}: ${what} names '${rule.param}', no parameter`);
  const def = integerDefault(g);
  if (def === undefined) throw new Error(`${where}: ${what} names '${rule.param}', which is not an integer or toggle parameter`);
  return { symbol: rule.param, visible: g.id, mask: visibilityMask(rule), default: def };
}

/** The checked visibility rules of a declared panel over `descriptor`: control symbol -> `{ symbol, visible, mask,
 * default }`, the governing control's symbol and id, the mask, and the governing control's come-up value. */
export function visibilityRules(descriptor, visibleWhen = {}, where = `descriptor ${descriptor.plugin?.id}`) {
  const all = descriptor.controls ?? [];
  const control = (sym) => all.find((c) => keyOf(c) === sym);
  return new Map(Object.entries(visibleWhen).map(([sym, rule]) => [sym, visibilityOf(sym, rule, control, where)]));
}

/** Whether control `c` of a layout is shown while the controls read `values` (symbol -> value; a governing control left
 * out reads its come-up value). A control with no visibility rule is always shown. */
export function isVisible(c, values = {}) {
  if (c.visible === null || c.visible === undefined) return true;
  const v = values[c.visibleWhen.symbol] ?? c.visibleWhen.default;
  // a layout read back from its JSON carries the mask as hex
  const mask = typeof c.mask === 'string' ? BigInt(`0x${c.mask}`) : BigInt(c.mask);
  return Number.isInteger(v) && v >= 0 && v <= VISIBLE_MAX && ((mask >> BigInt(v)) & 1n) === 1n;
}

/** A channel kind whose default a contract travel states (byKind) -> the placement it is. */
const PLACEMENT_OF_KIND = { fxReturn: 'return', main: 'master' };

/** The key a control carries its declared group under, for the page cut: a symbol, so no serialisation sees it. */
export const GROUP = Symbol('group');

/** The label of the repeated-group instance a control belongs to (`Band 3`), for the page cut: a symbol, so no serialisation sees it. */
export const INSTANCE = Symbol('instance');

/** The name of the Easy controls' page and of a MOD GUI's first section. */
export const EASY_PAGE = 'Easy';

/** The slots per page a caller that states no width gets: CLAP_REMOTE_CONTROLS_COUNT. A surface states its own. */
export const PAGE_SIZE = 8;

/**
 * THE one cut of a panel into control-surface pages (the pages amendment, one-panel spec 7.14). Every surface pages a
 * plugin's controls through this function at its own width, `perPage` (a surface that states none gets eight); no surface
 * builds, stores or reorders pages. The sequence:
 *
 * 1. the Easy controls (`x.easy`, symbols; a skin's list wins in `describe`), on pages of their own named Easy, Easy 2;
 * 2. then the plugin's declared remote-controls pages, as the host reports them (`remote`: `[{ name, ids }]`, a slot a
 *    control's param id or null), replacing the derived ones; a declared page is not edited, so an Easy control may also
 *    sit on its remote page, and a slot of no control is blank;
 * 3. else the sections in order, each cut at the width with a group kept whole at every width: a page ends early to keep
 *    a group together, a group longer than a page is the only one split, starting on a page of its own and ending
 *    on one, never mixed with its neighbour. A derived page holds a control once. A control with no group is its own.
 *    A section of several pages names each page by the controls it holds, "Band: Freq - Q".
 *
 * A control hidden by `values` (symbol -> current value; a governing control left out reads its come-up value) keeps its
 * slot, blank: the slots do not move with the governing values. Below two encoders a group is plain controls (one a page).
 */
export function pagesOf(x, { perPage, remote, values = {} } = {}) {
  const size = perPage ?? PAGE_SIZE;
  if (!Number.isInteger(size) || size < 1) throw new Error(`pages: --per-page must be a whole number of at least 1, not ${perPage}`);
  const blank = new Set(x.controls.filter((c) => !isVisible(c, values)).map((c) => c.param));
  const known = new Set(x.controls.map((c) => c.param));
  const slot = (id) => (id === null || id === undefined || !known.has(id) || blank.has(id) ? null : id);
  const pad = (ids) => {
    const out = ids.map(slot);
    while (out.length < size) out.push(null);
    return out;
  };
  const easy = (x.easy ?? []).filter((symbol) => x.controls.some((c) => c.symbol === symbol));
  const easyPages = [];
  for (let k = 0; k < easy.length; k += size) {
    const ids = easy.slice(k, k + size).map((symbol) => x.controls.find((c) => c.symbol === symbol).param);
    easyPages.push({ section: null, sectionName: EASY_PAGE, pageName: k === 0 ? EASY_PAGE : `${EASY_PAGE} ${k / size + 1}`, ids: pad(ids) });
  }
  if (Array.isArray(remote) && remote.length > 0) {
    const declared = remote.flatMap((r) => {
      const name = String(r.name ?? '');
      const pages = [];
      for (let k = 0; k < Math.max(1, r.ids.length); k += size) pages.push({ section: null, sectionName: name, pageName: k === 0 ? name : `${name} ${k / size + 1}`, ids: pad(r.ids.slice(k, k + size)) });
      return pages;
    });
    return [...easyPages, ...declared];
  }
  return [...easyPages, ...x.sections.flatMap((s, section) => {
    // an Easy control is on its Easy page alone; in an instance of a repeated group it leaves its slot blank, so the slots
    // after it stay where every other instance has them, and the blanks an instance would end on are left off
    const taken = (c) => c.param === null || easy.includes(c.symbol);
    const cs = x.controls.filter((c) => c.section === section && (c[INSTANCE] !== undefined || !taken(c)))
      .map((c) => (taken(c) ? { ...c, param: null } : c))
      .filter((c, i, all) => c.param !== null || all.slice(i + 1).some((d) => d[GROUP] === c[GROUP] && d.param !== null));
    const pages = [];
    let page = [];
    const flush = () => {
      if (page.length) pages.push(page);
      page = [];
    };
    for (let i = 0; i < cs.length; ) {
      let j = i + 1;
      if (cs[i][GROUP]) while (j < cs.length && cs[j][GROUP] === cs[i][GROUP]) j++;
      const run = cs.slice(i, j);
      i = j;
      // a group that fits ends the page early rather than split; a longer one starts and ends on a page of its own
      // an instance of a repeated group is never beside another control: a page of its own, ended after it
      const alone = run[0][INSTANCE] !== undefined;
      if (run.length > size || page.length + run.length > size || alone) flush();
      for (const c of run) {
        if (page.length === size) flush();
        page.push(c);
      }
      if (run.length > size || alone) flush();
    }
    flush();
    // a page of one repeated-group instance is named by it (`Band 3`, a continuation `Band 3 2`)
    const seen = new Map();
    return pages.map((p, k) => {
      const held = p.length > 1 ? `${p[0].label} - ${p[p.length - 1].label}` : p[0].label;
      const instance = p[0][INSTANCE];
      if (instance !== undefined && p.every((c) => c[INSTANCE] === instance)) {
        const n = (seen.get(instance) ?? 0) + 1;
        seen.set(instance, n);
        return { section, sectionName: s.label, pageName: `${s.label}: ${n === 1 ? instance : `${instance} ${n}`}`, ids: pad(p.map((c) => c.param)) };
      }
      return { section, sectionName: s.label, pageName: pages.length === 1 ? s.label : `${s.label}: ${held}`, ids: pad(p.map((c) => c.param)) };
    });
  })];
}

/** The shortest decimal that round-trips to the same binary64, -0 written 0. */
const shortest = (n) => (Object.is(n, -0) ? '0' : String(n));
const byCodeUnit = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

/** The canonical serialisation: UTF-8, LF after every line, TAB-separated, parameters by symbol, the
 * fallback labels left out. */
export function panelCanonical(x) {
  const lines = [PANEL_ID, `family\t${x.family}`];
  x.sections.forEach((s, i) => lines.push(['section', i, s.key, s.labelKey].join('\t')));
  for (const c of x.controls) lines.push(['control', c.symbol, c.sectionKey, c.widget, c.labelKey, c.visible ?? '-', c.mask.toString(16)].join('\t'));
  for (const r of [...x.roles].sort((a, b) => byCodeUnit(a.role, b.role) || a.index - b.index)) lines.push(['role', r.role, r.index, r.symbol].join('\t'));
  // a display read from the meters word, and the meters a curve reads, are views: out of the canonical form
  for (const v of x.displays.filter((d) => d.source !== 'meters')) {
    const floor = v.floor === null ? '-' : typeof v.floor === 'number' ? shortest(v.floor) : v.floor;
    const meter = (m) => (m === null ? '-' : String(m));
    lines.push(['display', v.kind, v.sectionKey, v.source, meter(null), meter(null), v.curve ?? '-', floor, v.labelKey].join('\t'));
  }
  const order = (p) => PLACEMENTS.indexOf(p);
  for (const p of [...x.defaults].sort((a, b) => order(a.placement) - order(b.placement) || byCodeUnit(a.symbol, b.symbol))) lines.push(['default', p.placement, p.symbol, shortest(p.value)].join('\t'));
  return `${lines.join('\n')}\n`;
}

/** The fingerprint: lowercase hex SHA-256 of the canonical serialisation. */
export const panelFingerprint = (x) => createHash('sha256').update(panelCanonical(x)).digest('hex');
