/** The faults of the bundled font against the pin, as sentences, or none. */
export function fontPinFaults(pin?: any, root?: string): string[];
export const FONT_PIN_JSON: string;
export function loadFontPin(file?: string): any;
