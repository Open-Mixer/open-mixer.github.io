export function unitToken(unit: any): any;
/**
 * @typedef {{ symbol: string, name: string, numbered?: string, index: number, kind: 'toggle' | 'choice' | 'travel', unit: string,
 *   min?: number, max?: number, options?: number, integer?: boolean, path: string[] }} Control
 */
/**
 * The controls of an omx-contract descriptor, each under the key the layout names it by (`keyOf`: its symbol, else an LV2
 * control's id, else a CLAP parameter's id as `p<id>`), so a descriptor a scan wrote, which states no `symbol`, is read as
 * the authored one is. A control keyed by a CLAP id carries `numbered`, its name: the id's digits number no instance.
 * `panel`, a declared panel (`{ sections: [{ key, label, controls }] }`), wins over the controls' own `group` paths: it
 * is the plugin's later word on its layout.
 * @returns {Control[]}
 */
export function controlsOfDescriptor(descriptor: any, { panel }?: {}): Control[];
/** The controls of LV2 plugin `uri` in parsed Turtle (tools/turtle-read.mjs): its placeable ports, a pg:group's name as the path. */
export function controlsOfLv2(triples: any, uri: any): any;
/**
 * A parameter's role from its words (the name's words less the number and the words every parameter of the instance
 * shares) and its kind and unit: `on` / `off` (the instance's head toggle), one of ROLE_ORDER, or null.
 */
export function roleOf(words: any, kind: any, unit: any): string | null;
/** The edge a control's name opens with, and how many words that takes; null for none. */
export function edgeOf(name: any): {
    edge: "hpf" | "lowshelf" | "highshelf" | "lpf";
    take: number;
} | null;
/**
 * The model of a plugin's controls: its groups, in the order of their first control, each a plain list or a repeated
 * group of instances (low to high) holding the same parameters.
 * @param {Control[]} controls
 * @returns {{ groups: Group[] }}
 */
export function inferGroupModel(controls: Control[]): {
    groups: Group[];
};
/**
 * The instances of a served matrix, one per head (an EQ's HPF and LPF included), left to right: the head and the symbols it
 * holds in the order a screen shows them, its on/off first, then its cells from the top row down (the head row and an empty
 * cell are none). The one order of an instance: the page cut (`describe`) and the port groups (`instanceGroups`) both read it.
 * `slots` is the same order with the places kept: the on/off's place (where any head has one), then one place per row, null
 * where this head has no control there, so place `k` is the same parameter in every instance; the nulls after an instance's
 * last control are left off.
 * @returns {{ head: { label: string, on: { symbol: string } | null, edge: string | null }, symbols: string[], slots: (string | null)[] }[]}
 */
export function matrixInstances(served: any): {
    head: {
        label: string;
        on: {
            symbol: string;
        } | null;
        edge: string | null;
    };
    symbols: string[];
    slots: (string | null)[];
}[];
/**
 * The instances of the repeated groups a plugin does not declare instance by instance (source `indexed`, no declared group
 * above them), each one a port group: docs/group-model.md, P2. `{ symbol, name, ports }`, the ports in `matrixInstances`'s
 * order; the name the instance's label (a bare number is "Section 3"), the symbol that name as an LV2 symbol. A group the
 * plugin declares is its own and gives none.
 * @param {{ groups: Group[] }} model
 * @returns {{ symbol: string, name: string, ports: string[] }[]}
 */
export function instanceGroups(model: {
    groups: Group[];
}): {
    symbol: string;
    name: string;
    ports: string[];
}[];
/** Every symbol a group holds: its own parameters, its instances' and its edges'. */
export function memberSymbols(g: any): any[];
/**
 * A repeated group as the matrix a surface draws: `columns` and `rows` with `cells[row][column]` a control symbol or
 * null (that column has no such parameter), never flowed. An EQ is always `columns` (bands left to right low to high,
 * the high-pass leftmost, the low-pass rightmost); another repeated group is `columns` when it has at least as many
 * instances as rows, else `rows` (the instances as rows, transposed). Each instance's header carries its on/off and its
 * `ordinal` (its place among the instances, null for an edge). A group with a `count` draws its first `count` instances
 * only, at `values[count.symbol]` (L6): the others are left out and leave no gap; a value left out draws every instance.
 * @param {Group} g a repeated group of inferGroupModel's
 * @param {{ values?: Record<string, number> }} [options]
 */
export function matrixOf(g: Group, { values }?: {
    values?: Record<string, number>;
}): {
    orientation: string;
    columns: {
        key: any;
        label: any;
        on: any;
        edge: any;
        ordinal: any;
    }[];
    rows: Row[] | undefined;
    cells: any[][];
} | {
    orientation: string;
    columns: Row[] | undefined;
    rows: {
        key: any;
        label: any;
        on: any;
        edge: any;
        ordinal: any;
    }[];
    cells: any[][];
};
/**
 * Where a repeated group's matrix goes among a surface's sections (`sections`: `{ id, symbols }` in drawing order). The
 * sections that hold the group's instances and own parameters are its home: they must hold nothing else, and the first is
 * where the matrix goes (the others are folded into it). The sections that hold only the group's edges, taken from
 * beside the EQ, are donors: they give their members to the matrix and keep the rest. Null when the group cannot be
 * placed whole: a member no section draws, or a home section that holds another control beside the group.
 * @returns {{ home: unknown, folded: unknown[], donors: unknown[], members: Set<string> } | null}
 */
export function placeMatrix(g: any, sections: any): {
    home: unknown;
    folded: unknown[];
    donors: unknown[];
    members: Set<string>;
} | null;
/**
 * The served matrix (docs/group-model.md, "The served matrix"): the ONE shape `omx-panel describe` serves and every surface
 * (the console, modgui-gen, the C renderer, the Zynthian builder) reads and never recomputes. `heads` are every instance and
 * edge along one axis, `rows` the parameters in the owner's order then the head row (always last: `On` when any head has
 * an on/off, else a caption row labelled ''), `cells[row][head]` a symbol as `symbolOf` gives it, or null; `title` the
 * group's label (else `title`, the label of the section that holds it); `count` only where no visibleWhen rule governs the
 * instances (`governs(symbol)`): such a group keeps every instance's cell and its rules hide them live.
 * @param {Group} g a repeated group of inferGroupModel's
 * @param {{ symbolOf?: (s: string) => string, governs?: (s: string) => boolean, title?: string, countDefault?: number | null }} [options]
 */
export function servedMatrix(g: Group, { symbolOf, governs, title, countDefault }?: {
    symbolOf?: (s: string) => string;
    governs?: (s: string) => boolean;
    title?: string;
    countDefault?: number | null;
}): {
    count?: {
        symbol: string;
        default: number | null;
    } | undefined;
    orientation: string;
    title: string | null;
    heads: {
        label: any;
        on: {
            symbol: string;
            sense: any;
        } | null;
        edge: any;
    }[];
    rows: ({
        label: any;
    } | {
        label: string;
        head: boolean;
    })[];
    cells: (string | null)[][];
};
/**
 * The ONE section merge after `placeMatrix` (docs/group-model.md, "The served matrix"): `sections` in drawing order, each
 * `{ section, home }` kept: the home is the matrix's section; a folded or donor section stays only while `holdsAfter(s)`
 * (it still holds something once the group's members have moved); every other section stays as it is. The description,
 * its `--layout` and the MOD GUI face all merge by it.
 */
export function mergedSections(placed: any, sections: any, { idOf, holdsAfter }: {
    idOf: any;
    holdsAfter: any;
}): any;
/**
 * L6 on a served matrix: the indices of the heads a surface draws with the count at `value` (the served `count.default`
 * when left out): every edge, and the first `value` instances in order; every head when the matrix has no count or the
 * value is not a number.
 */
export function drawnHeads(served: any, value?: any): any[];
/**
 * L7, the visible-column rule, the one every language applies (the C renderer's omx_panel_view_visible_columns answers the
 * same vector, test/fixtures/group-model/visible-columns.json): of a SERVED matrix, how many columns a surface `width` wide
 * shows at `column` each: as many as fit, at least one, at most the columns it is drawn with (the drawn heads in `columns`;
 * the rows, the head row among them, in `rows`).
 */
export function visibleColumns(served: any, { width, column, count }?: {}): number;
/** L7: the drawn head `n` (clamped) an encoder surface edits: its head and its cells in row order (the head row last), an empty cell null. */
export function selectedColumn(served: any, n: any, { count }?: {}): any;
export const REASONS: {
    'two-indices': string;
    'ragged-instances': string;
    'one-parameter': string;
    'index-gap': string;
    'kind-mismatch': string;
    'unit-mismatch': string;
    'range-mismatch': string;
    'name-number-disagrees': string;
    'declared-index-conflict': string;
};
/** The canonical parameter roles of a repeated group, the EQ's rows in this order. */
export const ROLE_ORDER: string[];
/** The EQ's edge columns, the filters outermost, the shelves inside them, the bands between: meaning-infer.mjs's EQ_WORDS edges, the one table. */
export const EDGES: readonly (Readonly<{
    edge: "hpf";
    shape: "highpass";
    side: "left";
    words: readonly string[];
}> | Readonly<{
    edge: "lowshelf";
    shape: "lowshelf";
    side: "left";
    words: readonly string[];
}> | Readonly<{
    edge: "highshelf";
    shape: "highshelf";
    side: "right";
    words: readonly string[];
}> | Readonly<{
    edge: "lpf";
    shape: "lowpass";
    side: "right";
    words: readonly string[];
}>)[];
export type Control = {
    symbol: string;
    name: string;
    numbered?: string;
    index: number;
    kind: "toggle" | "choice" | "travel";
    unit: string;
    min?: number;
    max?: number;
    options?: number;
    integer?: boolean;
    path: string[];
};
export type Head = {
    symbol: string;
    sense: "on" | "off";
};
export type Instance = {
    index: number;
    label: string;
    on: Head | null;
    parameters: Record<string, string>;
};
export type Edge = {
    edge: string;
    label: string;
    on: Head | null;
    parameters: Record<string, string>;
};
export type Row = {
    key: string;
    label: string;
    role: string | null;
};
export type Group = {
    key: string;
    label: string | null;
    source: "declared" | "indexed" | "none";
    kind: "repeated" | "list";
    parameters: string[];
    family?: "eq" | null;
    rows?: Row[];
    instances?: Instance[];
    edges?: Edge[];
    count?: {
        symbol: string;
    } | null;
    reason?: keyof typeof REASONS;
    detail?: string;
};
