/** The directory of the shipped fixtures. */
export const FIXTURES_DIR: string;
/**
 * A MOD GUI bundle of our own, with no MOD art: one LV2 echo plugin (urn:openmixer:fixture:echo) with its modgui.ttl,
 * stylesheet, icon, knob sprite, screenshot and thumbnail. The importer's and the console's round-trip tests read it.
 */
export const MODGUI_ECHO: string;
