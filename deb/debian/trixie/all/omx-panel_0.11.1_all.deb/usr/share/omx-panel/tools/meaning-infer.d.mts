/** A shape word from a filter-type choice's label; undefined when the label is none of them. */
export function shapeOfLabel(label: any): "lowshelf" | "highshelf" | "highpass" | "lowpass" | "notch" | "bell" | "off" | undefined;
/**
 * A choice control's `shapes`: one shape word per choice value from 0 (`-` for a value whose label is none of
 * them), or undefined when none of its labels is a shape. A choice's value is its entry in `values`, else its place.
 */
export function shapesOf(c: any): string[] | undefined;
/** Infer `controls`' EQ bands. See the file's header for the verdict. */
export function inferBands(controls: any): {
    outcome: string;
    reason: string;
    roles?: undefined;
} | {
    outcome: string;
    roles: {
        inferred: boolean;
        role: string;
        index: number;
        symbol: any;
        unit: string;
    }[];
    reason?: undefined;
};
/** The band shapes a curve function knows, and `-` for a choice value that is none of them. */
export const SHAPES: string[];
export function statesMeaning(c: any): boolean;
