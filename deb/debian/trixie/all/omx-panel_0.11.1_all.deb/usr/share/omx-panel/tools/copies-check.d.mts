/** What omx-panel renders or ships, by digest: each a name a reader can follow, and its path in omx-panel's tree. */
export function canonicalFiles(): Map<any, any>;
/** Every tracked file of `tree` that is byte for byte something omx-panel renders or ships: [path, what it copies]. */
export function copiesIn(tree: any, canon?: Map<any, any>): any[][];
export function main(argv: any): 1 | 2 | 0;
