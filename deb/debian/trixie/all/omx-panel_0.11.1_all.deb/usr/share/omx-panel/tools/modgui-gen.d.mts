/**
 * A descriptor control as the travel this generator draws: `{ kind, min, max, def, points? }`, `kind` `toggle`
 * (0..1), `integer` (a choice, or a travel of step 1) or none (a continuous travel); a choice's `points` are its
 * values and labels, `{value, label}` from the lowest. Undefined for a control with no travel to draw (a trigger,
 * a text, a read-only reading).
 */
export function travelOf(c: any): {
    kind: string;
    min: any;
    max: any;
    def: any;
    points: any;
} | {
    min: any;
    max: any;
    def: any;
    kind?: string | undefined;
    points?: undefined;
} | undefined;
/**
 * The widget a declared parameter takes when its panel names none: a toggle is a switch; a parameter with
 * labelled values (a choice, an enumeration port) or an integer with a few steps is a selector,
 * MOD's own `custom-select` over the port's values; an integer with a wide travel (more than
 * MAX_SELECTOR_STEPS steps, e.g. a time in ms) and every other travel is a knob.
 */
export function widgetOf(p: any): "knob" | "switch" | "selector";
/**
 * Whether `widget` can draw `p`: a switch a toggle; a selector an integer travel (every step an
 * option); a knob or a fader a travel with no labelled values (labels are a selector's) and no toggle.
 */
export function widgetFits(widget: any, p: any): boolean;
/** The widget a control of `panel` is drawn with: the panel's `widgets` entry, else widgetOf. */
export function widgetFor(panel: any, symbol: any, p: any): any;
/** A selector's options, `{value, label}` from min up: the labelled values, else every step. */
export function optionsOf(p: any): any;
/** Where a value sits on its travel, 0..1 (every declared travel is linear). */
export function travelFraction(p: any, v: any): number;
/**
 * Where a curve's stroke, axis and marks fall inside its frame of `cw` x `ch` device px at scale `s`, relative to the frame's corner: the
 * mapping of renderer/src/view.c `draw_curve`, operation for operation (an eq_response on a log frequency axis with the dB symmetric about 0
 * to the next 6 dB; a transfer_curve on linear dB, input and output on one span), so the two rasterisers draw one stroke.
 */
export function curveGeometry(curve: any, kind: any, cw: any, ch: any, s: any): {
    axis: number[];
    poly: any;
    marks: any;
} | null;
/** The panel a descriptor is drawn with: the declared one, else the layout's sections and family over its
 * groups and meanings (tools/panel-description.mjs); with `wantEasyFirst` (--easy-first), the Easy controls first. */
export function panelOf(descriptor: any, declared: any, wantEasyFirst?: boolean): any;
/** The panel of a descriptor, resolved: each section with its controls, each control its descriptor control's
 * symbol, name and travel. `stem` names the files. */
export function resolvePanel(descriptor: any, { panel: declared, stem, easyFirst: wantEasyFirst }: {
    panel: any;
    stem: any;
    easyFirst?: boolean | undefined;
}): {
    uri: any;
    stem: any;
    name: any;
    brand: any;
    family: any;
    sections: any;
    skipped: any[];
};
/** Every box of the face, in px at scale 1: what the template positions and the raster paints. */
export function layout(panel: any): {
    w: number;
    h: any;
    sections: any;
};
/** The look: tools/look.json, every colour a plain #rrggbb. */
export function loadLook(): {
    theme: any;
    personality: any;
    tokens: {};
    font: {
        unitsPerEm: number;
        ascent: number;
        descent: number;
        glyph(ch: any): any;
    };
};
/** The default a control shows, with its unit: a number to three significant figures, an option's label, On or Off. */
export function valueText(k: any): any;
/** The face at `scale`, every control at its declared default. */
export function renderFace(lay: any, look: any, scale: any): Buffer<ArrayBuffer>;
/** MOD's film strip: `filmFrames` square frames left to right, the knob from minimum to maximum. */
export function renderFilm(tok: any): Buffer<ArrayBuffer>;
/** The fader's film strip: the same square frames, the fader from minimum to maximum. */
export function renderFaderFilm(tok: any): Buffer<ArrayBuffer>;
/** `modgui.ttl`: the gui resource, and `modgui:port` for every input control of the FIRST section (a readout is
 * none); a modgui:port's lv2:index is its order on the pedal, its symbol and name the LV2 port's. */
export function emitModguiTtl(panel: any, source: any): string;
/** The icon template, in MOD's documented format: every section and every control, laid out. */
export function emitTemplate(panel: any, lay: any, source: any): string;
/** The stylesheet: the GEOMETRY and the look's resolved tokens, scoped by MOD's {{{cns}}}. */
export function emitStylesheet(panel: any, look: any, source: any): string;
/** The modgui's script, in MOD's documented format (a function of the event and MOD's helpers): on start and on each port
 * change, every control that names the changed port as its governing one is shown while bit `value` of its mask is set. */
export function emitScript(source: any): string;
/** Every file of a descriptor's modgui, as [path relative to the LV2 bundle, bytes], in a fixed order. `source`
 * is what the banner names the files were made from. */
export function generateModgui(descriptor: any, { panel: declared, stem, source, easyFirst: wantEasyFirst }: {
    panel: any;
    stem: any;
    source: any;
    easyFirst?: boolean | undefined;
}, look?: {
    theme: any;
    personality: any;
    tokens: {};
    font: {
        unitsPerEm: number;
        ascent: number;
        descent: number;
        glyph(ch: any): any;
    };
}): (string | Buffer<ArrayBuffer>)[][];
/**
 * Whether a bundle manifest points a lilv host at modgui.ttl: a seeAlso triple with that object, read as Turtle, so any
 * spelling and any place in an object list. A manifest that is not Turtle throws, naming the line: lilv cannot read it either.
 */
export function manifestSeesModgui(text: any): boolean;
/** The manifest with `<uri> rdfs:seeAlso <modgui.ttl>` added, or unchanged when it already has it. */
export function withModguiSeeAlso(text: any, uri: any): any;
export function main(argv: any): void;
export { LOOK_JSON };
/** The shared widgets, schema/panel.schema.json's `$defs.widget`: the one list a plugin's schema, this generator
 * and the console name a control's widget from. */
export const WIDGETS: any;
/** The widgets the MOD GUI draws: the controls a plugin's own parameters take; the others are read-only or a graph. */
export const DRAWN_WIDGETS: readonly string[];
export const MODGUI_TTL: "modgui.ttl";
export const MODGUI_DIR: "modgui";
/** An integer travel with more steps than this is a continuous knob; fewer is a selector. */
export const MAX_SELECTOR_STEPS: 16;
/** The controls of one row of a section; a section with more wraps onto further rows. */
export const ROW_CONTROLS: any;
/** The geometry, in CSS px: one set of numbers the template, the stylesheet and the raster read. */
export const GEOMETRY: any;
/** A choice control whose descriptor states ids (and labels) but no `values`: the value the plugin reads for an id is
 * the descriptor's to say, an index is not it, so the generator refuses and names the control. */
export class ChoiceNoValues extends Error {
    code: string;
}
/** A descriptor with no visible control (a synth whose parameters are not LV2 ports): there is no face to make. Not a
 * fault of the descriptor; `omx-panel modgui` exits 3 for it so a sweep records a skip. */
export class NothingToDraw extends Error {
    code: string;
}
/** The rate a static curve is computed at, and the grid it is sampled on. */
export const STATIC_CURVE: Readonly<{
    sampleRate: 48000;
    points: 128;
}>;
/** The one letter a mark wears: one per planter family, as the console's band-origin.ts names it. */
export const ORIGIN_LETTER: Readonly<{
    'fbs-fixed': "F";
    'fbs-live': "F";
    hrp: "H";
    'room-mode': "R";
}>;
export function lookTokens(): {};
import { LOOK_JSON } from './look.mjs';
