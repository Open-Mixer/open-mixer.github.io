/** Parse Turtle `text` read from `base` (a URL); returns its triples in document order. */
export function parseTurtle(text: any, base: any): any[];
