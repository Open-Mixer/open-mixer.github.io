/**
 * The easy list `descriptor` (a scan) takes from `installed` (descriptors), by plugin id; undefined with none, or when a key
 * has no control in this scan: no list rather than half of one, and the rule answers.
 */
export function easyFromInstalled(descriptor: any, installed: any): any;
