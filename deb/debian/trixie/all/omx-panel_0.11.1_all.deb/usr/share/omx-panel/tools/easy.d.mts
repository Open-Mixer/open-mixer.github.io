/**
 * The symbols of the Easy face of `x`, a layout or anything with its `family`, `roles` (`role`, `index`, `symbol`) and
 * `controls` (`symbol`). `declared` is the plugin's own list, refused whole by name when it is wrong. `drawable` says which
 * controls a face can set, for a host whose controls are not the layout's.
 */
export function easyOf(x: any, { declared, drawable, where }?: {
    drawable?: ((c: any) => boolean) | undefined;
    where?: string | undefined;
}): any[];
/** The most controls a declared list names: what one surface page holds. */
export const EASY_DECLARED_MAX: 8;
/** The most the roles pick. */
export const EASY_RULE_MAX: 6;
/** The order fills up to this many when the roles gave fewer. */
export const EASY_FILL: 4;
/** Each family's roles for the Easy face, in order: what is first matters most, a screen of four shows those. */
export const EASY_ROLES: Readonly<{
    none: never[];
    gate: string[];
    dynamics: string[];
    limiter: string[];
    deesser: string[];
    eq: string[];
    filter: string[];
    drive: string[];
    modulation: string[];
    delay: string[];
    reverb: string[];
    pitch: string[];
}>;
export class EasyRefused extends Error {
    code: string;
}
