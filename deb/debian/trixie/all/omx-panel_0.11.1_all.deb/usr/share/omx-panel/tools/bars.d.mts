/** A frequency label in Hz: `100 Hz`, `1k`, `1.2 kHz`; undefined for any other label. */
export function hzOf(label: any): number | undefined;
/**
 * The bar runs of one section. `items` are the section's visible controls in order, each `{ symbol, label, control }`
 * (`control` the descriptor control); `declared` the section's `bars` word (true, false, or undefined). Answers
 * `{ runs, refusal }`: `refusal` is `{ code, why }` when a declared `bars: true` fails a check of the rule; the
 * runs are then empty. A run is `{ controls, labels, tied }`.
 */
export function barsOf(items: any, declared: any): {
    runs: never[];
    refusal: {
        code: string;
        why: string;
    };
} | {
    runs: any[];
    refusal: null;
};
/**
 * The bar runs of a section of a served description (a skin's `sections` rebuild them): `controls` are the section's description
 * controls in order, `params` the description's params. A number with labels is a choice and a trigger or text is no travel;
 * a skin states no meaning, so the tie goes to the first run.
 */
export function barsOfDescription(controls: any, params: any, declared: any): {
    runs: never[];
    refusal: {
        code: string;
        why: string;
    };
} | {
    runs: any[];
    refusal: null;
};
export const MIN_BARS: 4;
export const MAX_BARS: 16;
/** The footages of an organ's drawbars, as setBfree and Hammond clones label them. */
export const FOOTAGES: string[];
export namespace BARS_CODES {
    let few: string;
    let kind: string;
    let facts: string;
    let series: string;
    let unknown: string;
}
