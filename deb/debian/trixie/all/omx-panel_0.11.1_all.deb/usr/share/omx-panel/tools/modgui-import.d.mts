/** Every `*.ttl` at the bundle's root, parsed; each triple carries the file it was read from. */
export function readBundle(dir: any): {
    s: any;
    p: any;
    o: any;
    file: string;
}[];
/**
 * Import one bundle into `<out>/<skinPackageDirName(plugin)>/`. Returns the written package or
 * throws a {@link Refusal}; on a refusal nothing exists under `out` that was not there before.
 */
export function importModgui({ bundle, out, plugin }: {
    bundle: any;
    out: any;
    plugin: any;
}, core: any): {
    dir: string;
    skin: {
        backdrop?: string | undefined;
        schema: any;
        plugin: any;
        licence: string;
        source: {
            kind: string;
            bundle: string;
            licenceEvidence: string;
        };
        sections: {
            controls: string[];
            label?: any;
            key: string;
        }[];
        labels: {
            [k: string]: {
                label: any;
            };
        };
    };
    brand: any;
    label: any;
};
