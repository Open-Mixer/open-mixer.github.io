/** gesture_words.h's text. */
export function emitWordsHeader(words: any): string;
/** The OMX_PANEL_WORD_* names of omx_panel_word_t, in order, NONE first. */
export function enumWords(text?: string): (string | undefined)[];
/** Every problem of the header and the enum against gestures.json. */
export function problems(words: any, header: any, enumNames: any): string[];
export const WORDS_HEADER: string;
export function declaredWords(doc?: any): string[];
