// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
/*
 * describe.mjs — the one derivation of a plugin's panel description (the one-panel spec §3.1): the descriptor, a user's
 * override layers and a skin in; the description every surface draws, and the refusals, out. It never throws: each
 * throw of the layout (no controls, a bad key, a family its meanings do not back, a bar group the rule refuses)
 * is a refusal by code.
 *
 *   describe(descriptor, { overrides, applyOverride, skin, panel, ns }) -> { description, refusals }
 *   describe(descriptor, { ..., withLayout: true }) -> { description, refusals, layout }: the derived layout the description was made
 *   from, what the renderer draws (renderer/include/omx_panel_render.h), so a host draws exactly what it describes
 *
 * - the override layers are omx-contract's `applyOverride` over the descriptor (the caller passes the function; omx-contract
 *   does not export it from its package entry), before the layout;
 * - the PARAMS are the effective descriptor's controls as contract facts: kind, unit and its token, scale, step, ends,
 *   default and the labels of a choice (`log` over a floor at or below zero is served linear, the same rule as omx-contract's
 *   `contract.override.scale-floor`; a default outside the ends is the floor; a choice is a stepped number, labelled only
 *   when every value is an integer; a gain the band inference reads as a linear factor, its unit unstated, is `coef`);
 * - every SYMBOL the description serves is the name a host sets the parameter by (`servedSymbolOf`): an LV2 control's symbol,
 *   a CLAP parameter's id in decimal. The layout's own key of a CLAP control, `p<id>`, stays inside the layout;
 * - the FAMILY is the one general rule of §3.1.1: a candidate from the plugin's own LV2 class or CLAP feature (a fixed
 *   table, no list of plugins), kept only when the controls back every required role of the family, from descriptor
 *   words or from the meaning inference (tools/meaning-infer.mjs, each role `inferred`); else `none`. A declared panel's
 *   family, or a user's override naming one, wins and is applied as the layout applies it;
 * - the DISPLAYS of a derived panel are the family's closed form on the section holding its required roles, each with its
 *   `basis`: `exact` only when an authored descriptor declares it, else `modelled`;
 * - the ROLES carry `unit` (the contract token), `inferred`, a band's `shape` and a band-type role's `shapes`;
 * - the SECTIONS carry `bars` (tools/bars.mjs), a view of the panel that stays out of the fingerprint;
 * - the skin applies last of the derivation, by `applySkinOverride` (its sections, its `easy`), and the PAGES are cut after it by
 *   `pagesOf`, the one cut (`perPage`, the surface's width, left out eight; `remote`, the host's declared remote-controls pages).
 */
import { applySkinOverride } from '../src/skin-package.js';
import { inferBands } from './meaning-infer.mjs';
import { FamilyNotBacked, NoControls, BarsRefused, FAMILIES, familyOf, GROUP, keyOf, pagesOf, panelFingerprint, panelLayout, requiredRolesMapped, unitToken } from './panel-description.mjs';

/** The refusal codes of the derivation, beside the layout's and the bar rule's. */
export const DESCRIBE_CODES = {
  noControls: 'panel.describe.no-controls',
  familyNotBacked: 'panel.describe.family-not-backed',
  layoutInvalid: 'panel.describe.layout-invalid',
  overrideUnavailable: 'panel.describe.override-unavailable',
  overrideRefused: 'panel.describe.override-refused',
  overrideDropped: 'panel.describe.override-dropped',
  roleDropped: 'panel.describe.role-dropped',
  skinDropped: 'panel.describe.skin-dropped',
  meterRefused: 'panel.describe.meter-refused',
  paramUnserved: 'panel.describe.param-unserved',
};

/** The LV2 range of a patch parameter -> the kind it is served as: a file (atom:Path) or a text (atom:String). */
const TEXT_KIND_OF_RANGE = {
  Path: 'path', 'atom:Path': 'path', 'http://lv2plug.in/ns/ext/atom#Path': 'path',
  String: 'text', 'atom:String': 'text', 'http://lv2plug.in/ns/ext/atom#String': 'text',
};

/**
 * The path and text parameters a descriptor declares (#17): an LV2 plugin's patch:writable lv2:Parameters, as a scan
 * writes them under `extensions.lv2["patch:writable"]` ({ uri, label, range }, and a `symbol` where a host names it), served
 * as `{ kind: 'path' | 'text', symbol, name, default }`: the symbol is the one stated, else the parameter URI's fragment
 * (else its last segment), the name its label, the
 * default empty. One of another range is not served: it is listed apart (`unserved`, its symbol and range), for a refusal.
 */
export function textParamsOf(descriptor) {
  const writable = descriptor.extensions?.lv2?.['patch:writable'];
  const list = Array.isArray(writable) ? writable : writable ? [writable] : [];
  const served = [];
  const unserved = [];
  for (const p of list) {
    const uri = typeof p === 'string' ? p : p?.uri;
    if (typeof uri !== 'string' || uri === '') continue;
    // a symbol the entry states wins (a host's own name for it); else the URI's fragment, else its last segment
    const stated = typeof p === 'object' && typeof p.symbol === 'string' && p.symbol !== '' ? p.symbol : undefined;
    const symbol = stated ?? (uri.includes('#') ? uri.slice(uri.lastIndexOf('#') + 1) : uri.slice(uri.lastIndexOf('/') + 1));
    const range = typeof p === 'object' ? p.range : undefined;
    const kind = TEXT_KIND_OF_RANGE[range];
    if (kind) served.push({ kind, symbol, name: (typeof p.label === 'string' && p.label) || symbol, default: '' });
    else unserved.push({ symbol, range: range ?? null });
  }
  return { served, unserved };
}

/** What a plugin declares about itself (an LV2 class, a CLAP feature) -> the family whose closed form omx-panel knows. */
export const FAMILY_OF_DECLARED = {
  'lv2:EQPlugin': 'eq', 'lv2:ParaEQPlugin': 'eq', equalizer: 'eq',
  'lv2:CompressorPlugin': 'dynamics', compressor: 'dynamics',
  'lv2:GatePlugin': 'gate', 'lv2:ExpanderPlugin': 'gate', gate: 'gate',
  'lv2:DistortionPlugin': 'drive', distortion: 'drive',
};

const LV2_CORE = 'http://lv2plug.in/ns/lv2core#';

/**
 * The classes and features the descriptor carries as the plugin states them: its extension bag, `extensions.lv2` (a class
 * as a field, `lv2:CompressorPlugin`, or among `rdf:type`'s values) and `extensions.clap`
 * (`clap_plugin_descriptor.features`). A scan spells a CLAP feature by its macro (`CLAP_PLUGIN_FEATURE_EQUALIZER`, the format
 * table's term), a declaration by its string (`equalizer`): the macro is read as the string it stands for.
 */
export function declaredOf(descriptor) {
  const lv2 = descriptor.extensions?.lv2 ?? {};
  const clap = descriptor.extensions?.clap ?? {};
  const out = new Set(Object.keys(lv2).filter((k) => lv2[k] !== false && lv2[k] !== null));
  for (const t of [lv2['rdf:type']].flat()) if (typeof t === 'string') out.add(t.startsWith(LV2_CORE) ? `lv2:${t.slice(LV2_CORE.length)}` : t);
  for (const f of [clap['clap_plugin_descriptor.features']].flat()) if (typeof f === 'string') out.add(clapFeature(f));
  return [...out];
}

const CLAP_FEATURE_MACRO = 'CLAP_PLUGIN_FEATURE_';
/** A CLAP feature as the string the format defines: CLAP_PLUGIN_FEATURE_DE_ESSER is "de-esser". */
const clapFeature = (f) => (f.startsWith(CLAP_FEATURE_MACRO) ? f.slice(CLAP_FEATURE_MACRO.length).toLowerCase().replaceAll('_', '-') : f);

/** The candidate families of a descriptor's declarations, in the table's order and without repeats. */
export const candidatesOf = (descriptor) => [...new Set(declaredOf(descriptor).map((d) => FAMILY_OF_DECLARED[d]).filter(Boolean))];

// ---- the params: the effective descriptor's controls as contract facts ----

/** The numbers of a mask as the values that set its bits, 0..63. */
const valuesOfMask = (mask) => {
  const m = typeof mask === 'string' ? BigInt(`0x${mask}`) : BigInt(mask);
  return Array.from({ length: 64 }, (_, v) => v).filter((v) => ((m >> BigInt(v)) & 1n) === 1n);
};

/**
 * The name a host sets a control's parameter by, and the one every symbol of the description is: the control's symbol, else
 * its id as text (a CLAP parameter's id in decimal, the key the console's sessions and parameter doors hold it under).
 */
export const servedSymbolOf = (c) => c.symbol ?? (typeof c.id === 'string' || Number.isInteger(c.id) ? String(c.id) : keyOf(c));

/** The widest span of integers a choice is labelled over: one label each, a 16-bit index. */
const LABEL_SPAN = 1 << 16;

/**
 * One control as the contract facts the description serves (§3.1 `params`). `factor`: the band inference reads it as a gain
 * in a linear factor, so a unit the descriptor leaves unstated is `coef`.
 */
export function servedParamOf(c, { factor = false } = {}) {
  const symbol = servedSymbolOf(c);
  const name = c.label ?? c.name ?? symbol;
  if (c.kind === 'trigger') return { kind: 'trigger', symbol, name, min: 0, max: 1 };
  if (c.kind === 'toggle') return { kind: 'number', symbol, name, unit: 'none', scale: 'stepped', step: 1, min: 0, max: 1, default: c.default === true ? 1 : 0 };
  if (c.kind === 'choice') {
    const values = c.values ?? c.ids.map((_, i) => i);
    const min = Math.min(...values), max = Math.max(...values);
    const at = c.ids.indexOf(c.default);
    const labels = c.labels ?? c.ids;
    // one label per integer of the span, only when every value is one: a value between two integers has no slot of a
    // stepped number, so its label would be lost and another put in its place. A sparse choice (FFT sizes 128..16384) takes
    // a label per integer between, as the console's derivation served it; past a 16-bit span no list is made
    const enumLabels = values.every(Number.isInteger) && max - min < LABEL_SPAN ? Array.from({ length: max - min + 1 }, (_, k) => labels[values.indexOf(min + k)] ?? String(min + k)) : undefined;
    // a stepped number's default is an integer inside its ends, as a stepped travel's is
    const fallback = at >= 0 ? values[at] : min;
    return { kind: 'number', symbol, name, unit: 'none', scale: 'stepped', step: 1, min, max, default: Math.min(max, Math.max(min, Math.round(fallback))), ...(enumLabels ? { enumLabels } : {}) };
  }
  const t = c.travel;
  const stated = t.unit && t.unit !== 'unknown';
  const token = factor && !stated ? 'coef' : unitToken(t.unit);
  const stepped = t.scale === 'stepped' || (t.step ?? 0) >= 1;
  // log over a floor at or below zero is served linear (contract.override.scale-floor)
  const scale = stepped ? 'stepped' : t.scale === 'log' && t.min > 0 ? 'log' : 'linear';
  // the default rides only inside the ends; one outside them (a TTL's typo, 440 on a 0..0.5 travel) is the floor
  const at = typeof t.default === 'number' && t.default >= t.min && t.default <= t.max ? t.default : t.min;
  return {
    kind: 'number', symbol, name, unit: token ?? 'none',
    ...(token === undefined && t.unit && t.unit !== 'unknown' ? { unitText: t.unit } : {}),
    scale, step: stepped ? Math.max(1, t.step ?? 1) : 0, min: t.min, max: t.max,
    default: stepped ? Math.min(t.max, Math.max(t.min, Math.round(at))) : at,
  };
}

// ---- the layout of a candidate family, and the family rule ----

/** The layout of `descriptor` under `family`, with the bands the meanings leave unnamed inferred (family `eq` only). */
function layoutUnder(descriptor, family, options) {
  const inferred = family === 'eq' ? inferBands(descriptor.controls) : null;
  return panelLayout(descriptor, { ...options, family, derive: true, inferredRoles: inferred?.outcome === 'inferred' ? inferred.roles : undefined, completingRoles: completing(descriptor, family) });
}

/** The bands as the inference reads them with every stated meaning set aside: what completes a band the words name with
 * the Q, type and switch they leave unnamed (panelLayout's `completingRoles`). Family `eq` only. */
function completing(descriptor, family) {
  if (family !== 'eq') return undefined;
  const all = inferBands(descriptor.controls.map((c) => ({ ...c, meaning: undefined })));
  return all.outcome === 'inferred' ? all.roles : undefined;
}

/**
 * The family and layout of a plugin that declares no panel and has no override naming one (§3.1.1). One candidate from the
 * plugin's declarations, kept when the layout under it maps every required role; two or more candidates give a family only
 * when exactly one of them is kept; none, or no kept one, is `none`.
 */
export function familyRule(descriptor, options) {
  const kept = [];
  for (const family of candidatesOf(descriptor)) {
    const layout = layoutUnder(descriptor, family, options);
    if (requiredRolesMapped(family, layout.roles)) kept.push({ family, layout });
  }
  if (kept.length === 1) return kept[0];
  return { family: 'none', layout: layoutUnder(descriptor, 'none', options) };
}

const refuse = (code, args = {}) => ({ code, args });

/**
 * The description of `descriptor` and the refusals, as the header says. `description` is null when no panel can be made
 * (no control, an invalid layout); a declared family the controls do not back is `none` with its refusal.
 */
export function describe(descriptor, { overrides = [], applyOverride, skin, panel, ns, where, perPage, remote, withLayout = false } = {}) {
  const refusals = [];
  const plugin = descriptor.plugin?.id;
  let effective = descriptor, userFamily;
  if (overrides.length > 0) {
    if (typeof applyOverride !== 'function') refusals.push(refuse(DESCRIBE_CODES.overrideUnavailable, { plugin, layers: overrides.length }));
    else {
      const r = applyOverride(descriptor, overrides, {});
      effective = r.descriptor;
      userFamily = r.family;
      for (const x of r.refused ?? []) refusals.push(refuse(DESCRIBE_CODES.overrideRefused, { plugin, layer: x.layer, name: x.name, message: x.message }));
      for (const x of r.dropped ?? []) refusals.push(refuse(DESCRIBE_CODES.overrideDropped, { plugin, layer: x.layer, control: x.control, name: x.name, message: x.message }));
    }
  }
  const options = { panel, ns, ...(where ? { where } : {}) };
  const texts = textParamsOf(effective);
  for (const u of texts.unserved) refusals.push(refuse(DESCRIBE_CODES.paramUnserved, { plugin, symbol: u.symbol, range: u.range }));
  let layout;
  // a declared family the controls do not back is refused by code and the panel is `none`: the plain sections
  const tryDeclared = (make) => {
    try {
      return make();
    } catch (e) {
      if (!(e instanceof FamilyNotBacked)) throw e;
      refusals.push(refuse(DESCRIBE_CODES.familyNotBacked, { plugin, message: e.message }));
      return panelLayout(effective, { ...options, panel: undefined, family: 'none', derive: true });
    }
  };
  try {
    if (panel) {
      // a declared panel's family, or a user's override over it, is applied as the layout applies it
      layout = tryDeclared(() => panelLayout(effective, { ...options, panel: userFamily === undefined ? panel : { ...panel, family: userFamily }, derive: true }));
    } else if (userFamily !== undefined) {
      const family = FAMILIES.includes(userFamily) ? userFamily : 'none';
      const inferred = family === 'eq' ? inferBands(effective.controls) : null;
      const { needs } = familyOf(effective.controls, family);
      layout = tryDeclared(() => {
        if (needs) throw new FamilyNotBacked(`${plugin}: the ${family} family needs a control meaning ${needs.join(' or ')}`);
        return panelLayout(effective, { ...options, family, derive: true, inferredRoles: inferred?.outcome === 'inferred' ? inferred.roles : undefined, completingRoles: completing(effective, family) });
      });
    } else layout = familyRule(effective, options).layout;
  } catch (e) {
    // a plugin whose only parameters are paths or texts still has a panel: one section holding their controls
    if (e instanceof NoControls && texts.served.length > 0) layout = textOnlyLayout(effective);
    else {
      const code = e instanceof NoControls ? DESCRIBE_CODES.noControls : e instanceof BarsRefused ? e.code : DESCRIBE_CODES.layoutInvalid;
      refusals.push(refuse(code, { plugin, message: e.message }));
      return { description: null, refusals };
    }
  }
  // the layout keys a control by keyOf; the description serves the name a host sets it by
  const servedOf = new Map(effective.controls.map((c) => [keyOf(c), servedSymbolOf(c)]));
  const served = (key) => servedOf.get(key) ?? key;
  for (const u of layout.unpublished) refusals.push(refuse(DESCRIBE_CODES.roleDropped, { plugin, entry: u.role, symbol: served(u.symbol), reason: u.why }));

  for (const m of layout.meterRefusals ?? []) refusals.push(refuse(DESCRIBE_CODES.meterRefused, { plugin, symbol: m.symbol, reason: m.reason }));

  const factors = new Set(layout.roles.filter((r) => r.role === 'band_gain' && r.inferred && (r.token ?? r.unit) === 'coef').map((r) => r.symbol));
  // a path or text parameter is served after the controls' facts, and drawn as a control of the panel's last section
  const params = [...effective.controls.map((c) => servedParamOf(c, { factor: factors.has(keyOf(c)) })), ...texts.served];
  const textSection = layout.sections.at(-1)?.key;
  const textControls = texts.served.map((t) => ({ symbol: t.symbol, section: textSection, widget: 'auto', labelKey: '', label: t.name, visibleWhen: null }));
  const visibleWhen = (c) => (c.visibleWhen ? { param: served(c.visibleWhen.symbol), values: valuesOfMask(c.mask) } : null);
  let description = {
    family: layout.family,
    fingerprint: panelFingerprint(layout),
    // the Easy controls, a view of the panel (the descriptor's own list, else the roles', tools/easy.mjs)
    easy: layout.easy.map(served),
    params,
    sections: layout.sections.map((s) => ({ key: s.key, labelKey: s.labelKey ?? '', label: s.label, ...(s.bars ? { bars: s.bars } : {}) })),
    controls: [...layout.controls.map((c) => ({ symbol: served(c.symbol), section: c.sectionKey, widget: c.widget, labelKey: c.labelKey ?? '', label: c.label, visibleWhen: visibleWhen(c) })), ...textControls],
    // the meters (contract 7.9): a meter control each, in the descriptor's order. Facts of the view, never ballistics.
    meters: layout.meters.map((m) => ({ symbol: m.symbol, section: m.sectionKey, kind: m.kind, measurement: m.measurement, unit: m.unit, min: m.min, max: m.max, channels: m.channels, held: m.held, clip: m.clip, labelKey: m.labelKey ?? '', label: m.label })),
    roles: layout.roles.map((r) => {
      const { role, index } = r;
      return { role, index, symbol: served(r.symbol), unit: r.token ?? unitToken(r.unit) ?? 'none', ...(r.shape ? { shape: r.shape } : {}), ...(r.shapes ? { shapes: r.shapes } : {}), ...(r.inferred ? { inferred: true } : {}) };
    }),
    displays: layout.displays.map((d) => ({ kind: d.kind, section: d.sectionKey, source: d.source, meterIds: d.meters, curveIndex: d.curve, floor: d.floor, labelKey: d.labelKey ?? '', label: d.label, basis: d.basis ?? 'modelled' })),
  };
  if (skin) {
    const applied = applySkinOverride(description, skin);
    description = applied.description;
    for (const d of applied.dropped) refusals.push(refuse(DESCRIBE_CODES.skinDropped, { plugin, field: d.field, entry: d.entry, reason: d.reason }));
  }
  // the pages are cut last, over the description as the skin left it: its sections, its order, its visibility
  description = { ...description, pages: pagesOfDescription(description, effective, layout, servedOf, { perPage, remote }) };
  return withLayout ? { description, refusals, layout } : { description, refusals };
}

/** The layout of a plugin with no control to lay out but path or text parameters: one plain section for them, family
 * `none`, nothing else (its fingerprint is that section's; the parameters themselves are facts of `params`). */
function textOnlyLayout(descriptor) {
  return {
    origin: descriptor.origin, family: 'none', sections: [{ key: 'controls', labelKey: 'section.controls', label: 'Controls' }],
    controls: [], roles: [], unpublished: [], displays: [], defaults: [], ports: { inputs: [], outputs: [], sidechain: false, notes: false }, easy: [], meters: [], meterRefusals: [],
  };
}

/** The page cut over a description (a skin's sections and order included): a surface slot drives a number, never a path or a text. */
function pagesOfDescription(description, effective, layout, servedOf, { perPage, remote }) {
  const idOf = new Map(effective.controls.map((c) => [servedSymbolOf(c), c.id]));
  const groupOf = new Map(layout.controls.map((c) => [servedOf.get(c.symbol) ?? c.symbol, c[GROUP]]));
  const default_ = (symbol) => description.params.find((p) => p.symbol === symbol)?.default ?? 0;
  const numeric = (c) => description.params.find((p) => p.symbol === c.symbol)?.kind === 'number';
  const controls = description.controls.filter(numeric).map((c) => {
    const at = description.sections.findIndex((s) => s.key === c.section);
    const gov = c.visibleWhen;
    return {
      symbol: c.symbol, label: c.label || description.params.find((p) => p.symbol === c.symbol)?.name || c.symbol, section: at, param: idOf.get(c.symbol),
      ...(groupOf.get(c.symbol) ? { [GROUP]: groupOf.get(c.symbol) } : {}),
      ...(gov ? { visible: idOf.get(gov.param), mask: gov.values.reduce((m, v) => m | (1n << BigInt(v)), 0n), visibleWhen: { symbol: gov.param, default: default_(gov.param) } } : { visible: null, mask: 0n }),
    };
  });
  return pagesOf({ sections: description.sections, controls, easy: description.easy }, { perPage, remote });
}

