/** The contract directories, in the order they are read: `$OMX_CONTRACT_PATH`, else omx-contract's `contractdir`,
 * else the default. */
export function contractDirs(): string[];
/** The directory `<contractdir>/<package>` of the first contract directory that holds it, or undefined. */
export function packageDir(pkg: any): string | undefined;
/** The directories the panel domain is opened from: `$OMX_CONTRACT_PATH`, this tree's `contract.d`, then omx-contract's
 * `contractdir` (where omx-panel-contract installs it); the first that holds `panel/panel.json` wins. */
export function panelDomainDirs(): string[];
/** omx-contract's own data directory: its pkg-config `datadir`, else the default. */
export function contractDataDir(): string;
/** The installed omx-contract schema, where the descriptor words are declared. */
export function contractSchemaFile(): string;
/** The meaning role `role` plays, or undefined: a role no package declares, one declared `unknown`, or one whose meaning
 * the installed schema does not list plays none, whatever its name (a role is looked up, never read as a meaning). */
export function meaningOfRole(role: any): any;
/** omx-contract's param domain document, `<contractdir>/param/param.json`, from the first contract directory holding it. */
export function paramDomainFile(): string | undefined;
/** The descriptor file a package installed into omx-contract's contract directory, `<package>/<name>`:
 * `<contractdir>/<package>/plugins/<name>.json`. */
export function installedDescriptorFile(ref: any): string;
/** Every descriptor file installed under the contract directories, sorted: `<contractdir>/<package>/plugins/*.json`. A
 * `<package>/<name>` installed under several contract directories is listed once, from the first that holds it. */
export function installedDescriptorFiles(): any[];
/** A panel domain item's words by title (`PANEL_GROUP_REASONS` -> `{ noControls: 'no-controls', ... }`): the codes and
 * words the tools emit, read from the panel domain; a title the item lacks is refused by name, never undefined. */
export function panelCodes(item: any): Readonly<{
    [k: string]: string;
}>;
/**
 * The words a panel surface draws of its own (the panel domain's PANEL_LABELS, omx-panel#13): `{ <title>: { labelKey, label } }`,
 * the key the word (`panel.label.meters`) and the label its English sentence (x-text), from the first domain directory that
 * holds panel/panel.json, as the loader opens it. A description serves them in `words`; no surface spells one.
 */
export function panelLabels(): Readonly<{
    [k: string]: Readonly<{
        labelKey: string;
        label: any;
    }>;
}>;
/** Where omx-contract-data installs its files and the contract directory, for an install with no omx-contract.pc. */
export const DEFAULT_DATADIR: "/usr/share/omx-contract";
export const DEFAULT_CONTRACTDIR: "/usr/share/omx-contract/contract.d";
export function panelWords(item: any): string[];
export function meanings(): any;
export function roleMeanings(): any;
export function standardUnits(): any;
export function unitIdOf(unit: any): any;
export function lv2UnitIds(): any;
export function unitSymbolOf(unit: any): any;
export function noUnitId(): any;
export function unitsOfDimensions(dimensions: any): any[];
/** The units the param-contract extension serves are omx-contract's (V23d, P2): PARAM_UNITS_CLAP_ENCODED of its param
 * domain, a words item whose words are the standard ids org.openmixer.param-contract/1 encodes. */
export const CLAP_ENCODED_ITEM: "PARAM_UNITS_CLAP_ENCODED";
export function clapEncoded(): any;
export function servedUnit(id: any): any;
