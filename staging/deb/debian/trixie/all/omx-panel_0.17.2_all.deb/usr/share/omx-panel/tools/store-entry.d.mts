/** The verdict as the store holds it; null for a plugin with none (a CLAP plugin states no port groups). */
export function verdictEntry(verdict: any): {
    outcome: any;
    reason: any;
    groups: any;
} | null;
/**
 * The entry `omx-panel-store put` takes for one derivation. `derived` is `describeStored`'s answer: a stored derivation
 * is the body, the controls and the repeated groups; a refused one is stored as its refusing code.
 * @param {{ derived: { stored: any, refusals: { code: string }[] }, verdict?: any, source: string, rules: number, madeBy: string }} o
 */
export function entryOf({ derived, verdict, source, rules, madeBy }: {
    derived: {
        stored: any;
        refusals: {
            code: string;
        }[];
    };
    verdict?: any;
    source: string;
    rules: number;
    madeBy: string;
}): {
    family: string;
    fingerprint: string;
    body: null;
    groups: null;
    refused: string;
    controls: never[];
    edited: number;
    made_by: string;
    rules: number;
    source: string;
    verdict: {
        outcome: any;
        reason: any;
        groups: any;
    } | null;
} | {
    family: any;
    fingerprint: any;
    body: any;
    groups: any;
    refused: null;
    controls: any;
    edited: number;
    made_by: string;
    rules: number;
    source: string;
    verdict: {
        outcome: any;
        reason: any;
        groups: any;
    } | null;
};
/**
 * What `describeFromStored` reads, from an `omx-panel-store get` answer of a key of `format`; null for a refused entry
 * (it has no description to serve).
 * @param {any} answer
 * @param {'clap' | 'lv2'} format
 * @param {string} [plugin] the plugin's id, named in a refusal
 */
export function storedOf(answer: any, format: "clap" | "lv2", plugin?: string): {
    plugin: string | undefined;
    body: any;
    groups: any;
    controls: any;
} | null;
/**
 * `descriptor` with each control that states no group placed in its stored group (3.4): a grouped verdict's group, by
 * the control's port symbol. A control that states a group keeps it.
 */
export function withStoredGroups(descriptor: any, verdict: any): any;
export const WORD_OF_RULE: readonly (string | undefined)[];
/** Each PANEL_GROUP_RULES word back to its inference rule's number. */
export const RULE_OF_WORD: Map<string | undefined, number>;
/** The fingerprint of a refused derivation: no layout was made, and the column is NOT NULL. */
export const NO_LAYOUT: string;
