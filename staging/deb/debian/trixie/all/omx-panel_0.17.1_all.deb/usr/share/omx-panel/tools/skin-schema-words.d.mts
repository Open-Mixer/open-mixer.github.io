/** The schema's text with its family, display kind and display source enums the domain's words. */
export function skinSchemaText(text?: string): string;
export const SCHEMA_FILE: string;
