export const BANDS: {
    hz: number;
    db: number;
    peakDb: number;
}[];
export const CURVE: {
    hz: number;
    gain: number;
}[];
export function gainAt(hz: any): number;
export const PRE: {
    hz: number;
    db: number;
    peakDb: number;
}[];
