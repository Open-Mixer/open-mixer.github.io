/**
 * The pass's store half. Returns { described, noDescriptor, pruned, failed } and logs each plugin it could not store and
 * each key it pruned; `failed` counts the store's refusals (a plugin with no descriptor is no failure: nothing to derive).
 * @param {{ lv2Path: string, env?: NodeJS.ProcessEnv, log?: (line: string) => void }} o
 */
export function pass({ lv2Path, env, log }: {
    lv2Path: string;
    env?: NodeJS.ProcessEnv;
    log?: (line: string) => void;
}): {
    described: number;
    noDescriptor: number;
    pruned: number;
    failed: number;
    store: boolean;
};
