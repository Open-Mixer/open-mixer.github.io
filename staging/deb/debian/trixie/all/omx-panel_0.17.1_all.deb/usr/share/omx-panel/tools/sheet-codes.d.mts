/** The code of the sheet's `key` (`panelEasyRefused` -> `panel.describe.easy-refused`); a key the sheet lacks is refused by name. */
export function codeOf(key: any): any;
