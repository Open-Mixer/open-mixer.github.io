/** The declaration the domain gives, in the shape of schema/gestures.json; refused by item when the domain does not hold together. */
export function declarationOf(doc: any): {
    schema: any;
    title: any;
    description: any;
    timings: any;
    thresholds: any;
    words: {
        [k: string]: any;
    };
    inputs: any;
    table: any;
    paint: any;
    codes: {
        [k: string]: any;
    };
    exceptions: any;
};
/** The domain document of `dir` (a contract directory), read and refused as declarationOf refuses. */
export function readDomain(dir?: string): any;
/** schema/gestures.json's text for a domain document. */
export function renderGestures(doc: any): string;
export const CONTRACT_DIR: string;
export const SCHEMA_FILE: string;
export class GesturesDomainError extends Error {
}
export function declarationIn(dir?: string): {
    schema: any;
    title: any;
    description: any;
    timings: any;
    thresholds: any;
    words: {
        [k: string]: any;
    };
    inputs: any;
    table: any;
    paint: any;
    codes: {
        [k: string]: any;
    };
    exceptions: any;
};
