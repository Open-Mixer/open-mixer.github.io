/**
 * A descriptor control as the travel this generator draws: `{ kind, min, max, def, points? }`, `kind` `toggle`
 * (0..1), `integer` (a choice, or a travel of step 1) or none (a continuous travel); a choice's `points` are its
 * values and labels, `{value, label}` from the lowest. Undefined for a control with no travel to draw (a trigger,
 * a text, a read-only reading).
 */
export function travelOf(c: any): {
    kind: string;
    min: number;
    max: number;
    def: number;
    points?: undefined;
} | {
    kind: string;
    min: any;
    max: any;
    def: any;
    points: any;
} | {
    min: any;
    max: any;
    def: any;
    unit: any;
    kind?: string | undefined;
    points?: undefined;
} | undefined;
/**
 * The widget a declared parameter takes when its panel names none: a toggle is a switch; a parameter with
 * labelled values (a choice, an enumeration port) or an integer with a few steps is a selector,
 * MOD's own `custom-select` over the port's values; an integer with a wide travel (more than
 * MAX_SELECTOR_STEPS steps, e.g. a time in ms) and every other travel is a knob.
 */
export function widgetOf(p: any): "knob" | "switch" | "selector";
/**
 * Whether `widget` can draw `p`: a switch a toggle; a selector an integer travel (every step an
 * option); a knob or a fader a travel with no labelled values (labels are a selector's) and no toggle.
 */
export function widgetFits(widget: any, p: any): boolean;
/** The widget a control of `panel` is drawn with: the panel's `widgets` entry, else widgetOf. */
export function widgetFor(panel: any, symbol: any, p: any): any;
/** A selector's options, `{value, label}` from min up: the labelled values, else every step. */
export function optionsOf(p: any): any;
/** Where a value sits on its travel, 0..1 (every declared travel is linear). */
export function travelFraction(p: any, v: any): number;
export function curveGeometry(curve: any, kind: any, cw: any, ch: any, s: any): {
    axis: any[];
    poly: any;
    marks: never[];
    stems: any;
} | {
    axis: number[];
    poly: any;
    marks: any;
} | null;
/** The panel a descriptor is drawn with: the declared one, else the layout's sections and family over its
 * groups and meanings (tools/panel-description.mjs); with `wantEasyFirst` (--easy-first), the Easy controls first. */
export function panelOf(descriptor: any, declared: any, wantEasyFirst?: boolean): any;
/**
 * A declared panel as one tier of the MOD GUI draws it: the sections' edge bands moved into place (an EQ's first and last
 * band are the controls another section lists, [HPF] [bands] [LPF]) and, for `easy`, only the controls the panel's `tiers` name
 * easy (a plugin that names none draws them all: nothing says easy). Returns the panel to draw, the panel as the layout reads
 * it (the declared lists, none of `tiers` or `edges`) and each edge control's band label.
 */
export function shapeDeclared(declared: any, tier: any, where: any): {
    panel: any;
    layoutPanel: any;
    bands: {};
};
/** The panel of a descriptor, resolved: each section with its controls, each control its descriptor control's
 * symbol, name and travel. `stem` names the files. */
export function resolvePanel(descriptor: any, { panel: declared, stem, easyFirst: wantEasyFirst, tier }: {
    panel: any;
    stem: any;
    easyFirst?: boolean | undefined;
    tier?: any;
}): {
    uri: any;
    stem: any;
    name: any;
    brand: any;
    family: any;
    sections: any;
    meters: any[];
    words: Readonly<{
        [k: string]: any;
    }> | null;
    skipped: any[];
};
/**
 * A repeated group's controls (docs/group-model.md) drawn as one section: its own parameters first, then the group's SERVED
 * matrix (group-model.mjs `servedMatrix`, the one `omx-panel describe` serves), read as given: the heads `drawnHeads` keeps
 * at the count's come-up value (L6), each cell at its row and column, never flowed. The section is where the group's
 * instances were, titled by the matrix; the edges (an EQ's high-pass and low-pass) are taken from whatever section holds
 * them, which keeps the rest of its controls. The count is a selector. A group some of whose controls are not drawn (an Easy
 * section took them), or whose instance section holds anything else beside the group, is left as it is.
 */
export function withRepeats(descriptor: any, declared: any, sections: any): any;
/** Every box of the face, in px at scale 1: what the template positions and the raster paints. */
/** How many cells wide a selector is: one, or as many as its widest label needs (an enumeration of long labels, the strip's stage order, is a
 * row-wide selector, never an ellipsis); the shown text is measured in the default look's font at the selector's 10 px. */
export function selectorSpan(options: any): number;
export function layout(panel: any): {
    w: number;
    h: any;
    sections: any;
    band: {
        x: any;
        y: any;
        w: number;
        h: any;
        meters: any;
        title: any;
    } | null;
};
/**
 * The look `name` (the default one when none is named): tools/look.json, every colour a plain #rrggbb, and the look's
 * own tokens, `depth`, each with its colour roles set.
 */
export function loadLook(name?: any): {
    name: any;
    theme: any;
    personality: any;
    tokens: {};
    depth: any;
    pinned: any;
    drawings: any;
    font: {
        unitsPerEm: number;
        ascent: number;
        descent: number;
        glyph(ch: any): any;
    };
};
/** The plugin's enclosure colour in `look`: the palette's entry its name picks (a one-colour palette is its colour). */
export function enclosureOf(look: any, stem: any): string | undefined;
/** The default a control shows, with its unit: a number to three significant figures, an option's label, On or Off. */
export function valueText(k: any): any;
/** The needle dials of a meters band as the template places them, in px from the band's top left: the band's meters side by side,
 * each as tall as the band's rows; given a look, each with its bezel as `border` (the place is every look's, the bezel its own). */
export function vuFaces(band: any, look: any): any;
/** The face at `scale`, every control at its declared default. */
export function renderFace(lay: any, look: any, scale: any): Buffer<ArrayBuffer>;
/** MOD's film strip: `filmFrames` square frames left to right, the knob from minimum to maximum. */
export function renderFilm(look: any): Buffer<ArrayBuffer>;
/** The fader's film strip: the same square frames, the fader from minimum to maximum. */
export function renderFaderFilm(look: any): Buffer<ArrayBuffer>;
/** `modgui.ttl`: the gui resource, and `modgui:port` for every input control of the FIRST section (a readout is
 * none); a modgui:port's lv2:index is its order on the pedal, its symbol and name the LV2 port's. */
export function emitModguiTtl(panel: any, source: any): string;
export function labelSizeOf(name: any, width: any, looks?: {
    name: any;
    theme: any;
    personality: any;
    tokens: {};
    depth: any;
    pinned: any;
    drawings: any;
    font: {
        unitsPerEm: number;
        ascent: number;
        descent: number;
        glyph(ch: any): any;
    };
}[]): any;
/** The icon template, in MOD's documented format: every section and every control, laid out. */
export function emitTemplate(panel: any, lay: any, source: any, lookName?: any): string;
/** The stylesheet: the GEOMETRY and the look's resolved tokens, scoped by MOD's {{{cns}}}. The pedal's rim is an inset shadow, not a
 * border: a border takes a pixel of layout and would set every box of the face 1 px right and down of the raster's (renderFace). */
export function emitStylesheet(panel: any, look: any, source: any, scope: any): string;
/** The modgui's script, in MOD's documented format (a function of the event and MOD's helpers): on start and on each port
 * change, every control that names the changed port as its governing one is shown while bit `value` of its mask is set. */
export function emitScript(source: any): string;
/** Every file of a descriptor's modgui, as [path relative to the LV2 bundle, bytes], in a fixed order. `source`
 * is what the banner names the files were made from. */
export function generateModgui(descriptor: any, { panel: declared, stem, source, easyFirst: wantEasyFirst, look: named, tier }: {
    panel: any;
    stem: any;
    source: any;
    easyFirst?: boolean | undefined;
    look: any;
    tier: any;
}, wornLook: any): (string | Buffer<ArrayBuffer>)[][];
/**
 * Whether a bundle manifest points a lilv host at modgui.ttl: a seeAlso triple with that object, read as Turtle, so any
 * spelling and any place in an object list. A manifest that is not Turtle throws, naming the line: lilv cannot read it either.
 */
export function manifestSeesModgui(text: any): boolean;
/** The manifest with `<uri> rdfs:seeAlso <modgui.ttl>` added, or unchanged when it already has it. */
export function withModguiSeeAlso(text: any, uri: any): any;
export function main(argv: any): void;
export { LOOK_JSON };
/** The shared widgets, schema/panel.schema.json's `$defs.widget`: the one list a plugin's schema, this generator
 * and the console name a control's widget from. */
export const WIDGETS: any;
/** The widgets the MOD GUI draws: the controls a plugin's own parameters take; the others are read-only or a graph. */
export const DRAWN_WIDGETS: readonly string[];
export const MODGUI_TTL: "modgui.ttl";
export const MODGUI_DIR: "modgui";
/** An integer travel with more steps than this is a continuous knob; fewer is a selector. */
export const MAX_SELECTOR_STEPS: 16;
/** A count (an integer travel with no unit: bands, voices, stages) may have this many values and stay a selector. */
export const MAX_COUNT_VALUES: 32;
/** The controls of one row of a section; a section with more wraps onto further rows. */
export const ROW_CONTROLS: any;
/** The geometry, in CSS px: one set of numbers the template, the stylesheet and the raster read. */
export const GEOMETRY: any;
/** The needle meters, declared once (tools/look/geometry.json, `vu`): the sweep, the orange zone, the ballistics, which kind is reversed. */
/** The label sizes a control steps through, largest first (tools/look/geometry.json `label.sizes`): a word that does not fit the cell steps the size down, never breaks. */
export const LABEL_SIZES: any;
/** The tracking of an uppercase label, in em (`label.letterSpacing`): the stylesheet's rules and the size fit read this one number. */
export const LETTER_SPACING: any;
export const VU: any;
/** A choice control whose descriptor states ids (and labels) but no `values`: the value the plugin reads for an id is
 * the descriptor's to say, an index is not it, so the generator refuses and names the control. */
export class ChoiceNoValues extends Error {
    code: string;
}
/** A descriptor with no visible control (a synth whose parameters are not LV2 ports): there is no face to make. Not a
 * fault of the descriptor; `omx-panel modgui` exits 3 for it so a sweep records a skip. */
export class NothingToDraw extends Error {
    code: string;
}
/** The rate a static curve is computed at, and the grid it is sampled on. */
export const STATIC_CURVE: Readonly<{
    sampleRate: 48000;
    points: 128;
}>;
/** The one letter a mark wears: one per planter family, as the console's band-origin.ts names it. */
export const ORIGIN_LETTER: Readonly<{
    'fbs-fixed': "F";
    'fbs-live': "F";
    hrp: "H";
    'room-mode': "R";
}>;
/** A delay tap's leg as the letter above its stem: a tap that lands on both legs carries none. */
export const LEG_LETTER: Readonly<{
    both: " ";
    left: "L";
    right: "R";
}>;
export function holdInPlot(v: any, lo: any, hi: any): any;
/** The setting that chooses a look, schema/modgui-looks.json: its name, values, default, environment variable and flag. */
export const LOOK_SETTING: any;
/** The looks the MOD GUI wears, and the one it wears when none is named. */
export const LOOKS: readonly string[];
export const DEFAULT_LOOK: any;
/** The setting that chooses the tier the MOD GUI is generated for (MOD has no live switch): `modgui-tier`, easy or advanced, default advanced. */
export const TIER_SETTING: any;
export const TIERS: any;
export const DEFAULT_TIER: any;
/** An unknown tier: refused by its name. */
export class UnknownTier extends Error {
    code: string;
}
/** The tokens every look sets, the one schema of the looks. */
export const LOOK_KEYS: readonly string[];
/** An unknown look: refused by its name. */
export class UnknownLook extends Error {
    code: string;
}
export function wornDepth(look: any, stem?: string): {
    [k: string]: string;
};
export function lookTokens(): {};
export function meterCaption(m: any): string;
export function meterLamp(frameW: any, border?: number): {
    x: number;
    y: number;
    size: any;
};
import { LOOK_JSON } from './look.mjs';
