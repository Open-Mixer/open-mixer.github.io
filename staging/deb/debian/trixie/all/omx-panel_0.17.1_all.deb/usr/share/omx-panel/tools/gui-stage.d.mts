export { main as guiStage };
declare function main(argv: any): void;
