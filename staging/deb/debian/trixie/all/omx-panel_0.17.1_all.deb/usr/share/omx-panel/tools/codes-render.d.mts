/** Every rendered file of the domains at `dir` (a contract directory holding panel/ and gestures/): `{ <path in the tree>: <text> }`. */
export function renderAll(dir?: string): {
    'schema/codes.json': string;
};
export const CONTRACT_DIR: string;
/** The items the sheet is made of, in the sheet's order, each with the domain that declares it. */
export const SHEET_ITEMS: {
    domain: string;
    item: string;
}[];
