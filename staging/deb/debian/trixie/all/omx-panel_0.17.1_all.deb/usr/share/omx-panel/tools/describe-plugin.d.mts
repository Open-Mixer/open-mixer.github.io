/** `omx-panel <version>`: the made_by of an entry this package derives (package.json beside tools/, or two up in dist). */
export function madeBy(): string;
/** `lv2:<uri>` or `clap:<path>#<id>`, the form `plugin-hostd-probe describe` takes; null for anything else. */
export function parseTarget(target: any): {
    format: string;
    uri: string;
    path?: undefined;
} | {
    format: string;
    path: string | undefined;
    uri: string | undefined;
} | null;
/** The store command, run once; its stdout, or a refusal carrying its own code and text. */
export function storeCommand(args: any, { input, env }?: {}): string;
/**
 * One plugin's entry, derived (docs/descriptions-store.md 3.4): an LV2 plugin's descriptor takes the complement's
 * verdict over its bundle as its controls' groups, then `describeStored`, then the store's codec. The one derivation of
 * every producer: `describe --plugin --store`, the pass and the base builder.
 */
export function deriveEntry({ descriptor, where, bundle, uri, source, rules, madeBy: made }: {
    descriptor: any;
    where: any;
    bundle: any;
    uri: any;
    source: any;
    rules: any;
    madeBy: any;
}): {
    family: string;
    fingerprint: string;
    body: null;
    groups: null;
    refused: string;
    controls: never[];
    edited: number;
    made_by: string;
    rules: number;
    source: string;
    verdict: {
        outcome: any;
        reason: any;
        groups: any;
    } | null;
} | {
    family: any;
    fingerprint: any;
    body: any;
    groups: any;
    refused: null;
    controls: any;
    edited: number;
    made_by: string;
    rules: number;
    source: string;
    verdict: {
        outcome: any;
        reason: any;
        groups: any;
    } | null;
};
/**
 * The call. Returns the `get` answer's text, as the store printed it: the entry any layer held, or the one this call
 * derived and wrote. Throws a PluginRefusal for what the command reports.
 * `bundle` is the installed bundle of an LV2 target when the caller has read it (the complement), else it is found;
 * `derive` false only reads (a PluginRefusal `no-entry` when no layer holds the key): a dry run writes no entry.
 * @param {{ target: string, descriptor?: string, sha256?: string, madeBy?: string, env?: NodeJS.ProcessEnv, bundle?: any }} o
 */
export function describePlugin({ target, descriptor: given, sha256, madeBy: made, env, bundle: read, derive }: {
    target: string;
    descriptor?: string;
    sha256?: string;
    madeBy?: string;
    env?: NodeJS.ProcessEnv;
    bundle?: any;
}): string;
/**
 * The complement's verdicts from the store (docs/descriptions-store.md 6, lane 4): a function of an installed bundle and
 * a plugin's URI giving the verdict the store holds for it (derived and written first when no layer holds it), or null
 * when there is no store: no `omx-panel-store` on PATH, or no base (`panel-store.absent`). A plugin with no descriptor has
 * no entry: `onNoEntry(uri, message)` is told and the rules infer it. Any other refusal of the store is a Refusal
 * `store-refused` for the bundle.
 * `derive` false reads only (a dry run or a check), and a key no layer holds is inferred.
 * @param {{ env?: NodeJS.ProcessEnv, onNoEntry?: (uri: string, message: string) => void, derive?: boolean }} [o]
 */
export function storeVerdicts({ env, onNoEntry, derive }?: {
    env?: NodeJS.ProcessEnv;
    onNoEntry?: (uri: string, message: string) => void;
    derive?: boolean;
}): ((bundle: any, uri: any) => any) | null;
/** The complement's form of a stored verdict: a declared group keeps the plugin's own node, the pg:group its ports state. */
export function verdictOfEntry(answer: any, bundle: any, uri: any): {
    outcome: any;
    groups: any;
    reason?: undefined;
} | {
    outcome: any;
    reason: any;
    groups?: undefined;
};
/** plugin-hostd's LV2 search list, the one omx-modgui-sync and plugin-qualify read when LV2_PATH is unset. */
export const LV2_DEFAULT_PATH: "/usr/lib64/lv2:/usr/lib/lv2:/usr/local/lib/lv2";
/** A failure the command reports and exits 1 on; `reason` is `no-descriptor` when nothing could be derived from. */
export class PluginRefusal extends Error {
    constructor(message: any, reason?: string);
    reason: string;
}
