/** WCAG relative luminance of `#rrggbb`. */
export function luminance(h: any): number;
/** WCAG contrast ratio of two `#rrggbb` colours. */
export function contrast(a: any, b: any): number;
/**
 * Every rule of the role file `doc` broken, as sentences, or none. The floors are measured on `values` (name ->
 * #rrggbb) when given, else on the defaults: a host's table is held to the same floors by the same function. A floor
 * on a key a finish sets (`--knob-face`) is measured on that key in every finish of the console's pin: a role drawn
 * on the hardware is read there, never on the page around it (docs/modgui.md "The look").
 */
export function checkRoles(doc: any, values: any): string[];
/** Every rule of the drawings `drawings` (the scenes of the looks file) broken, as sentences, or none. */
export function checkDrawings(drawings: any, roles?: any): string[];
/** Every rule of the looks file `looks` broken, as sentences, or none. */
export function checkLooks(looks: any, roles?: any): string[];
/** tools/look.json's text: the look the defaults are, every role at its default, and the font. */
export function emitLook(doc?: any, looks?: any): string;
/** renderer/src/look_roles.h's text: the role names read_look requires of every look. */
export function emitRoleHeader(doc?: any): string;
export const ROLES_JSON: string;
export const LOOK_JSON: string;
export const LOOKS_JSON: string;
export const ROLE_HEADER: string;
/** The families a role belongs to (omx look §2(i)); finish is a host's chrome, never a role's. */
export const FAMILIES: readonly string[];
/** The tokens that are not colours: the CSS font stack, and the font file (relative to tools/) the raster reads. */
export const NOT_COLOURS: readonly string[];
export function loadRoles(file?: string): any;
export function finishOf(look: any, pin?: any): string;
export function loadLooks(file?: string): any;
export function lookKeys(looks?: any): string[];
/** The tokens whose backgrounds carry text: they may name colour roles, never the plugin's enclosure. */
export const TEXT_PLATES: readonly string[];
/** The shapes of the scene subset the film painter and the renderer's backends draw. */
export const SCENE_SHAPES: readonly string[];
/** A drawing's gradient takes two stops at most: NanoVG's gradients do, and the CPU raster is held to the same pictures. */
export const SCENE_MAX_STOPS: 2;
export function roleNames(doc?: any): any;
/** The tokens tools/look.json lists: every role, then the font. */
export const LOOK_TOKENS: readonly any[];
