/**
 * The kind of a control from what the plugin states (the rule above).
 * @param {StatedControl} c
 * @returns {ControlKind}
 */
export function controlKind(c: StatedControl): ControlKind;
/**
 * What the plugin states for one control, in the contract's words whatever its format.
 */
export type StatedControl = {
    /**
     * CLAP_PARAM_IS_ENUM; LV2 lv2:enumeration.
     */
    enumeration?: boolean | undefined;
    /**
     * LV2 lv2:toggled; CLAP has no such flag.
     */
    toggled?: boolean | undefined;
    /**
     * CLAP_PARAM_IS_STEPPED; LV2 lv2:integer.
     */
    stepped?: boolean | undefined;
    /**
     * the parameter-contract entry's scale word, else the
     * format's own (LV2 pprops:logarithmic is `log`); none when the plugin states none.
     */
    scale?: "linear" | "log" | "stepped" | "unknown" | undefined;
    min: number;
    max: number;
    /**
     * the contract entry's step; none, or 0, is one step per unit (CLAP's integer step).
     */
    step?: number | undefined;
    default?: number | undefined;
};
/**
 * The kind the rule gives, with what it fixes: a toggle's come-up state when a default is stated, a travel's scale.
 */
export type ControlKind = {
    kind: "choice";
} | {
    kind: "toggle";
    default?: boolean;
} | {
    kind: "travel";
    scale: "linear" | "log" | "stepped" | "unknown";
};
