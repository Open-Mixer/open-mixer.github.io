/** The text of tools/group-words.mjs for the domains found first in `extra` (directories), then in their homes. */
export function groupWordsText(extra?: any[]): string;
export const OUT_FILE: string;
