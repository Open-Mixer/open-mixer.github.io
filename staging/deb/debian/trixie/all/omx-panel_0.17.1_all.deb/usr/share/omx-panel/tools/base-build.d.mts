/** The commit the inputs were built from: BUILT_FROM.txt (substituted by git archive), else git's HEAD, else a refusal. */
export function builtFrom(inDir: any, env?: NodeJS.ProcessEnv): string;
/** The base from `inDir` into `out`. Throws a PluginRefusal for what the command reports. */
export function buildBase({ inDir, out, env }: {
    inDir: any;
    out: any;
    env?: NodeJS.ProcessEnv | undefined;
}): {
    entries: number;
    builtFrom: string;
};
