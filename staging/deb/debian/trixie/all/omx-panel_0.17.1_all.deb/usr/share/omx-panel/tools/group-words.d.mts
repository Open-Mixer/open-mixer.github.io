/** The verdict's outcomes: PANEL_GROUP_OUTCOMES. */
export const GROUP_OUTCOMES: Readonly<{
    nothingToDo: "nothing-to-do";
    grouped: "grouped";
    noConfidentGrouping: "no-confident-grouping";
}>;
/** The verdict's reasons: PANEL_GROUP_REASONS. */
export const GROUP_REASONS: Readonly<{
    noControls: "no-controls";
    ownGroupsComplete: "own-groups-complete";
    fitsOneScreen: "fits-one-screen";
    unplacedControls: "unplaced-controls";
    tooFewGroups: "too-few-groups";
    tooManyGroups: "too-many-groups";
    mostlyByIndex: "mostly-by-index";
}>;
/** The standard meaning of each LV2 designation term plugin-db's F1 maps: LV2_DESIGNATION_MEANINGS. */
export const DESIGNATION_MEANINGS: Readonly<{
    attack: "attack";
    bypass: "bypass";
    cutoffFrequency: "cutoffFrequency";
    decay: "decay";
    delay: "delay";
    frequency: "frequency";
    gain: "gain";
    hold: "hold";
    ratio: "ratio";
    release: "release";
    resonance: "resonance";
    threshold: "threshold";
    wetDryRatio: "wetDryRatio";
    enabled: "enabled";
}>;
