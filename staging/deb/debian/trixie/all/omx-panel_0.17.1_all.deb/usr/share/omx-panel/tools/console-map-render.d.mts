/** The table's lines for the map's rows: one row per map row, in the map's order. */
export function mapTable(rows: any): string;
/** `doc` with the text between the markers replaced by the table of `rows`; throws when the markers are not there once each, in order. */
export function withTable(doc: any, rows: any): string;
export const MAP_FILE: string;
export const DOC_FILE: string;
export const BEGIN: "<!-- the map table: printed from tools/look/console-map.json by tools/console-map-render.mjs, do not edit by hand -->";
export const END: "<!-- end of the map table -->";
