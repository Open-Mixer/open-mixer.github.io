/**
 * The timings a surface runs with: the declared defaults, with the surface's own settings over them. The safety hold
 * may be lengthened and is refused below the declared floor; an unknown name or a non-positive time is refused.
 */
export function timingsOf(settings?: {}): Readonly<{}>;
/** The word a widget's input is, or undefined: the table, then a section exception layered on it. */
export function wordOf(control: any, input: any): any;
/** A value's place on its travel, 0..1 (a log travel is linear in its logarithm). */
export function normOf(m: any, v: any): number;
/** The value at a place on the travel, in the control's unit; an integer travel lands on an integer. */
export function valueOfNorm(m: any, n: any): any;
/** One step on the 0..1 travel: the declared step (linear travels), an integer travel's one, else 1% of the travel. */
export function stepNormOf(m: any): any;
/** One declared step in the control's own unit at `v`: the parity tolerance of a drag against the reference. */
export function stepOf(m: any, v?: any): number;
/** Whether two values are within one declared step of each other. */
export function withinStep(m: any, a: any, b: any): boolean;
/**
 * A control's member for the reference from a descriptor control's `travel` (the layout's own words): its ends, default,
 * log or linear scale, declared step; a stepped travel is an integer one. `extra` adds the surface's geometry and value.
 */
export function memberOf(control: any, extra?: {}): {
    integer: boolean;
    step?: any;
    min: any;
    max: any;
    def: any;
    scale: string;
};
/**
 * Run a script of events against one control. Scripts are in time order (a stable sort by `t` is applied). Returns the
 * value in the control's own unit (a number; `{ freq, gain, q }` for a handle; `{ [symbol]: value }` for a bar group),
 * every gesture with its id, word, begin, end and changes, the ids of the undo entries, and what was refused.
 */
export function runGesture(control: any, events: any, settings?: {}): {
    gestures: never[];
    refused: never[];
    cancelled: never[];
    selected: any;
};
/** The declaration, schema/gestures.json, read once. */
export const GESTURES: any;
export namespace GESTURE_CODES {
    let readOnly: string;
    let owned: string;
    let noDefault: string;
    let notInTable: string;
    let holdShort: string;
    let holdBelowFloor: string;
    let noTarget: string;
    let paintRequired: string;
    let badSetting: string;
    let badInput: string;
}
/**
 * Each refusal code's code word in the one codes sheet, schema/codes.json (docs/panel-gestures.md, ruled omx-panel#106):
 * `panel.gesture.<kebab>` of its name, as the gestures domain declares it (`const` the word, `x-name` the name). A surface shows a
 * refusal's text by this word; the name is what the reference and the C unit answer.
 */
export const GESTURE_CODE_WORDS: Readonly<{
    [k: string]: string;
}>;
export class GestureError extends Error {
    constructor(code: any, why: any);
    code: any;
    /** the code word of schema/codes.json, its sentence in every catalog */
    word: string | undefined;
}
