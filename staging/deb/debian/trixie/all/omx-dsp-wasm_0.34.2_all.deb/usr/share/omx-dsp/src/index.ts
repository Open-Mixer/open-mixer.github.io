// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
/**
 * @openmixer/omx-dsp: the TypeScript twins of omx-dsp kernels, the ones that stay in TypeScript because doing
 * the work in C would be silly (a display, a unit conversion a browser runs). Each is pinned to its kernel by an
 * agreement test in test/ that feeds both the same grid.
 */
export { ANALYSIS_FLOOR_DB, dbToLinearGain, linearGainToDb, linearToDbFloored } from './units.js';
export {
  biquadMagnitudeDb,
  clampEqQFor,
  lowpassHandover,
  butterworthQs,
  magnitudeSumDb,
  rbjSection,
  type BiquadBand,
  type BiquadKind,
  type BiquadSection,
  type BiquadType,
} from './eq.js';
export {
  COMP_KNEE_DB_RANGE,
  COMP_RATIO_RANGE,
  CURVE_CODES,
  CURVE_DISPLAYS,
  CURVE_EXTENTS,
  CURVE_FAMILIES,
  CURVE_POINTS_MAX,
  CURVE_ORIGINS,
  CURVE_ROLE_PREFIXES,
  CURVE_ROLES,
  CURVE_SHAPES,
  CURVE_UNITS,
  EQ_NOTCH_Q_RANGE,
  EQ_Q_RANGE,
  GATE_RANGE_DB_RANGE,
  GATE_RATIO_RANGE,
  LIN_TO_DB_FLOOR,
  LOWPASS_HANDOVER,
  METER_DECIMATION,
  METER_KINDS,
  METER_MEASUREMENTS,
  METER_UNITS,
  METER_VIEW,
  RTA_BAND_F_MAX_CAP,
  RTA_BAND_F_MIN,
  RTA_BAND_GATE_DB,
  RTA_DELTA_DEADBAND_DB,
  RTA_FFT_SIZE_MAX,
  RTA_GRID_FREQS,
  RTA_HZ,
  RTA_LEVEL_DB_MAX,
  RTA_LEVEL_DB_MIN,
  RTA_LEVEL_GRID_DB,
  RTA_LOW_ADVANCE,
  RTA_TAP_GATE_DB,
  RTA_TARGET_BIN_HZ,
  RTA_TIER_CROSSOVER_HZ,
} from './definitions.js';
export {
  aggregateSpectrumBands,
  bandDelta,
  bandFMax,
  fftSizeForRate,
  hzToBin,
  lowTierGainDb,
  spectrumBandCentres,
  type BandDelta,
  type BandWedge,
  type MagnitudeSeries,
  type SpectrumBand,
  type SpectrumBandOptions,
  type SpectrumTierInput,
} from './rta.js';
export { gaincompDb, type GaincompMode, type GaincompParams } from './gaincomp.js';
export { CURVE_WORDS, WASI_IMPORTS, curveRoleIsBand, loadCurve, wasiStandIns, type CurveAnswer, type CurveCode, type CurveMark, type CurveModule, type CurvePoint, type CurveRequest, type CurveStem, type CurveTerm } from './wasm.js';
export { EQ_FREQ_RANGE, HRP_GAIN_STEP_DB } from './definitions.js';
export { EQ_GAIN_RANGE, FBS_MAX_CUT_DB } from './definitions.js';
export { METER_MARKER_EMPTY, meterBarStep, meterFill, meterFillDb, meterMarker, meterStep, type MeterMarker } from './meter.js';
