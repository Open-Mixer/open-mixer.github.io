/**
 * What `omx-contract translate` makes, and what it refuses (omx-contract#21, docs/data-layout.md "Language packs").
 * The model call itself is the CLI's; everything it decides is here, with no network:
 *
 * - {@link toMake}: the keys of a language to make: every key with a source sentence that the catalog lacks, and
 *   every model's entry made from another source sentence (stale). A person's entry is never made again.
 * - {@link admit}: a model's answer for one key, behind the placeholder gate: its `{name}` placeholders are exactly
 *   the source sentence's, each one of the key's `args`, or it is refused and the run is red.
 * - {@link releaseProblems}: the release gate, with no model: a listed language with no catalog, a key it lacks, a
 *   stale entry.
 * - {@link catalogText}: the catalog as written, one message a line, the existing order kept and new keys after it.
 */
import type { Catalog, CatalogEntry, CatalogKey, CatalogRecord } from './catalog.mjs';
import { entryText } from './catalog.mjs';
/** One key to make: its source sentence and its args. */
export interface ToMake {
    readonly text: string;
    readonly args: readonly string[];
}
/** One release problem: the file, the key (or `-`), and what is wrong. */
export interface ReleaseProblem {
    readonly file: string;
    readonly key: string;
    readonly message: string;
}
/** Whether `entry` is kept, not generated: `by: human`, or `by: same`. */
export declare const isHuman: (entry: CatalogEntry) => boolean;
/** The keys of `catalog` (none when there is none yet) to make from their source sentences. */
export declare function toMake(keys: ReadonlyMap<string, CatalogKey>, catalog: Catalog | undefined): Map<string, ToMake>;
/**
 * A model's answer `answer` for `want` as an entry, or the reason it is refused: no text, or placeholders that are not
 * exactly the source sentence's (each of which is one of the key's args).
 */
export declare function admit(want: ToMake, answer: unknown, model: string): {
    entry: CatalogRecord;
} | {
    refused: string;
};
/** The release problems of the catalogs `catalogs` (by language, undefined when absent) against `keys`. */
export declare function releaseProblems(keys: ReadonlyMap<string, CatalogKey>, langs: readonly string[], catalogs: ReadonlyMap<string, Catalog | undefined>, fileOf: (lang: string) => string): ReleaseProblem[];
/** The catalog's text: its head, then one message a line, in `order` (existing keys first, new ones sorted after). */
export declare function catalogText(catalog: Catalog & {
    readonly $schema?: string;
}, before?: readonly string[]): string;
/** The text of one entry, for a caller that holds a catalog's raw messages. */
export { entryText };
