/**
 * What each PARAM_SCALES word means as a position, beside the word (docs/scale-position.md). A position `p` runs
 * from 0 at the travel's `min` to 1 at its `max`.
 *
 * - `linear`: p = (v - min) / (max - min).
 * - `log`: p = ln(v / min) / ln(max / min), over a positive floor `min`. A log travel whose floor is not positive
 *   has no logarithm: it is served linear (the validator drops an override entry that asks for one, and
 *   `contract.override.scale-floor` is its code).
 * - `stepped`: p = k / (n - 1), k the step's index and n the number of steps, n = (max - min) / step + 1.
 * - `map`, the override module's table: linear between its `points`, a list of [plain value, quantity]. The
 *   position is the plain value's, linear over the first and last point; the value is the quantity.
 *
 * A word's law is not overridable per control. Nothing is clamped: a value outside the travel has a position
 * outside 0..1, and the ends are exact.
 */
/** A word of PARAM_SCALES this library gives a law to, or the override `map`. */
export type PositionLaw = 'linear' | 'log' | 'stepped' | 'map';
/** The words this library gives a law to: PARAM_SCALES' ids and the override `map`. `unknown` is served linear. */
export declare const POSITION_LAWS: readonly PositionLaw[];
/**
 * One named member per word of POSITION_LAWS, made from it and never listed beside it (omx-contract#46): a surface
 * that branches on one law writes `Law.LOG`, not `'log'`. A member is the word itself.
 */
export declare const Law: {
    readonly [W in PositionLaw as Uppercase<W>]: W;
};
/** A travel as a descriptor states it: `step` for a stepped one, `unknown` is served linear. */
export interface ScaleTravel {
    readonly scale?: PositionLaw | 'unknown';
    readonly min?: number;
    readonly max?: number;
    readonly step?: number;
}
/** The override module's map: [plain value, quantity] points, linear between them. */
export interface ScaleMap {
    readonly scale: 'map';
    readonly points: readonly (readonly [number, number])[];
}
type Travel = ScaleTravel | ScaleMap;
/** The position of `value` on `travel` ({ scale, min, max, step? } or { scale: 'map', points }). */
export declare function scalePosition(travel: Travel, value: number): number;
/** The value at position `p` on `travel`: the inverse of scalePosition (a stepped one lands on the nearest step). */
export declare function scaleValue(travel: Travel, p: number): number;
export {};
