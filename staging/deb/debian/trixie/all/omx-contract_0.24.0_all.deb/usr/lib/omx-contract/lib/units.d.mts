import type { Json } from './json.mjs';
/** The descriptor format's "states no unit": a descriptor's travel.unit may say it, a lookup never. */
export declare const UNKNOWN = "unknown";
export interface UnitGate {
    /** PARAM_UNITS's standard ids. */
    ids: Set<string>;
    /** The keys whose string value is a unit (`unit`, and its domain spelling `x-unit`). */
    unitKeys: Set<string>;
    /** The keys whose value is an object of units (`choiceUnits`). */
    unitMapKeys: Set<string>;
    /** Whether a descriptor word (a map row's word.word) names a unit. */
    isUnitWord(path: string): boolean;
}
export interface UnitProblem {
    /** The JSON pointer of the value. */
    pointer: string;
    /** The key the value sits under (a unit key, or a lookup's source key). */
    key: string;
    value: string;
    message: string;
}
/** The gate as `schema` (omx-contract's own by default) defines it. */
export declare function unitGate(schema?: Json): UnitGate;
/**
 * Every unit `doc` states that is no standard id: a unit key's string (or `unknown`), each value of a map of
 * units, and each lookup value of a map row whose word (`word`, or a domain's `x-word`) is a unit word.
 */
export declare function unitProblems(doc: Json, gate?: UnitGate): UnitProblem[] & {
    checked: number;
};
/**
 * A line finder over `text`: `find(key, value)` is the 1-based line of the next line stating `"key": "value"` (each
 * pair resumes after its last answer, so the problems of one file, in document order, get their lines in one pass
 * per pair); 0 when none does.
 */
export declare function lineFinder(text: string): (key: string, value: string) => number;
/** A format map's rows (the data form's formatMap value): each unit lookup value that is no id (rule map-unit). */
export declare function mapUnitProblems(rows: Record<string, Json>, gate?: UnitGate): string[];
