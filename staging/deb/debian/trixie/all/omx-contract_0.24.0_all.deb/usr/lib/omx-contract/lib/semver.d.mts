/**
 * `omx-contract semver`: classify every change between two resolved declarations and
 * refuse a version whose bump is shorter than the largest class found.
 *
 *   major  a field removed; an item or a code removed (MINOR in the development phase, below); a
 *          unit or kind changed; a travel narrowed; a constant a kernel computes with changed (a
 *          scalar, sheet leaf or derived value that is not a travel bound or default; a list member
 *          or set id changed or removed; a set's default added, removed; a value an id carries changed
 *          or removed)
 *   minor  an item, field, sheet leaf, list member or set id added (appended); a travel widened;
 *          a default moved inside its travel; a step changed; a set's values added
 *   patch  doc and why text
 *
 * A verbs item (verbChanges): a verb added, a refusal added or a host given an optional verb is minor; a verb removed or
 * changed, a refusal removed or any other move of what a host owes is major.
 *
 * A kernel's readouts (docs/readouts.md): one removed, renamed or moved, or its unit changed, is major (a removal is
 * minor in the development phase, as an item's is); one appended, or its range, scale or rate changed, is minor; its
 * doc is patch.
 */
import type { Json } from './json.mjs';
/**
 * The development-phase rule: while every consumer of
 * omx-contract is an OpenMixer repository named here, removing an item is MINOR. The rule ends, and
 * this becomes null so a removal is MAJOR again, in the release that names the first consumer
 * outside the list. Until then a MAJOR class is released as a minor bump (see refusal).
 */
export declare const DEVELOPMENT_PHASE: Readonly<{
    consumers: readonly string[];
}>;
/** `{ level, changes: [{ level, item, what }] }` from `prev` to `next` (Maps name -> resolved item). */
export declare function classify(prev: any, next: any, { developmentPhase }?: {
    developmentPhase?: Readonly<{
        consumers: readonly string[];
    }> | undefined;
}): {
    level: any;
    changes: any[];
};
/**
 * The changes between two schema documents (parsed JSON), `{ level, changes }` with changes `{ level, item: 'schema', what }`.
 * A file that was valid must stay valid under the same major: a property, definition or enum member removed, a
 * required member added, a constraint added or changed (pattern, const, type, bounds, additionalProperties) is
 * major (MINOR in the development phase, as an item's removal is, see refusal); a property, definition or enum
 * member added, or a required member dropped, is minor; a description is patch. `x-omx-schema-version` is the
 * version, not a change.
 */
export declare function classifySchema(prev: any, next: any): {
    level: any;
    changes: any[];
};
/** The class of the bump from version `from` to `to`: 'major' | 'minor' | 'patch' | 'none'; throws if `to` is lower. */
export declare function bumpOf(from: any, to: any): string;
/**
 * null when bumping `from` -> `to` covers `level`, else the refusal. In the development phase no
 * release takes a major bump (decided 2026-10-13: majors wait for the first public
 * release), so a MAJOR class is covered by a minor bump; the classes are still reported as found.
 */
export declare function refusal(level: any, from: any, to: any, { developmentPhase }?: {
    developmentPhase?: Readonly<{
        consumers: readonly string[];
    }> | undefined;
}): string | null;
/**
 * What is wrong with the version a schema states, against the schema at the last tag: `x-omx-schema-version` is the
 * omx-contract release that last changed the vocabulary (docs/contract-dir.md), so a changed schema states a newer one, by
 * what its changes need, in the commit that changes it. null when it is right.
 */
export declare function schemaVersionProblem(prev: any, next: any): string | null;
/**
 * The items new since the previous release whose `x-since` is not the release that ships them (omx-contract#246). An
 * item's `x-since` is the `info.version` of its domain that first carries it (docs/contract-dir.md), so an item absent
 * from the domain at the previous tag says the domain's `info.version` in this tree, and that version is above the
 * domain's at the tag. `prev` and `next` map a domain's name to its document (`prev` without the domains the tag did not
 * have). One line per problem, naming the domain, the item, its x-since and the version that ships it; [] when none.
 */
export declare function sinceProblems(prev: Record<string, Json>, next: Record<string, Json>, from: string): string[];
