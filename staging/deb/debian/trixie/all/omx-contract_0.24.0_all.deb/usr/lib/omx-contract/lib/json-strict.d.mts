/**
 * JSON that refuses a key written twice in one object (the C loader reads with JSON_REJECT_DUPLICATES; JSON.parse keeps
 * the last one silently, so a document the two readers read would differ). `parseStrict` is JSON.parse plus that one rule.
 */
/** The first key written twice in one object of the JSON text `text`, with its line, or undefined. `text` must be valid JSON. */
export declare function duplicateKey(text: string): {
    key: string;
    line: number;
} | undefined;
/**
 * JSON.parse of `text`, refusing a duplicate key.
 * @throws Error naming the syntax error, or the duplicate key and its line.
 */
export declare function parseStrict(text: string): unknown;
