import type { Json, JsonObject } from './json.mjs';
/**
 * omx-contract's own domains whose items join the read of a data directory: `<dir>/../contract.d/<name>/<name>.json`,
 * read as the classic file of its items at `<name>/<name>.json`, the place a read of the installed contract directory
 * gives it, so the renders of data/ and of the installed tree agree. `param` holds the standard parameter words
 * (PARAM_SCALES, PARAM_UNITS, PARAM_UNIT_DIMENSIONS; sorting pass V21, V23a+b). A data directory with no such domain
 * beside it reads as before.
 */
export declare const TREE_DOMAINS: string[];
/** The files of the TREE_DOMAINS beside `dir`, `{ rel, text, doc, domain: true }`, each `doc` the classic file of its items. */
export declare function treeDomainFiles(dir: string | null): Json[];
/**
 * The files at the top of a data directory that are neither declarations nor items: `scale-vectors.json` holds the
 * golden vectors of the position law of each scale word (lib/scale.mjs). They are not loaded, not rendered and not
 * installed in a contract directory; the packages install the file beside omx-contract.json.
 */
export declare const SIDE_FILES: string[];
/** Every `.json` file under `dir`, sorted by its path relative to `dir`, the side files at its top left out. */
export declare function dataFiles(dir: any): any[];
/**
 * The raw data: `{ files: [{ path, rel, doc }], items: Map<name, { name, rel, item }> }`, items in
 * file order then key order. `files` may be handed in as `{ rel: text }` (a tag's data, a test). `sources` names, by
 * rel, the document a handed-in file was rebuilt from (`render --data --with-domain`: the domain's
 * `contract.d/<domain>/<leaf>.json`); the file and its items carry it as `source`, the provenance sourceOf reads.
 * @throws naming the file when one is not JSON, and an item declared by two files.
 */
export declare function loadData(dir: string, texts?: Readonly<Record<string, string>>, sources?: Readonly<Record<string, string>>): Json;
/** The four sections of a kernel file that declare items, in their order. */
export declare const KERNEL_SECTIONS: string[];
/** Every top-level key a kernel file may hold, in their order: the four sections and `readouts`, which declares no item. */
export declare const KERNEL_KEYS: string[];
/**
 * The keys a data file of any shape may carry beside its items (docs/contract-dir.md): `$schema`, `requires` (the
 * names of the packages and domains it refers to, no version: the devel wave 2026-11-24), `source` (the file's provenance and connector), `render` (how the
 * owner's own header spells the file's items, docs/render.md) and `checks` (sums held under a bound). They declare no
 * item.
 */
export declare const FILE_KEYS: string[];
/** Whether a data file is a kernel file (`kernels/<kernel>.json`), which holds the four sections, never an item map. */
export declare const isKernelFile: (rel: any) => boolean;
/**
 * Whether a parsed file is a plugin descriptor (docs/descriptors.md): it carries `origin`, which no item map or kernel
 * file may. A descriptor declares no item.
 */
export declare const isDescriptor: (doc: any) => boolean;
/** The kernel's upper-case prefix, read off its file name: `kernels/band_dyn.json` is BAND_DYN. */
export declare const kernelPrefix: (rel: any) => any;
/**
 * Whether a control is a USE: it declares no travel and no ids of its own and takes its values from the item its
 * `global` names, which another control of the same kernel declares (an EQ's low-pass slope takes the slope set its
 * high-pass slope declares). A use adds no item; it is a control of the kernel all the same.
 */
export declare const isUse: (c: any) => any;
/** A control's item name: its `global`, else <KERNEL>_<NAME>_RANGE for a travel and <KERNEL>_<NAME>S for a choice. */
export declare const controlGlobal: (rel: any, c: any) => any;
/**
 * A data file's items as [name, item] pairs. A kernel file's four sections are expanded into the items the renders
 * read: a travel control is a `travels` item named by controlGlobal, a choice a `set`; the controls of one `table`
 * regroup into that table's `travels` item with `fields`; an aggregate is regenerated as fields that reference its
 * controls; constants pass through. Any other top-level key of a kernel file is not read (validation names it).
 * rates.json and primitives.json are item maps, read as they are.
 */
export declare function entriesOf(rel: string, doc: Json): [string, Json][];
/** A kernel's name, read off its file name: `kernels/band_dyn.json` is band_dyn. */
export declare const kernelName: (rel: any) => any;
/**
 * Every kernel's controls, in its file's order: `{ <kernel>: { controls: [{ name, kind, global, table?, rearms?, count?, when? }] } }`,
 * kernels in file order. `global` is the item the control's value lives in: its own travel or set, or, for a field of
 * a table, the table (`table` names it too, and the field is the control's name). `rearms` is carried only when true:
 * changing the control re-arms the kernel's state, it is not a smooth parameter. `count` names the item that counts a
 * control the kernel takes once per band (a scalar, or a sheet whose every variant gives its count as `max`). A
 * control that declares `of` is no control of its own but the travel the control it names reaches while the choice
 * `when` names holds the id it names: it is listed under that control's `when` as `{ control, is, global }`.
 */
export declare function kernelControls(data: any): {};
/**
 * The kernel file that declares `entries` ([name, item] pairs, the items entriesOf gives back), the inverse of
 * entriesOf: a single travel is a travel control and a set a choice; a fields table whose every field IS a single
 * travel of the kernel (`{ ref }`) is an aggregate, and its field names name those controls; any other fields table
 * is a table whose fields are its controls; every other item is a constant. A control's `global` is written only
 * when its name does not derive it. `kept`, a kernel file already written, is extended: its declarations stay as
 * they are and the entries it lacks are added. Empty sections are left out.
 * @throws naming the item: a fields table that mixes references and travels, an aggregate field whose name is not
 * its control's.
 */
export declare function kernelDocOf(rel: string, entries: [string, Json][], kept?: Json): JsonObject;
/** An item's own value before resolution, by kind. */
export declare function rawValue(item: any): any;
/** The closed list of derivations. A new one is a change here with its own test. */
export declare const DERIVATIONS: {
    count: (d: any, val: any) => number;
    sqrt: (d: any, val: any) => number;
    ceilSum: (d: any, val: any) => number;
    lagrangeReadL1: (d: any, val: any) => number;
};
/** The taps of the order-`order` Lagrange fractional read at fraction `f` (the fdelay kernel's read). */
export declare function lagrangeReadTaps(order: any, f: any): any[];
/** The worst L1 norm of the read over 1024 fractions, rounded to 1e-9 (core's readKernelL1Norm). */
export declare function lagrangeReadL1(order: any): number;
/**
 * Resolve every item: `{ name, rel, kind, doc, why?, since?, unit?, c?, shape?, default?, labels?, values?, standard?, groups?, axes?, format?, spec?, version?, value }`
 * (default, labels, values and standard: a set's; groups and axes: a words item's; format, spec and version: a terms item's), where `value` has
 * every `{ref}` and `{derive}` evaluated. The returned map also carries `kernels`, every kernel's ordered controls
 * (kernelControls) and, for a kernel that declares them, its ordered `readouts` `{ name, doc, unit, min, max, scale,
 * rateHz }` with every reference resolved, which the json render publishes beside the items; `packageOf`, each item's
 * package (undefined for a data directory), and `kernelPackageOf`, each kernel's; `checks`, every file's checks with its `rel`; and `renders`, every file that carries a `render` word,
 * `{ rel, pkg, render, items, kernel }` with its items' names in file order and, for a kernel file, its kernel.
 * @throws naming the item: a reference that does not resolve, a cycle, an unknown derivation.
 */
/** The resolved items by name, with what a read carries beside them (see resolveData). */
export type Resolved = Map<string, JsonObject> & {
    kernels: JsonObject;
    packageOf: Map<string, string | undefined>;
    ownerOf?: Map<string, string>;
    kernelPackageOf: Map<string, string | undefined>;
    renders: JsonObject[];
    checks?: JsonObject[];
};
export declare function resolveData(data: Json): Resolved;
/** Where a render's banner says a resolved item comes from: its domain's document for a domain item, else its data file. */
export declare const sourceOf: (r: JsonObject) => string;
/**
 * The resolved items of one package of a contract directory, in their order, with its kernels, packageOf and renders
 * cut to it: what an owner renders of its own (`render --package`). Every reference stays resolved over the whole
 * read. A data directory (no package on any file) is the package named, whole.
 */
export declare function packageItems(resolved: Resolved, pkg: string | undefined): Resolved;
/**
 * A set's default, resolved: an id as written, or `{ ref }` to the scalar that states it. A boolean scalar names the
 * second id of a two-id switch when true and the first when false (a delay's ping-pong switch takes its default from
 * the boolean come-up scalar, so the come-up value keeps one home).
 * @throws naming the set: a boolean default of a set that is not two ids.
 */
export declare function setDefault(item: any, val: any, name: any): any;
/** The package version (package.json), which names the tag, the release and the npm version. */
export declare function packageVersion(root: any): any;
