import type { JsonObject } from './json.mjs';
/** What `domain check` finds: the problems (exit 1) and the accepted code shifts it names (omx-contract#167). */
export interface DomainCheckReport {
    problems: string[];
    shifts: string[];
}
/**
 * The problems of `next` against `committed`, one line each, naming the domain, the item and the word; empty is clean.
 * A version going down is refused as well: a domain's version only rises.
 */
export declare function domainCheck(next: JsonObject, committed: JsonObject): string[];
/** domainCheck's problems, and one line for each word whose code shifted in an item without `x-c-codes`, accepted. */
export declare function domainCheckReport(next: JsonObject, committed: JsonObject): DomainCheckReport;
