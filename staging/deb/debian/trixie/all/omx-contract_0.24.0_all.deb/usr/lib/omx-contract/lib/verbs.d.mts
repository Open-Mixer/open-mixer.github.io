/**
 * The item that lists the hosts a verb's implementedBy may name: omx-clap's hosting words
 * (data/hosting/verb-hosts.json, installed as `<major>/omx-clap/hosting/verb-hosts.json`). omx-contract ships none.
 */
export declare const HOSTS_ITEM = "HOSTING_VERB_HOSTS";
/** Why a read with verbs and no host list is refused: the hosts are read from the read only. */
export declare const NO_HOSTS: string;
/** The host words of the read's HOSTS_ITEM, in their order; undefined when the read holds no such words item. */
export declare function hostWords(items: any): any[] | undefined;
/** Every verb of the read, in item order: `[{ item, key, verb, rel, pkg }]`. */
export declare function verbsOf(items: any): any[];
/**
 * The problems of every verb of `items` (a read's items, `Map<name, { name, rel, item, pkg }>`):
 * `[{ name, rel, item, message }]`, `name` the CONTRACT_CODES name: verbDuplicate (one word declared twice),
 * verbFormat (a format whose first word is not the verb), verbHostUnknown (an implementedBy key that is no host word,
 * or verbs in a read with no HOSTS_ITEM),
 * verbCodeUnknown (a code whose item is no codes item, or carries no such name). A code whose item no file declares is
 * the reference machinery's (contract.ref.unresolved), and is left to it.
 */
export declare function verbProblems(items: any): any[];
