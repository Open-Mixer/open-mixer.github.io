/// <reference types="node" resolution-mode="require"/>
/** The `contract` domain of this tool: the one place its codes are written. */
export declare const CODES_FILE: import("url").URL;
/** `{ <lowerCamel name>: <code> }`, in the domain's word order: a word's `x-name` is its name, its `const` the code. */
export declare const CONTRACT_CODES: Readonly<Record<string, string>>;
/** A refusal: `code` is a CONTRACT_CODES code, `file` what it was found in, the message what was found. */
export declare class ContractRefusal extends Error {
    /** The CONTRACT_CODES code. */
    readonly code: string;
    /** What the refusal was found in. */
    readonly file: string;
    constructor(name: string, file: string, message: string);
    /** The one line a refusal is printed as: its code first. */
    line(): string;
    toJSON(): {
        code: string;
        file: string;
        message: string;
    };
}
/** Raise the refusal named `name`. */
export declare function refuse(name: string, file: string, message: string): never;
