import type { Json } from './json.mjs';
/** The ids of PARAM_SCALES, the scales a travel may name, read from omx-contract's own `param` domain (contract.d/param/param.json): its words in order. */
export declare const PARAM_SCALE_IDS: readonly string[];
/** The value a descriptor writes for a unit, a scale or a meaning the plugin does not state. */
export declare const UNKNOWN: "unknown";
/**
 * The words a plugin's author may reach for that the contract does not take: one word per meaning, no synonyms
 * (FreeMixer/omx-contract#100). Each maps to the meaning that already says it; the validator names it.
 */
export declare const MEANING_SYNONYMS: Readonly<Record<string, string>>;
/**
 * Every problem of descriptor `doc` (file `rel`) beyond the schema: `[{ file, item, rule, code, name, message }]`, `rule`
 * and `code` the CONTRACT_CODES code, `name` its key. `scales` are the ids a travel's scale may name besides unknown.
 */
/** One problem of a descriptor beyond the schema: `rule` and `code` the CONTRACT_CODES code, `name` its key. */
export interface DescriptorProblem {
    file: string;
    item: string;
    rule: string;
    code: string;
    name: string;
    message: string;
}
/** A refused file or a warning of one layer; a dropped entry names its control too. */
export interface OverrideNote {
    layer: number;
    code: string;
    name: string;
    message: string;
}
/** The effective descriptor under the override layers, and what each layer answered, dropped, warned or refused. */
export interface OverrideResult<D> {
    descriptor: D;
    family: string | undefined;
    answered: Record<string, number>;
    dropped: (OverrideNote & {
        control: string;
    })[];
    warnings: OverrideNote[];
    refused: OverrideNote[];
}
export declare function descriptorProblems(rel: string, doc: Json, { scales }?: {
    scales?: readonly string[];
}): DescriptorProblem[];
/** The schema's problems of an override file `doc`: `[{ path, message }]`, none when it is well formed. */
export declare function overrideSchemaProblems(doc: Json): {
    path: string;
    message: string;
}[];
/**
 * The effective descriptor of `descriptor` under the override files `layers`, lowest first (docs/overrides.md). For
 * each control id the highest layer's entry wins whole, and so does `family`; each winning entry is checked against
 * the descriptor, and an entry that fails is dropped with its code while the rest stands. A file that fails the schema
 * (`contract.file.invalid`) or names another plugin (`contract.override.plugin-mismatch`) is refused whole. A file
 * written against another `paramsFingerprint` than `opts.paramsFingerprint` (the scan's) is a warning, never a refusal.
 * An override never changes the scan's fingerprint, and never widens or changes a kind.
 *
 * @returns {{ descriptor: object, family: string|undefined, answered: Record<string, number>,
 *   dropped: {layer: number, control: string, code: string, name: string, message: string}[],
 *   warnings: {layer: number, code: string, name: string, message: string}[],
 *   refused: {layer: number, code: string, name: string, message: string}[] }}
 */
export declare function applyOverride<D extends object>(descriptor: D, layers: readonly unknown[], opts?: {
    paramsFingerprint?: string;
}): OverrideResult<D>;
