/** The schema of a domain document, as a constant a consumer reads with json-schema-to-ts `FromSchema` and validates with Ajv 2020. */
export declare const domainSchema: {
    readonly $schema: "https://json-schema.org/draft/2020-12/schema";
    readonly $id: "https://openmixer.org/schema/omx-contract/v0/domain.schema.json";
    readonly title: "omx-contract domain document";
    readonly description: "A domain document (docs/contract-dir.md, Domains): <contractdir>/<domain>/<last segment>.json, one JSON Schema 2020-12 document of a vocabulary, its words items, range items, sheets, scalars, terms items and map items under components.schemas. GPL-3.0-or-later. What a schema cannot say stays in the reader (src/lib/domain.mts): the prefix rule (an item name starts with the domain's name in upper snake case with its underscore, and never with the prefix of a longer domain of the read); the x-code order (a word's x-code is its place in the oneOf, from 0); a title used twice in one item; x-groups naming a words item of this document and x-group a word of that item; x-dimensions and x-dimension likewise; a set's x-default being one of its words; the $id agreeing with the directory the document is in (the domain's name, a nested domain's document being <domain>/<last segment>.json); a name used by two domains; a word's x-args being exactly the placeholders of its x-text, each once (and present when the x-text has any); a map row's const being its title and the outcome and cover rules a schema states again by name; a map row's term link resolving to a term of a terms item of the map's format, which the read of all the data checks (validate, rule map-term); and x-since and x-why, which the reader does not type.";
    readonly type: "object";
    readonly required: readonly ["$schema", "$id", "x-omx-contract", "info", "components"];
    readonly additionalProperties: false;
    readonly properties: {
        readonly $schema: {
            readonly const: "https://json-schema.org/draft/2020-12/schema";
        };
        readonly $id: {
            readonly description: "The stable id of the domain, the URL every cross-domain reference names.";
            readonly type: "string";
            readonly pattern: "^https://openmixer\\.org/contract/[a-z][a-z0-9-]*(/[a-z][a-z0-9-]*)*$";
        };
        readonly "x-omx-contract": {
            readonly description: "The omx-contract format the document is written in, MAJOR.MINOR of the schema's x-omx-schema-version (docs/contract-dir.md, \"Domains\"), as OpenAPI's openapi field: never the domain's own version, which is info.version. A reader refuses another MAJOR than its own.";
            readonly type: "string";
            readonly pattern: "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)$";
        };
        readonly info: {
            readonly type: "object";
            readonly required: readonly ["title", "version", "x-owner", "x-stability"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly title: {
                    readonly type: "string";
                    readonly minLength: 1;
                };
                readonly version: {
                    readonly description: "The domain's own version.";
                    readonly type: "string";
                    readonly pattern: "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)$";
                };
                readonly "x-owner": {
                    readonly description: "The package that owns the domain today: metadata, never a path.";
                    readonly type: "string";
                    readonly pattern: "^[a-z][a-z0-9-]*$";
                };
                readonly "x-stability": {
                    readonly description: "The domain's stability level: every document carries it, and there is no default.";
                    readonly enum: readonly ["experimental", "stable"];
                };
                readonly "x-requires": {
                    readonly description: "The packages (or domains) the domain's words take terms from, by name, in ascending order and each once, no version: the requires every data file rebuilt from the domain carries (docs/contract-dir.md, \"Domains\"). A map of floors and an empty list are refused (the devel wave 2026-11-24): a domain that refers to nothing has none.";
                    readonly type: "array";
                    readonly items: {
                        readonly type: "string";
                        readonly pattern: "^[a-z][a-z0-9-]*(/[a-z][a-z0-9-]*)*$";
                    };
                    readonly uniqueItems: true;
                    readonly minItems: 1;
                };
            };
        };
        readonly "x-render": {
            readonly description: "The render block of the data file the root's x-file names, as render --with-domain rebuilds it (docs/render.md).";
            readonly type: "object";
        };
        readonly "x-file": {
            readonly description: "The data path of the file that carried x-render.";
            readonly type: "string";
            readonly pattern: "\\.json$";
        };
        readonly components: {
            readonly type: "object";
            readonly required: readonly ["schemas"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly schemas: {
                    readonly description: "The items of the domain, each named in upper snake case: a words item, a range item, a sheet, a scalar, a terms item or a map item.";
                    readonly type: "object";
                    readonly minProperties: 1;
                    readonly propertyNames: {
                        readonly pattern: "^[A-Z][A-Z0-9_]*$";
                    };
                    readonly additionalProperties: {
                        readonly oneOf: readonly [{
                            readonly $ref: "#/$defs/words";
                        }, {
                            readonly $ref: "#/$defs/range";
                        }, {
                            readonly $ref: "#/$defs/sheet";
                        }, {
                            readonly $ref: "#/$defs/scalar";
                        }, {
                            readonly $ref: "#/$defs/terms";
                        }, {
                            readonly $ref: "#/$defs/map";
                        }];
                    };
                };
            };
        };
    };
    readonly $defs: {
        readonly range: {
            readonly description: "A range item: its description the item's doc, and one parameter per name under properties, each a minimum and a maximum and optionally a default, a unit and a scale. The loaders read it at run time; nothing is rendered from it. What a schema cannot say stays in the reader: a minimum not above the maximum, a default inside them.";
            readonly type: "object";
            readonly required: readonly ["description", "properties"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-since": {};
                readonly "x-why": {};
                readonly type: {
                    readonly const: "object";
                };
                readonly properties: {
                    readonly type: "object";
                    readonly additionalProperties: {
                        readonly type: "object";
                        readonly required: readonly ["minimum", "maximum"];
                        readonly additionalProperties: false;
                        readonly properties: {
                            readonly minimum: {
                                readonly type: "number";
                            };
                            readonly maximum: {
                                readonly type: "number";
                            };
                            readonly default: {
                                readonly type: "number";
                            };
                            readonly "x-unit": {
                                readonly type: "string";
                            };
                            readonly "x-scale": {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
        };
        readonly words: {
            readonly description: "A words item: its description the item's doc, a oneOf of one word each in their declared order.";
            readonly type: "object";
            readonly required: readonly ["description", "oneOf"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-since": {};
                readonly "x-why": {};
                readonly "x-groups": {
                    readonly description: "The name of the words item of this document whose words are the groups of this item's words.";
                    readonly type: "string";
                };
                readonly "x-dimensions": {
                    readonly description: "The name of the words item of this document whose words are the dimensions of this item's words (a unit list's: what each unit measures); the data form's dimensions.";
                    readonly type: "string";
                };
                readonly "x-units": {
                    readonly description: "V28 (#189): the name of the words item of this document whose words are the units its words' x-figure-unit names; the data form's units.";
                    readonly type: "string";
                };
                readonly "x-bases": {
                    readonly description: "V28 (#189): the name of the words item of this document whose words are the bases its words' x-basis names; the data form's bases.";
                    readonly type: "string";
                };
                readonly "x-extension": {
                    readonly description: "V28 (#189): the data form's extension, verbatim: the carriers (CLAP extension id, LV2 prefix and namespace) of a resource-hint item.";
                    readonly type: "object";
                };
                readonly "x-default": {
                    readonly description: "A set's default: one of its words; the data form's default. Only on x-kind set.";
                    readonly type: "string";
                };
                readonly "x-c-codes": {
                    readonly description: "The item becomes constants, its codes header.";
                    readonly type: "boolean";
                };
                readonly "x-c-xmacro": {
                    readonly description: "The item's codes header also carries an X-macro; only with x-c-codes true.";
                    readonly type: "boolean";
                };
                readonly "x-kind": {
                    readonly description: "The data item it rebuilds (docs/render.md): a codes item (the default), each code keyed by its word's x-name, a words item, each word keyed by its title, a set, its words the ids in order and x-default its default, or a verbs item, each word a verb keyed by its title.";
                    readonly enum: readonly ["codes", "words", "set", "verbs"];
                };
                readonly "x-file": {
                    readonly description: "The data path the item came from.";
                    readonly type: "string";
                    readonly pattern: "\\.json$";
                };
                readonly "x-source": {
                    readonly $ref: "#/$defs/source";
                };
                readonly oneOf: {
                    readonly type: "array";
                    readonly minItems: 1;
                    readonly items: {
                        readonly $ref: "#/$defs/word";
                    };
                };
            };
            readonly if: {
                readonly required: readonly ["x-c-xmacro"];
                readonly properties: {
                    readonly "x-c-xmacro": {
                        readonly const: true;
                    };
                };
            };
            readonly then: {
                readonly required: readonly ["x-c-codes"];
                readonly properties: {
                    readonly "x-c-codes": {
                        readonly const: true;
                    };
                };
            };
        };
        readonly sheet: {
            readonly description: "A data sheet render --with-domain rebuilds (docs/render.md): no words, read nowhere else.";
            readonly type: "object";
            readonly required: readonly ["description", "x-kind", "x-file", "x-value"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-since": {};
                readonly "x-why": {};
                readonly "x-kind": {
                    readonly const: "sheet";
                };
                readonly "x-file": {
                    readonly type: "string";
                    readonly pattern: "\\.json$";
                };
                readonly "x-source": {
                    readonly $ref: "#/$defs/source";
                };
                readonly "x-value": {
                    readonly description: "The data sheet's value, verbatim.";
                    readonly type: "object";
                };
                readonly "x-docs": {
                    readonly description: "The data sheet's docs, verbatim.";
                    readonly type: "object";
                };
            };
        };
        readonly scalar: {
            readonly description: "A single value: its description the item's doc, x-value the value, x-unit its unit (an empty string for none). The runtime readers serve it (omx_domain_scalar, Domain.scalar); with an x-file, render --with-domain also rebuilds it as a data scalar (docs/render.md).";
            readonly type: "object";
            readonly required: readonly ["description", "x-kind", "x-unit", "x-value"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-since": {};
                readonly "x-why": {};
                readonly "x-kind": {
                    readonly const: "scalar";
                };
                readonly "x-file": {
                    readonly type: "string";
                    readonly pattern: "\\.json$";
                };
                readonly "x-source": {
                    readonly $ref: "#/$defs/source";
                };
                readonly "x-unit": {
                    readonly description: "The scalar's unit, the data form's unit.";
                    readonly type: "string";
                };
                readonly "x-value": {
                    readonly description: "The scalar's value: a number, or true or false.";
                    readonly oneOf: readonly [{
                        readonly type: "number";
                    }, {
                        readonly type: "boolean";
                    }];
                };
            };
        };
        readonly terms: {
            readonly description: "A terms item (3.21.0): a format's terms as one specification or header states them, rebuilt as the data form's terms item; the runtime readers serve it as words, the words the term keys.";
            readonly type: "object";
            readonly required: readonly ["description", "x-kind", "x-format", "x-spec", "x-version", "oneOf"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-since": {};
                readonly "x-why": {};
                readonly "x-kind": {
                    readonly const: "terms";
                };
                readonly "x-file": {
                    readonly type: "string";
                    readonly pattern: "\\.json$";
                };
                readonly "x-source": {
                    readonly $ref: "#/$defs/source";
                };
                readonly "x-format": {
                    readonly description: "The format, the data form's format (lv2, clap).";
                    readonly type: "string";
                };
                readonly "x-spec": {
                    readonly description: "The specification's URI or the header's path, the data form's spec.";
                    readonly type: "string";
                };
                readonly "x-version": {
                    readonly description: "The specification's version, the data form's version.";
                    readonly type: "string";
                };
                readonly "x-deprecated": {
                    readonly const: true;
                };
                readonly oneOf: {
                    readonly type: "array";
                    readonly minItems: 1;
                    readonly items: {
                        readonly $ref: "#/$defs/term";
                    };
                };
            };
        };
        readonly map: {
            readonly description: "A map item (omx-contract#191, owner ruling 2026-11-23): one format's mapping table, every field a scan of the format reads, each a row keyed by its source field; rebuilt as the data form's formatMap item (docs/descriptors.md), whose rows validate checks. The runtime readers serve it as words, the words the source keys.";
            readonly type: "object";
            readonly required: readonly ["description", "x-kind", "x-format", "oneOf"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-since": {};
                readonly "x-why": {};
                readonly "x-kind": {
                    readonly const: "map";
                };
                readonly "x-file": {
                    readonly type: "string";
                    readonly pattern: "\\.json$";
                };
                readonly "x-source": {
                    readonly $ref: "#/$defs/source";
                };
                readonly "x-format": {
                    readonly description: "The format whose fields the rows map (lv2, clap), the data form's format.";
                    readonly type: "string";
                };
                readonly oneOf: {
                    readonly type: "array";
                    readonly minItems: 1;
                    readonly items: {
                        readonly $ref: "#/$defs/mapRow";
                    };
                };
            };
        };
        readonly mapRow: {
            readonly description: "One row of a map: const and title its source key, the field as the format names it (units:unit, clap_param_info.min_value, omx_clap_panel_display.meter_ids[0]); x-code its place; exactly one outcome, x-word, x-extension or x-dropped; exactly one cover, x-term or x-from; description its doc. The data form's row is { term, from, word, extension, dropped, doc }.";
            readonly type: "object";
            readonly required: readonly ["const", "title", "x-code"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly const: {
                    readonly type: "string";
                    readonly pattern: "^[A-Za-z_][A-Za-z0-9_]*(\\[[0-9]+\\])?([.:#/][A-Za-z0-9_][A-Za-z0-9_-]*(\\[[0-9]+\\])?)*$";
                };
                readonly title: {
                    readonly type: "string";
                    readonly minLength: 1;
                };
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-code": {
                    readonly type: "integer";
                    readonly minimum: 0;
                };
                readonly "x-term": {
                    readonly description: "The term link, <TERMS item>#<term>: the term of a terms item of the map's format (an x-kind terms item, its x-spec the standard) the field is; the data form's term.";
                    readonly type: "string";
                    readonly pattern: "^[A-Z][A-Z0-9_]*#[A-Za-z0-9][A-Za-z0-9._/+-]*$";
                };
                readonly "x-from": {
                    readonly description: "For a field no terms item holds: where it is defined, a link <path>#<symbol>[.<field>] or an http(s) URL; the data form's from.";
                    readonly type: "string";
                    readonly minLength: 1;
                };
                readonly "x-word": {
                    readonly description: "The outcome descriptor word: the word the field becomes, the transform that converts it and that transform's data, the lookup sub-table values (a code token or unit IRI to its value; a unit's value is a PARAM_UNITS id spelled as its standard symbol, plugin-hostd#215 decision 2) or factor. Never code. The data form's word, verbatim.";
                    readonly type: "object";
                    readonly required: readonly ["word", "transform"];
                    readonly additionalProperties: false;
                    readonly properties: {
                        readonly word: {
                            readonly type: "string";
                            readonly pattern: "^[a-z][A-Za-z0-9]*(\\[\\])?(\\.[a-z][A-Za-z0-9]*(\\[\\])?)*$";
                        };
                        readonly transform: {
                            readonly type: "string";
                            readonly pattern: "^[a-z][a-z0-9]*(-[a-z0-9]+)*$";
                        };
                        readonly values: {
                            readonly type: "object";
                            readonly additionalProperties: {
                                readonly anyOf: readonly [{
                                    readonly type: "string";
                                }, {
                                    readonly type: "number";
                                }, {
                                    readonly type: "boolean";
                                }];
                            };
                            readonly minProperties: 1;
                        };
                        readonly factor: {
                            readonly type: "number";
                        };
                    };
                    readonly not: {
                        readonly required: readonly ["values", "factor"];
                        readonly properties: {
                            readonly values: true;
                            readonly factor: true;
                        };
                    };
                };
                readonly "x-extension": {
                    readonly description: "The outcome extension passthrough: the field is carried in the descriptor's extension bag; the data form's extension.";
                    readonly const: true;
                };
                readonly "x-dropped": {
                    readonly description: "The outcome dropped-with-ruling: the field is read and dropped, by the ruling named (a plugin unit with no standard id is such a row, plugin-hostd#215 decision 2); the data form's dropped.";
                    readonly type: "object";
                    readonly required: readonly ["ruling"];
                    readonly additionalProperties: false;
                    readonly properties: {
                        readonly ruling: {
                            readonly type: "string";
                            readonly minLength: 1;
                        };
                    };
                };
            };
            readonly oneOf: readonly [{
                readonly required: readonly ["x-word"];
                readonly properties: {
                    readonly "x-word": true;
                };
            }, {
                readonly required: readonly ["x-extension"];
                readonly properties: {
                    readonly "x-extension": true;
                };
            }, {
                readonly required: readonly ["x-dropped"];
                readonly properties: {
                    readonly "x-dropped": true;
                };
            }];
            readonly allOf: readonly [{
                readonly oneOf: readonly [{
                    readonly required: readonly ["x-term"];
                    readonly properties: {
                        readonly "x-term": true;
                    };
                }, {
                    readonly required: readonly ["x-from"];
                    readonly properties: {
                        readonly "x-from": true;
                    };
                }];
            }];
        };
        readonly term: {
            readonly description: "One term: const and title its key (the data form's key, which may hold . / + -), x-code its place, x-term the term as the data form writes it.";
            readonly type: "object";
            readonly required: readonly ["const", "title", "x-code", "x-term"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly const: {
                    readonly type: "string";
                    readonly minLength: 1;
                };
                readonly title: {
                    readonly type: "string";
                    readonly minLength: 1;
                };
                readonly "x-code": {
                    readonly type: "integer";
                    readonly minimum: 0;
                };
                readonly "x-term": {
                    readonly type: "object";
                };
            };
        };
        readonly word: {
            readonly type: "object";
            readonly required: readonly ["const", "title", "x-code"];
            readonly additionalProperties: false;
            readonly properties: {
                readonly const: {
                    readonly description: "The word as written: any string.";
                    readonly type: "string";
                    readonly minLength: 1;
                };
                readonly title: {
                    readonly description: "The word's key, the name of its macro.";
                    readonly type: "string";
                    readonly pattern: "^[A-Za-z][A-Za-z0-9]*$";
                };
                readonly description: {
                    readonly type: "string";
                };
                readonly "x-code": {
                    readonly description: "The word's code, its place in the order.";
                    readonly type: "integer";
                    readonly minimum: 0;
                };
                readonly "x-text": {
                    readonly description: "The English source sentence the catalogs translate.";
                    readonly type: "string";
                };
                readonly "x-args": {
                    readonly description: "The ordered names of the x-text's {name} placeholders, stored: each placeholder once and no other name; the data form's args.";
                    readonly type: "array";
                    readonly items: {
                        readonly type: "string";
                        readonly pattern: "^[a-z][A-Za-z0-9]*$";
                    };
                    readonly uniqueItems: true;
                };
                readonly "x-group": {
                    readonly description: "A word of the item x-groups names.";
                    readonly type: "string";
                };
                readonly "x-symbol": {
                    readonly description: "A unit word's symbol as written (`%`, `\"\"`, `dB/oct`), the one a wire word cannot spell; the data form's symbol.";
                    readonly type: "string";
                };
                readonly "x-uri": {
                    readonly description: "The absolute URI a format spells the word as, of any scheme (`http://lv2plug.in/ns/extensions/units#db`, `urn:openmixer:unit#dBoct`); the data form's uri.";
                    readonly type: "string";
                    readonly pattern: "^[A-Za-z][A-Za-z0-9+.-]*:[^\\s]+$";
                };
                readonly "x-dimension": {
                    readonly description: "A word of the item x-dimensions names: what the unit measures; the data form's dimension.";
                    readonly type: "string";
                };
                readonly "x-figure-unit": {
                    readonly description: "V28 (#189): a word of the item x-units names, the unit the hint's figure is in; the data form's figureUnit.";
                    readonly type: "string";
                };
                readonly "x-basis": {
                    readonly description: "V28 (#189): a word of the item x-bases names, how the hint's figure is known; the data form's basis.";
                    readonly type: "string";
                };
                readonly "x-format": {
                    readonly description: "A verb's format, the line as mod-host's protocol_add_command takes it; the data form's format. Only on a verb.";
                    readonly type: "string";
                };
                readonly "x-reply": {
                    readonly description: "A verb's reply as the protocol writes it; the data form's reply. Only on a verb.";
                    readonly type: "string";
                };
                readonly "x-codes": {
                    readonly description: "The refusals a verb answers, each { ref: <ITEM>.<name> }; the data form's codes. Only on a verb.";
                    readonly type: "array";
                    readonly items: {
                        readonly type: "object";
                        readonly required: readonly ["ref"];
                        readonly additionalProperties: false;
                        readonly properties: {
                            readonly ref: {
                                readonly type: "string";
                            };
                        };
                    };
                };
                readonly "x-implemented-by": {
                    readonly description: "What each host owes a verb, by host; the data form's implementedBy. Only on a verb.";
                    readonly type: "object";
                    readonly additionalProperties: {
                        readonly enum: readonly ["required", "optional", "unsupported"];
                    };
                };
                readonly "x-since": {
                    readonly description: "The version a verb came in; the data form's since. Only on a verb.";
                    readonly type: "string";
                };
                readonly "x-resp": {
                    readonly description: "A reply code's number, the n of resp <n>; the data form's resp. Only on a code.";
                    readonly type: "integer";
                    readonly maximum: -1;
                };
                readonly "x-transient": {
                    readonly description: "A reply code that says nothing about the plugin or the request; the data form's transient. Only on a code.";
                    readonly type: "boolean";
                };
                readonly "x-leaves-no-mark": {
                    readonly description: "A refusal that leaves no mark on the plugin, no verdict and no history; the data form's leavesNoMark. Only on a code.";
                    readonly type: "boolean";
                };
                readonly "x-name": {
                    readonly description: "The code's key in the data item it rebuilds, the macro stem (docs/render.md).";
                    readonly type: "string";
                    readonly pattern: "^[A-Za-z][A-Za-z0-9]*$";
                };
                readonly "x-from": {
                    readonly description: "What the word is taken from: a term of a terms item, or a word of a words item of another domain (or its own), by its $ref (the domain id and the item) and x-term (the term's key, or the target word's title). A package or domain other than omx-contract, the document's own and its owner is declared in info.x-requires.";
                    readonly type: "array";
                    readonly minItems: 1;
                    readonly items: {
                        readonly type: "object";
                        readonly required: readonly ["$ref", "x-term"];
                        readonly additionalProperties: false;
                        readonly properties: {
                            readonly $ref: {
                                readonly type: "string";
                                readonly pattern: "^https://openmixer\\.org/contract/[a-z][a-z0-9-]*(/[a-z][a-z0-9-]*)*#/components/schemas/[A-Z][A-Z0-9_]*$";
                            };
                            readonly "x-term": {
                                readonly description: "The term's key in a terms item, or the title of the target word in a words item.";
                                readonly type: "string";
                                readonly minLength: 1;
                            };
                        };
                    };
                };
            };
        };
        readonly source: {
            readonly type: "object";
            readonly description: "Where a definition comes from and where it is implemented (docs/contract-dir.md): from, the provenance, a link compared to the whole value or a map from a field path of the value to a link; impl, the connector; at, <package>@<version> of links outside the owner's tree. A link may carry its own at ({ link, at }), which stands for it in place of the source's.";
            readonly properties: {
                readonly from: {
                    readonly oneOf: readonly [{
                        readonly $ref: "#/$defs/oneLink";
                    }, {
                        readonly type: "object";
                        readonly propertyNames: {
                            readonly pattern: "^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)*$";
                        };
                        readonly additionalProperties: {
                            readonly $ref: "#/$defs/oneLink";
                        };
                        readonly minProperties: 1;
                    }];
                };
                readonly impl: {
                    readonly $ref: "#/$defs/links";
                };
                readonly at: {
                    readonly $ref: "#/$defs/at";
                };
            };
            readonly minProperties: 1;
            readonly additionalProperties: false;
        };
        readonly links: {
            readonly oneOf: readonly [{
                readonly $ref: "#/$defs/oneLink";
            }, {
                readonly type: "array";
                readonly items: {
                    readonly $ref: "#/$defs/oneLink";
                };
                readonly minItems: 1;
                readonly uniqueItems: true;
            }];
        };
        readonly oneLink: {
            readonly oneOf: readonly [{
                readonly $ref: "#/$defs/link";
            }, {
                readonly $ref: "#/$defs/linkAt";
            }];
        };
        readonly linkAt: {
            readonly type: "object";
            readonly description: "One link with its own at: <package>@<version> of the tree it lies in, in place of the source's (an impl in the owner's tree beside a from in the console's, at the commit it was imported from).";
            readonly properties: {
                readonly link: {
                    readonly $ref: "#/$defs/link";
                };
                readonly at: {
                    readonly $ref: "#/$defs/at";
                };
            };
            readonly required: readonly ["link", "at"];
            readonly additionalProperties: false;
        };
        readonly link: {
            readonly type: "string";
            readonly description: "<path>#<symbol>[.<field>|[<key>]]...: a path relative to the owner's root, a symbol defined there (enum X and struct X name a tag), and selectors into its value.";
            readonly pattern: "^[A-Za-z0-9_+.-]+(/[A-Za-z0-9_+.-]+)*#((enum|struct|union) )?[A-Za-z_][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*|\\[[A-Za-z0-9_.-]+\\])*$";
        };
        readonly at: {
            readonly type: "string";
            readonly pattern: "^[a-z][a-z0-9]*(-[a-z0-9]+)*@[A-Za-z0-9._+-]+$";
        };
    };
};
