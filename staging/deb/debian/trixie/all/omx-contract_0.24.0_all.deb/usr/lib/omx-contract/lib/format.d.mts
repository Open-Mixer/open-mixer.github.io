/** The schema's version, x.y.z: the omx-contract release that last changed it. */
export declare const SCHEMA_VERSION: string;
/** The format major this omx-contract reads: a document of another one is refused by name. */
export declare const FORMAT_MAJOR: number;
/** The format a document this omx-contract writes states, `x-omx-contract`: MAJOR.MINOR of the schema. */
export declare const CONTRACT_FORMAT: string;
/** A format as a document states it: MAJOR.MINOR, no leading zero. */
export declare const FORMAT: RegExp;
