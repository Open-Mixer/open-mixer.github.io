/** @returns {{ ok: boolean, errors: { path: string, code: string, message: string }[] }} */
export declare function validate(schema: object, doc: unknown): {
    ok: boolean;
    errors: {
        path: string;
        code: string;
        message: string;
    }[];
};
