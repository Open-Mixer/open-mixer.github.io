/**
 * The one formatting of a data file: two-space indent, one key per line, keys in schema
 * order, a trailing newline. Names (items, fields, sheet keys) keep the order the author gave them:
 * a travels table's field order is its C block order. A kernel file's sections come in their order (controls,
 * readouts, tables, aggregates, constants), its controls and readouts in the author's order, each one's keys in
 * schema order.
 *
 * A domain document (docs/contract-dir.md, "Domains") has the same one rule: two-space indent, one key per line, keys in
 * the order of the domain document schema, a trailing newline; the names of its schemas, the words of a `oneOf` (their
 * order is their `x-code`) and the entries of an `x-from` keep the order the author gave them.
 */
/** The canonical text of a parsed data file. */
export declare function formatDoc(doc: any): string;
/** Whether a parsed document is a domain document (an `$id` and `components`) rather than a classic data file. */
export declare const isDomainDoc: (doc: any) => boolean;
/** The canonical text of a parsed domain document. */
export declare function formatDomain(doc: any): string;
/** The canonical text of a loaded file: a domain document by the domain rule, any other by the classic one. */
export declare function formatFile(file: any): string;
