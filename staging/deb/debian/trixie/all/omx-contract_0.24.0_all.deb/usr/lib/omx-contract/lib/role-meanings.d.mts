/** Every role of the read, in item order: `[{ item, key, row, rel, pkg }]`. */
export declare function rolesOf(items: any): any[];
/** The meaning of every role the read declares: `Map<role, meaning>` (`unknown` for a role that plays none). */
export declare function meaningOfRoles(items: any): Map<any, any>;
/**
 * The problems of every role of `items` (a read's items, `Map<name, { name, rel, item, pkg }>`):
 * `[{ name, rel, item, message }]`, `name` the CONTRACT_CODES name: roleDuplicate (one role declared twice, by one
 * package or two).
 */
export declare function roleProblems(items: any): any[];
