import type { Json, JsonObject } from './json.mjs';
/** A catalog entry made with its provenance: a person's, or a model's from a source sentence. */
export interface CatalogRecord {
    readonly text: string;
    readonly by: 'human' | 'same' | 'machine';
    readonly model?: string;
    readonly source?: string;
}
/** A catalog entry: the sentence with how it was made. */
export type CatalogEntry = CatalogRecord;
/** A catalog document: `{ kind: 'catalog', lang, owner, messages }`. */
export interface Catalog {
    readonly kind: 'catalog';
    readonly lang: string;
    readonly owner: string;
    readonly messages: Readonly<Record<string, CatalogEntry>>;
}
/** A catalog key's declaration: its `args` and its English source sentence. */
export interface CatalogKey {
    readonly args: readonly string[];
    readonly en: string | undefined;
}
/** One problem of a catalog. */
export interface CatalogProblem {
    readonly file: string;
    readonly item: string;
    readonly rule: 'catalog-schema' | 'catalog-key' | 'catalog-placeholders' | 'catalog-stale';
    readonly message: string;
}
/** The resolved data `catalogKeys` reads (`resolveData`): its items by name, and the package of each when it names one. */
export type ResolvedItems = Iterable<[string, JsonObject]> & {
    readonly packageOf?: ReadonlyMap<string, string>;
};
/** Where an installed owner's catalogs live, the same for rpm and deb: `/usr/share/<owner>/catalogs`. */
export declare const CATALOG_SHARE_DIR = "/usr/share";
export declare const catalogDirOf: (owner: string, root?: string) => string;
export declare const catalogPathOf: (owner: string, lang: string, root?: string) => string;
/** The sha256 of a source sentence, the lowercase hex of its UTF-8 bytes: what a model's entry records as `source`. */
export declare function sourceHash(sentence: string): string;
/** An entry's sentence. */
export declare const entryText: (entry: CatalogEntry) => string;
/** Whether `entry` was made from another source sentence than `source`: a recorded hash `source` no longer has. */
export declare function isStale(entry: CatalogEntry, source: string): boolean;
/** The key of a code (its code) or of a word (`<ITEM>.<word>`). */
export declare const codeKey: (code: string) => string;
export declare const wordKey: (item: string, word: string) => string;
/**
 * Every code and word an owner declares, by its catalog key: `Map<key, { args, en }>`. `resolved` is the resolved data
 * (`resolveData`), and `extra` more items as `[name, item]` (a tool's own table, data/codes.json); `owner`, when the
 * data names packages, keeps only that package's items; `ownerOf` maps a package to its owner (a domain's `info.x-owner`), the package itself when absent.
 */
export declare function catalogKeys(resolved: ResolvedItems, { owner, extra, ownerOf }?: {
    owner?: string;
    extra?: readonly [string, JsonObject][];
    ownerOf?: ReadonlyMap<string, string>;
}): Map<string, CatalogKey>;
/**
 * A catalog's problems, `[{ file, item, rule, message }]`: its schema (`catalog-schema`), a key that is no code or word
 * the owner declares (`catalog-key`), and a placeholder that is not one of that entry's `args` (`catalog-placeholders`).
 */
export declare function catalogProblems(rel: string, catalog: Json, keys: ReadonlyMap<string, CatalogKey>): CatalogProblem[];
/**
 * The catalog of `owner` in `lang`, or `undefined` when none is installed or it does not read: a surface then shows the
 * source sentence. `root` defaults to the share dir; a test or a build names its own.
 */
export declare function loadCatalog(owner: string, lang: string, root?: string): Catalog | undefined;
/**
 * The sentence a surface shows for `key`: the catalog's, else `source` (the code's or word's `text.en`). An entry made
 * from another source sentence than `source` is stale and skipped; with no `source` to compare, the entry is read.
 */
export declare function sentenceOf(catalog: Catalog | undefined, key: string, source: string): string;
export declare function sentenceOf(catalog: Catalog | undefined, key: string, source?: string): string | undefined;
/** `sentence` with each `{name}` replaced by `args[name]`; a placeholder with no value is left as written. */
export declare function fill(sentence: string, args?: Readonly<Record<string, unknown>>): string;
