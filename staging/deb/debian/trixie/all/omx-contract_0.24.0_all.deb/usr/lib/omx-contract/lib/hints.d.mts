/**
 * The resource hints (docs/resource-hints.md): the words item that declares an `extension`, and the one place the
 * carriers' types per unit are spelled. The CLAP header and the LV2 Turtle are both rendered from the item; this file
 * is what they and the validator share.
 */
/**
 * The C type and the XSD datatype of a hint's figure, by the word of RESOURCE_UNITS it is given in. An integer figure
 * is an xsd:integer, the integer type lilv reads: it logs "Unknown datatype" for xsd:unsignedLong and xsd:unsignedInt
 * on every plugin that states a hint. `bound` is the range the carrier's C type allows, stated in the property's comment.
 */
export declare const HINT_UNITS: {
    bytes: {
        c: string;
        xsd: string;
        bound: string;
    };
    count: {
        c: string;
        xsd: string;
        bound: string;
    };
    ms: {
        c: string;
        xsd: string;
        bound: string;
    };
    flag: {
        c: string;
        xsd: string;
    };
};
/** The carrier types of a hint's unit; a unit the carriers have no type for is refused by name, never as a missing property. */
export declare function unitOf(key: any, w: any): any;
/** The `declared` mask of the CLAP structure is a uint32_t: one bit per hint. */
export declare const MAX_HINTS = 32;
/** The words items of a resolved read that declare an extension, in file order. */
export declare const hintItems: (resolved: any) => any[];
/** A hint's member name in the CLAP structure: its word in snake case. */
export declare const memberOf: (word: any) => any;
/** A hint's name in upper snake case, as the bit and the define spell it. */
export declare const constOf: (key: any) => any;
