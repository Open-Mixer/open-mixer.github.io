import type { JsonObject } from './json.mjs';
/** The stable `$id` of a domain: the URL every cross-domain reference names. */
export declare const domainId: (name: string) => string;
/** The one JSON Schema dialect a domain document is written in. */
export declare const DOMAIN_SCHEMA = "https://json-schema.org/draft/2020-12/schema";
/**
 * A domain's prefix: its name in upper snake case with its underscore, which every item name of the domain starts with
 * (`panel` is `PANEL_`, `dsp-kernels` and `dsp/kernels` are `DSP_KERNELS_`).
 */
export declare const domainPrefix: (name: string) => string;
/** A domain's name as the stem of its codes header: `panel_codes.h`, `dsp_kernels_codes.h`. */
export declare const domainStem: (name: string) => string;
/** A domain's marked items: `x-c-codes` is in the map, and `xmacro` says `x-c-xmacro` is too. */
export type DomainCodes = ReadonlyMap<string, {
    readonly xmacro: boolean;
}>;
/** A domain document of a read, for the prefix check: its path and the names of its items. */
export interface DomainItems {
    readonly rel: string;
    readonly items: readonly string[];
}
/**
 * The prefix check of a read's domains (docs/contract-dir.md, "Domains"). An item of a domain starts with the domain's
 * prefix, and no item starts with the prefix of a LONGER domain of the read (`DSP_KERNELS_X` in `dsp` collides with
 * `dsp/kernels`): two headers never define one name. A name alone cannot say whether `DSP_KERNELS_` is a domain, so
 * the second rule compares against the domains of the read.
 * @throws ContractRefusal contract.item.prefix, naming the item and the domain.
 */
export declare function checkItemPrefixes(docs: readonly DomainItems[]): void;
/** The last segment of a domain's name: what its document is called (`dsp/kernels` is `kernels.json`). */
export declare const domainLeaf: (name: string) => string;
/** The place of a domain's document under a contractdir, `<domain>/<last segment>.json`: the one rule the reader reads a domain by. */
export declare const domainPath: (name: string) => string;
/** The domain a document's path names, the inverse of {@link domainPath}; undefined when the path is no domain's place. */
export declare function domainOfPath(rel: string): string | undefined;
/** A domain's name: what a directory under a contractdir is called when it is not a schema major. */
export declare const DOMAIN_NAME: RegExp;
/** True when the MAJOR.MINOR.PATCH version `a` is below `b`. */
export declare function versionBelow(a: string, b: string): boolean;
/**
 * Refuse a document's `x-omx-contract` (a domain document's or a manifest's, at `at`) that is absent or not MAJOR.MINOR
 * (contract.manifest.invalid), or of another MAJOR than `major` (contract.schema.major); a higher MINOR is read.
 */
export declare function formatProblem(format: unknown, major: number, at: string): void;
/**
 * `released`: the document is a RELEASED tree's, read back as data (`semver <previous tag>` compares it with this tree).
 * A released tree passed its own release's rules; the spelling rules of ids this tree adds later (a unit id is
 * camelCase, 2026-11-23) are not held against it, or a rename the tree makes on purpose would refuse the comparison
 * that classifies it. Every other rule holds. A tree being built or installed is never read this way.
 */
export declare function readDomain(name: string, doc: JsonObject, schemaUrl: string, schemaMajor: number, { released }?: {
    released?: boolean;
}): {
    doc: JsonObject;
    manifest: JsonObject;
    codes: DomainCodes;
    names: string[];
};
/**
 * The names a `requires` (a data file's) or an `info.x-requires` (a domain's) lists: the packages and domains whose
 * items or terms the file refers to, in ascending order and each once, no version (the devel wave 2026-11-24, no hand-kept floors: a file
 * is read by the installed schema, beside the packages installed with it). `bad` is called with what is wrong, and
 * must throw: a map of version floors, the form before the devel wave 2026-11-24, is refused by name, and so is an empty list: absent
 * is the one way to refer to nothing.
 */
export declare function requiresNames(v: unknown, bad: (message: string) => never): string[];
/** A domain's `info.x-requires`, the package and domain names it takes from ([] when it declares none). Read the document with readDomain() first. */
export declare function domainRequires(doc: JsonObject): string[];
/** A word's term taken from a domain: where it is written, the word, the domain or package `to` and the `item` and `term` there. */
export interface DomainFrom {
    readonly where: string;
    readonly word: string;
    readonly to: string;
    readonly item: string;
    readonly term: string;
    /** The word's place in its item (its x-code), its description and its x-text, for word-from-differs. */
    readonly code: number;
    readonly doc?: unknown;
    readonly text?: unknown;
}
/**
 * The terms and words the words of a domain take (`x-from`), for the read of a contract directory to resolve in the
 * package or domain each names: with `rebuilt` (the default) only the words of the items with an `x-file`, the ones
 * `render --with-domain` rebuilds; else every word. Read the document with readDomain() first.
 */
export declare function domainFroms(doc: JsonObject, { rebuilt }?: {
    rebuilt?: boolean;
}): DomainFrom[];
/**
 * The data files a domain was made from (docs/render.md, `render --with-domain`), `{ <x-file>: <text> }`: the items of
 * one `x-file` in the document's order, each `{ kind, since, source, doc, why, ... }`: `x-kind` codes (the default)
 * with `codes` (each word's `x-name` its key, `const` its code, `description` its doc, `x-text` its English text,
 * `x-args` its args), `x-kind` words with `groups` and `words` (each word's `title` its key, `const` its word, `x-group`
 * its group, `x-from` its terms, `description`, `x-text` and `x-args` as for a code), `x-kind` scalar with `unit` and
 * `value`, `x-kind` map as a formatMap with `format` and `rows` (each row `{ term, from, word, extension, dropped, doc }`),
 * and `x-kind` sheet with `value` and `docs`; the root's `x-render` goes to the file the root's `x-file`
 * names. A domain that declares `info.x-requires` gives every file it rebuilds `requires`, the declared package and
 * domain names in ascending order; a word whose `x-from` reaches a package beyond those, omx-contract, the
 * domain and its owner is refused by name. Read the document with readDomain() first. An item with no `x-file` is read
 * at run time only: it is not rebuilt, and not refused (a domain may hold both).
 */
export declare function domainDataFiles(name: string, doc: JsonObject): Record<string, string>;
