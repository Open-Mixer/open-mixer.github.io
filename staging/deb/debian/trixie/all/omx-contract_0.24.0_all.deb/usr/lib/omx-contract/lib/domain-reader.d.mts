/** The longest domain name, as in the C header (`OMX_DOMAIN_NAME_MAX`). */
export declare const DOMAIN_NAME_MAX = 255;
/** A word of a words item: as written, its key, its line (undefined when it has none) and its code. */
export interface DomainWord {
    readonly word: string;
    readonly title: string;
    readonly description?: string;
    readonly code: number;
}
/** The value of a scalar item (since 3.21.0): a number, or true or false, in its unit (`''` for none). */
export interface DomainScalar {
    readonly value: number | boolean;
    readonly unit: string;
}
/** A parameter of a range item. */
export interface DomainRange {
    readonly min: number;
    readonly max: number;
    readonly default?: number;
    readonly unit: string;
    readonly scale: string;
}
/** One catalog of a domain: its language and its sentences by key. */
export interface DomainCatalog {
    readonly lang: string;
    readonly messages: ReadonlyMap<string, string>;
}
/**
 * The catalogs of a domain directory `ddir` (`<ddir>/catalogs/<lang>.json`): each a regular file (never a symlink) named by a
 * language tag, JSON with a `lang` that is its name and a `messages` object of entries with a `text`. Sorted by language.
 * @throws ContractRefusal contract.catalog.invalid for the first that is not.
 */
export declare function readCatalogs(ddir: string, domain: string): DomainCatalog[];
interface WordsItem {
    readonly words: DomainWord[];
    readonly texts: Map<string, string>;
}
interface RangeItem {
    readonly params: Map<string, DomainRange>;
}
interface ScalarItem {
    readonly scalar: DomainScalar;
}
/** An opened, validated domain: read-only lookups of its words, ranges and sentences. */
export declare class Domain {
    private readonly wordItems;
    private readonly rangeItems;
    readonly catalogs: readonly DomainCatalog[];
    private readonly scalarItems;
    /** @internal */
    constructor(wordItems: Map<string, WordsItem>, rangeItems: Map<string, RangeItem>, catalogs: readonly DomainCatalog[], scalarItems?: Map<string, ScalarItem>);
    private item;
    /** The words of a words item in declared order. @throws ContractRefusal contract.item.unknown. */
    words(item: string): readonly DomainWord[];
    /** A word of an item by the word as written. @throws ContractRefusal contract.item.unknown, contract.word.unknown. */
    word(item: string, word: string): DomainWord;
    /** A parameter of a range item. @throws ContractRefusal contract.item.unknown, contract.word.unknown. */
    range(item: string, name: string): DomainRange;
    /** The value and unit of a scalar item (since 3.21.0). @throws ContractRefusal contract.item.unknown, contract.word.unknown for a words or range item. */
    scalar(item: string): DomainScalar;
    /** The sentence of a word (`<ITEM>.<word>`) in `lang`, else its English source sentence; undefined when it has neither. */
    text(lang: string | undefined, key: string): string | undefined;
}
/**
 * Open `domain` from the first of `dirs` (a directory, a `:` list or an array) that holds `<domain>/<last segment>.json`,
 * and validate it as the C loader does. `needs` is the version floor `x.y.z`, or null for none.
 * @throws ContractRefusal contract.dir.absent, contract.file.not-json, contract.file.invalid, contract.manifest.invalid,
 * contract.package.too-old or contract.catalog.invalid, with the message and the member the C loader gives.
 */
export declare function openDomainAt(dirs: string | readonly string[], domain: string, needs?: string | null): Domain;
export {};
