/**
 * word-from-differs (docs/contract-dir.md, "Domains"): a word whose `x-from` (the data form's `from`) names a word of a
 * WORDS item is that word. Its const (the data form's `word`) and its x-code (its place in its item, as the data
 * form's order is) are the target's, and so are its description (`doc`) and x-text (`text.en`), copied, never inherited.
 * A terms target is not compared: a word is never its term. Both readers that resolve a from use this one comparison:
 * validate (rule word-from-differs) and the read of a contract directory (lib/contract-dir.mjs).
 */
/** A word as the comparison reads it: its const, its x-code, its description and its English x-text. */
export interface FromWord {
    readonly word: unknown;
    readonly code: number;
    readonly doc?: unknown;
    readonly text?: unknown;
}
/** One field a word differs in from the word it names: the domain field's name, its value and the target's. */
export interface FromDifference {
    readonly field: 'const' | 'x-code' | 'description' | 'x-text';
    readonly mine: unknown;
    readonly theirs: unknown;
}
/**
 * The fields `mine` differs in from `target`, the word its from names; empty when it is that word.
 *
 * An ABSENT description or x-text where the target carries one is a difference too (owner ruling (b), 2026-11-20:
 * copies only, no inheritance), so a runtime reader, which never resolves x-from, serves the same text a render does.
 */
export declare function fromDifferences(mine: FromWord, target: FromWord): FromDifference[];
export declare const fromDifference: (d: FromDifference) => string;
