import { placeholdersOf } from './placeholders.mjs';
/** The version of the schema's vocabulary (`x-omx-schema-version`), the version of the installed schema every file is read by. */
export { SCHEMA_VERSION } from './format.mjs';
/**
 * The kernel-file shape (2.0.0), which the item schema cannot see: only the four sections at the top; every control
 * named, of kind travel or choice, unique by name, a travel carrying a `travel` and a choice its `ids`; a control's
 * `table` declared under `tables`; `rearms` a boolean, and only on a control; a use (a control with a `global` and no
 * travel or ids) naming an item another control of the kernel declares, of its kind; `count` an item name; `of` naming
 * another control of its kind with `when` a { control, is } of a choice of the kernel; an aggregate's fields naming
 * controls; a constant a scalar, a list or a sheet; `readouts` a list of readouts, unique by name.
 * A kernel file written as a flat item map (the 1.x shape) is refused as a whole. Any other data file returns [].
 */
export declare function shapeProblems(rel: any, doc: any): any[];
/** The compiled schema validator. */
export declare function schemaValidator(): any;
/** The validator of one readout, the schema's `$defs/readout`. */
export declare function readoutValidator(): any;
/**
 * The rules about the meaning of the numbers, not their shape (they live with the data they judge):
 * a set's default, labels and standard ids; a travel's scale is a PARAM_SCALES id; a count; a sheet's default inside its min and
 * max; the checks the files declare. No rule names an item.
 */
/**
 * A code's or a word's source sentence (docs/data-layout.md): each `{name}` placeholder is one of `args`
 * (`<what>-text-arg`). The schema holds the sentence to English alone; a translation is a catalog's (lib/catalog.mjs).
 */
export { placeholdersOf };
/** The item-shaped object the schema validates `f` as: the `FILE_KEYS` it carries, plus every entry a kernel file
 * expands to (data.mjs `entriesOf`). Throws when `f.doc` has no valid shape to expand. */
export declare function itemsOf(f: any): {
    [x: string]: any;
};
/**
 * A use takes an item another control declares: one of its own kernel, or one of another kernel (a detector topology
 * one dynamics kernel declares and a second takes), so two kernels read ONE declaration and no copy of it. Over
 * the files read together: the item exists and is the use's kind, a choice a set and a travel a single travel.
 * `[{ rel, item, message }]`.
 */
export declare function useProblems(data: any): any[];
/**
 * The problems one file has on its own, before any merge: its `$schema` (the relative path in `data/`; a file read
 * from a contract directory carries `installed: true`, whose `$schema` the reader has checked already), its shape,
 * and the schema over the items it expands to with its file keys. A plugin descriptor (docs/descriptors.md) is held to
 * the schema whole, then to its own rules, whose problems also carry `code`, the CONTRACT_CODES code.
 * `[{ file, item, rule, message }]`.
 */
export declare function fileProblems(f: any): any[];
/** Every problem of the loaded data: `[{ file, item, rule, message }]`; empty is valid. */
export declare function validateData(data: any): any[];
