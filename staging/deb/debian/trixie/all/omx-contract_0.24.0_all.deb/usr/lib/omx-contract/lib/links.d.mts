import type { Json } from './json.mjs';
/** A link split: `{ path, symbol, tag?, selectors: [{ field } | { key }] }`. */
export declare function parseLink(link: any): {
    path: string;
    tag: string;
    symbol: string;
    selectors: ({
        field: string;
        key?: undefined;
    } | {
        key: string;
        field?: undefined;
    })[];
} | undefined;
/**
 * Every definition of `symbol` in `text`, one per place the symbol is defined: `{ kind, at, text }`, `kind` one of
 * define, const, function, enum, struct, union, type, var. A tag (`enum X`) finds only that tag's body.
 */
export declare function definitions(source: any, symbol: any, tag: any): any[];
/**
 * The links of a source, each with the `at` it lies at: its own (`{ link, at }`), else the source's, else none (the
 * owner's tree). `[{ role: 'impl' | 'from', field, link, at }]`, `field` the value's field path of a `from` map ('' for
 * the whole value).
 */
export declare function linksOf(source: any): {
    role: any;
    field: any;
    link: any;
    at: any;
}[];
/** Every item's source: its own, else its file's. `[{ name, rel, pkg, source }]`, items with neither left out. */
export declare function sourcesOf(data: Json): Json[];
/**
 * Check every link of the items: `{ problems: [{ code, file, item, link, message }], checked, unchecked, none }`.
 * `root` is the owner's tree; `trees` maps a package named by `at` to its tree; `requireImpl` makes an item with no
 * `impl` a problem; `only` keeps the items of one package.
 */
export declare function checkLinks(data: Json, { root, trees, requireImpl, only }?: {
    root?: string;
    trees?: Readonly<Record<string, string>>;
    requireImpl?: boolean;
    only?: string;
}): {
    problems: Json[];
    checked: number;
    unchecked: Json[];
    none: number;
};
