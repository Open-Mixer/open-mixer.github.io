/// <reference types="node" resolution-mode="require"/>
import type { DomainCodes } from './domain.mjs';
import type { JsonObject } from './json.mjs';
/** The schema major this reader reads: a manifest's and a domain document's `x-omx-contract` and a file's `$schema` must state it. */
export declare const SCHEMA_MAJOR: number;
export { CONTRACT_FORMAT } from './format.mjs';
/** The package whose files are read by the schema they ship with, and whose items every file may refer to. */
export declare const SCHEMA_PACKAGE = "omx-contract";
/** The `$schema` an installed file carries: the schema of its major, by URL. */
export declare const installedSchemaUrl: (major: any) => string;
/** Whether version `v` is at least version `floor`, both x.y.z. */
export declare function atLeast(v: any, floor: any): boolean;
/** The x.y.z of a floor `>= x.y.z`, or undefined when it is not one. */
export declare const floorOf: (s: any) => string | undefined;
/** The sha256 of a file's bytes, as the manifest lists it. */
export declare const sha256: (bytes: any) => string;
/**
 * The directories that stand where `contractdir` stands, in their order: `dir` (a path or a list) when given, else
 * `$OMX_CONTRACT_PATH` (a `:` list), else `pkg-config --variable=contractdir omx-contract`.
 * @throws contract.dir.absent when none is found, or one named does not exist.
 */
/** Where the contract directory is read from: `dir` (one or a list), else `env.OMX_CONTRACT_PATH`, else pkg-config. */
export interface ContractRootsOptions {
    readonly dir?: string | readonly string[];
    readonly env?: NodeJS.ProcessEnv;
    readonly pkgConfig?: string;
}
/** What `loadContractDir` reads, and what the consumer requires: `needs` as `{ <package>: '>= x.y.z' }`. */
export interface LoadContractDirOptions extends ContractRootsOptions {
    readonly needs?: Readonly<Record<string, string>>;
    readonly major?: number;
    /**
     * The domains read in their data form (docs/render.md, `render --installed --with-domain`, repeatable): each its
     * document `doc`, named `name`, at `path`. The data files each rebuilds (domainDataFiles) join the installed package
     * its `info.x-owner` names, so two domains of one owner (an item of one naming an item of the other) rebuild into one
     * package; a domain directory of one of these names in the roots is not also read as a domain.
     */
    readonly withDomains?: readonly {
        readonly name: string;
        readonly doc: JsonObject;
        readonly path: string;
    }[];
}
/** One file of the read: its reported path, text and document, its package and installed path. */
export interface ContractFile {
    readonly rel: string;
    readonly text: string;
    readonly doc: JsonObject;
    readonly pkg: string;
    readonly path: string;
    readonly installed: true;
}
/** One item of the read, by name: where it is declared and by which package. */
export interface ContractItem {
    readonly name: string;
    readonly rel: string;
    readonly item: JsonObject;
    readonly pkg: string;
}
/** One installed package of the read: its name, directory and manifest. */
export interface ContractPackage {
    readonly name: string;
    readonly dir: string;
    readonly manifest: JsonObject;
    /** A domain's items marked `x-c-codes` (docs/render.md); absent for a package of the other layout. */
    readonly codes?: DomainCodes;
}
export declare function contractRoots({ dir, env, pkgConfig }?: ContractRootsOptions): string[];
/**
 * Read the contract directory: `{ files, items, packages, roots }`, `files` and `items` in loadData's shape (each
 * file with `pkg`, `path` and `installed: true`, each item with `pkg`), files in the order of their reported path
 * (`<manifest tree>/<file>`, else `<package>/<file>`), `packages` a Map of package name to its manifest and dir.
 * `needs` is what the consumer requires, `{ <package>: '>= x.y.z' }`. A file's `requires` names packages, no version (the devel wave 2026-11-24).
 * @throws ContractRefusal, the first refusal met; see docs/contract-dir.md for the order.
 */
export declare function loadContractDir({ dir, env, pkgConfig, needs, major, withDomains }?: LoadContractDirOptions): {
    files: ContractFile[];
    items: Map<string, ContractItem>;
    packages: Map<string, ContractPackage>;
    roots: string[];
};
/** The version a read of the directory renders under: omx-contract's own manifest version, else `fallback`. */
export declare const contractVersion: (data: any, fallback: any) => any;
