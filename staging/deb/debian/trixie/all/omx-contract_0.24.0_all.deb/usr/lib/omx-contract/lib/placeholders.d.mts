/**
 * A sentence's `{name}` placeholders: what a code's or a word's source sentence and each catalog entry are held to
 * against the code's `args` (docs/data-layout.md). Its own module so the catalog reader carries no validator.
 */
/** The names of `sentence`'s `{name}` placeholders. */
export declare function placeholdersOf(sentence: unknown): Set<string>;
