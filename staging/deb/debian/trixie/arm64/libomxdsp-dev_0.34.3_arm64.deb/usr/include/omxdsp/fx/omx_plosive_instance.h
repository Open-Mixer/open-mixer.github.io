/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
 *
 * omx_plosive_instance.h — the plosive and consonant tamer as a plugin instance (the FX-13 design): a
 * transient detector listening to two bands and cutting only them. It mints no
 * word: the detector is omx_envdiff_step with the transient designer's fast follower and its ramp
 * omx_envdiff_ramp at an offset, the pop split is omx_allpass1's power-complementary pair, the
 * consonant band is the de-esser's cookbook bandpass in its split topology.
 *
 *   pop        LP = (x + A x)/2, A the first-order allpass at popHz; dP the legs' 0.5/0.5 fold of |LP|;
 *              gP = 10^(-popDb ramp(dP's contrast, popSensitivityDb)/20); x1 = x - (1 - gP) LP
 *   consonant  B the bandpass of x1 at bandHz, bandWidthOct; dC the fold of |B|;
 *              gC = 10^(-consonantDb ramp(dC's contrast, sensitivityDb)/20); y = x1 + (gC - 1) B
 *
 * Each half is bounded by 1 at every frequency (|((1 + g) + (g - 1) A)/2| <= 1 and the de-esser's
 * split), so no gain is added (L4). A gain of exactly 1 takes the half's unity branch, so a sustained
 * vowel whose contrast stays under the sensitivity passes bit for bit (L2), and consonantDb = popDb = 0
 * is the input bit for bit with the detectors running (L5). The pop half runs first so the consonant
 * detector reads the voice without the pop's spill. Both legs share each detector, so the image never
 * shifts.
 *
 *   RESOLVE. omx_plosive_instance_resolve() takes the plosive kernel's contract controls in their
 *   declared order (data/kernels/plosive.json), each clamped into its travel, a non-finite word reading
 *   as its default. The band's edges are bandHz / 2^(w/2) and bandHz 2^(w/2), the top one held under
 *   PLOSIVE_BAND_EDGE_FRACTION of the rate, and the section is designed from the held edges.
 *   RUN. Per sample as above; the deepest cut of each half in the block is its readout
 *   (omx_plosive_instance_consonant_reduction_db(), omx_plosive_instance_pop_reduction_db()).
 *
 * LATENCY IS ZERO (L1). Nothing is allocated; every word of state is in {@link OmxPlosiveInstance}.
 */
/**
 * @file omx_plosive_instance.h
 * @brief the plosive and consonant tamer as a plugin instance (the FX-13 design): a transient detector listening to two bands and cutting only them.
 */
#ifndef OMX_PLOSIVE_INSTANCE_H
#define OMX_PLOSIVE_INSTANCE_H

#include <math.h>
#include <stdint.h>
#include <string.h>

#include <omxdsp/omx_allpass.h>
#include <omxdsp/omx_biquad.h>
#include <omxdsp/omx_denormal.h>
#include <omxdsp/omx_envelope.h>
#include <omxdsp/omx_eq_design.h>
#include <omxdsp/omx_onepole.h>
#include <omxdsp/fx/omx_instance_io.h>
#include <omxdsp/omx_param.h>
#include <omxdsp/omx_units.h>
#include <omxdsp/omxdsp_definitions.h>

/** @brief Audio legs in and out: TWO, a stereo pair. */
#define OMX_PLOSIVE_INSTANCE_CHANNELS 2

/** The consonant band's top edge, as a share of the rate: PLOSIVE_BAND_EDGE_FRACTION. */
#define OMX_PLOSIVE_INSTANCE_EDGE OMX_PLOSIVE_BAND_EDGE_FRACTION_DOUBLE

/** One half's detector: the transient designer's fast follower and a slow one differing in its attack. */
struct omx_plosive_detector {
  /** @var omx_plosive_detector::slow
   * The slow follower's envelope: omx_envdiff_step() steps it, its attack the half's recovery time. */
  /** The fast follower's envelope: omx_env_step() steps it with the half's fast poles. */
  struct omx_env fast, slow;
};

/** One instance: the resolved controls, the pop split's and the consonant band's designs, each half's detector and
 * the deepest gain of each half in the last block. */
typedef struct {
  /** The sample rate init bound the instance to, Hz. */
  float sr;
  /** @var OmxPlosiveInstance::cons_s
   * sensitivityDb as resolve() clamped it, dB, 0 to 30: the consonant detector's contrast offset. */
  /** @var OmxPlosiveInstance::cons_rec
   * recoveryMs as resolve() clamped it, ms, 2 to 50: the consonant detector's slow attack. */
  /** @var OmxPlosiveInstance::band_hz
   * bandHz as resolve() clamped it, Hz, 1000 to 12000: the consonant band's centre before the edge hold. */
  /** @var OmxPlosiveInstance::band_oct
   * bandWidthOct as resolve() clamped it, octaves, 0.5 to 4: the consonant band's width before the edge hold. */
  /** @var OmxPlosiveInstance::pop_db
   * popDb as resolve() clamped it, dB, 0 to 24: the pop half's cut at full contrast. */
  /** @var OmxPlosiveInstance::pop_s
   * popSensitivityDb as resolve() clamped it, dB, 0 to 30: the pop detector's contrast offset. */
  /** @var OmxPlosiveInstance::pop_rec
   * popRecoveryMs as resolve() clamped it, ms, 10 to 200: the pop detector's slow attack. */
  /** @var OmxPlosiveInstance::pop_hz
   * popHz as resolve() clamped it, Hz, 60 to 300: the pop split's corner. */
  /** consonantDb as resolve() clamped it, dB, 0 to 24: the consonant half's cut at full contrast. */
  float cons_db, cons_s, cons_rec, band_hz, band_oct, pop_db, pop_s, pop_rec, pop_hz;
  /* the designs */
  float a;                       /**< the pop split's allpass coefficient */
  float bp[5];                   /**< the consonant band's section */
  struct omx_env_params fe;      /**< the fast follower's parameters, peak */
  struct omx_envdiff_poles pp;   /**< the pop detector's poles */
  struct omx_envdiff_poles cp;   /**< the consonant detector's poles */
  /* the state */
  struct omx_allpass1 ap[2];     /**< the pop split's allpass, per leg */
  float bs[2][4];                /**< the band section's history, per leg */
  /** @var OmxPlosiveInstance::cd
   * The consonant half's detector, reading the legs' fold of the band section's output. */
  /** The pop half's detector, reading the legs' fold of the pop band. */
  struct omx_plosive_detector pd, cd;
  /** @var OmxPlosiveInstance::cons_min
   * The consonant half's deepest gain in the last block run() ran, linear, 1 when it cut nothing; init sets 1. */
  /** The pop half's deepest gain in the last block run() ran, linear, 1 when it cut nothing; init sets 1. */
  float pop_min, cons_min;
  /** Non-zero while the effect is engaged, as the last resolve() set it; while zero, run() leaves the output as the input. */
  int enabled;
  /** Non-zero once init bound the instance to a usable rate; while zero, resolve() does nothing and run() leaves the output as the input. */
  int ready;
} OmxPlosiveInstance;

/** The half's gain for a contrast: 10^(-amount ramp(delta, s)/20), exactly 1 below the offset.
 * @param amount_db The half's cut at full contrast, dB; 0 or less gives 1.
 * @param delta The detector's contrast, dB, from omx_envdiff_step().
 * @param s_db The half's sensitivity, dB: the ramp's offset.
 * @return The gain, linear, in (0, 1]; exactly 1 while the ramp reads 0 or the amount is 0.
 * @thread audio */
static inline float omx_plosive_gain(float amount_db, float delta, float s_db) {
  const float u = omx_envdiff_ramp(delta, s_db);
  return u > 0.0f && amount_db > 0.0f ? omx_db_to_lin_poly(-amount_db * u) : 1.0f;
}

/** One leg's pop band, LP = (x + A x)/2, the allpass's word advanced.
 * @param ap The leg's first-order allpass state; advanced by one sample.
 * @param a The allpass coefficient, from omx_allpass1_coef() at popHz.
 * @param x The leg's input sample.
 * @return The pop band's sample, LP.
 * @thread audio */
static inline float omx_plosive_pop_band(struct omx_allpass1 *ap, float a, float x) {
  return 0.5f * (x + omx_allpass1_tick(ap, x, a));
}

/** The pop half at gain g: x - (1 - g) LP, the input itself at g = 1 (L2).
 * @param x The leg's input sample.
 * @param lp The leg's pop band sample, from omx_plosive_pop_band().
 * @param g The pop half's gain, linear.
 * @return x1, the sample with its pop band cut to `g`.
 * @thread audio */
static inline float omx_plosive_pop_apply(float x, float lp, float g) { return g != 1.0f ? x - (1.0f - g) * lp : x; }

/** The consonant half at gain g: x1 + (g - 1) B, x1 itself at g = 1 (L2).
 * @param x1 The leg's sample after the pop half.
 * @param b The leg's consonant band sample, the band section over `x1`.
 * @param g The consonant half's gain, linear.
 * @return The output sample, the consonant band cut to `g`.
 * @thread audio */
static inline float omx_plosive_cons_apply(float x1, float b, float g) { return g != 1.0f ? x1 + (g - 1.0f) * b : x1; }

static inline void omx_plosive_instance_resolve(OmxPlosiveInstance *s, int bypass, float consonant_db, float sensitivity_db,
                                                float recovery_ms, float band_hz, float band_width_oct, float pop_db,
                                                float pop_sensitivity_db, float pop_recovery_ms, float pop_hz);

/** Bind an instance to its rate. Returns 1 when usable, 0 when not: the rate must be one of the oracle
 * set. The tamer comes up at its declared defaults. Allocates nothing.
 * @param s The instance; every word of it is written.
 * @param sr The sample rate, Hz, one of the oracle set.
 * @return 1 when usable, 0 when not: a rate the console does not declare (the oracle set, 32 to 192 kHz) is refused, `ready` stays clear and run() is the identity.
 * @thread control */
static inline int omx_plosive_instance_init(OmxPlosiveInstance *s, float sr) {
  if (!omx_instance_bind(s, sizeof(*s), sr)) return 0;
  s->sr = sr;
  s->ready = 1;
  s->pop_min = s->cons_min = 1.0f;
  omx_plosive_instance_resolve(s, 0, (float)OMX_PLOSIVE_CONSONANT_DB_RANGE_DEFAULT, (float)OMX_PLOSIVE_SENSITIVITY_DB_RANGE_DEFAULT,
                               (float)OMX_PLOSIVE_RECOVERY_MS_RANGE_DEFAULT, (float)OMX_PLOSIVE_BAND_HZ_RANGE_DEFAULT,
                               (float)OMX_PLOSIVE_BAND_WIDTH_OCT_RANGE_DEFAULT, (float)OMX_PLOSIVE_POP_DB_RANGE_DEFAULT,
                               (float)OMX_PLOSIVE_POP_SENSITIVITY_DB_RANGE_DEFAULT, (float)OMX_PLOSIVE_POP_RECOVERY_MS_RANGE_DEFAULT,
                               (float)OMX_PLOSIVE_POP_HZ_RANGE_DEFAULT);
  return 1;
}

/** The detector poles of a half whose slow follower attacks in `slow_attack_ms`.
 * @param fe The fast follower's parameters; the slow follower takes its release.
 * @param slow_attack_ms The slow follower's attack, ms: the half's recovery time.
 * @param sr The sample rate, Hz.
 * @param p The half's poles, written: the fast attack and release, the slow attack and release.
 * @thread audio */
static inline void omx_plosive_poles(const struct omx_env_params *fe, float slow_attack_ms, float sr,
                                     struct omx_envdiff_poles *p) {
  omx_env_stage_poles(fe, 1u, &p->fast_attack, &p->fast_release);
  const struct omx_env_params sa = {omx_pole_from_time_ms(slow_attack_ms, sr), fe->release_pole, OMX_DETECT_PEAK};
  omx_env_stage_poles(&sa, 1u, &p->slow_attack, &p->slow_release);
}

#define OMX_CONTRACT_STAGE "plosive/instance-resolve"
/**
 * Resolve the host's control values for one cycle. `bypass` non-zero makes run() the identity. The
 * arguments are the plosive kernel's contract controls in their declared order (dB, dB, ms, Hz,
 * octaves, dB, dB, ms, Hz).
 * @param s The instance; null or not ready leaves it as it is.
 * @param bypass Non-zero makes run() the identity.
 * @param consonant_db consonantDb, 0 to 24 dB, default 6: How far a hard consonant (t, k) is cut in its band, dB, at
 *        full contrast: y = x1 + (g - 1) B, the de-esser's split, so no gain is added at any frequency.
 * @param sensitivity_db sensitivityDb, 0 to 30 dB, default 16: The contrast, dB between the band's fast and slow
 *        envelopes (omx_envdiff), a burst must pass before the consonant cut starts; the cut is full TRANSIENT_REF_DB
 *        past it (omx_envdiff_ramp).
 * @param recovery_ms recoveryMs, 2 to 50 ms, default 8: The consonant detector's slow attack, ms: how long a burst's
 *        contrast lasts, so how long the cut does.
 * @param band_hz bandHz, 1000 to 12000 Hz, default 4000: The consonant band's centre, Hz: the de-esser's cookbook
 *        bandpass section.
 * @param band_width_oct bandWidthOct, 0.5 to 4 oct, default 2: The consonant band's width, octaves; its top edge is
 *        held under PLOSIVE_BAND_EDGE_FRACTION of the rate.
 * @param pop_db popDb, 0 to 24 dB, default 12: How far a p pop is cut below popHz, dB, at full contrast: x1 = x - (1 -
 *        g) LP, the low half of a first-order power-complementary split, so no gain is added.
 * @param pop_sensitivity_db popSensitivityDb, 0 to 30 dB, default 16: The contrast, dB, the pop band's burst must pass
 *        before the pop cut starts.
 * @param pop_recovery_ms popRecoveryMs, 10 to 200 ms, default 40: The pop detector's slow attack, ms.
 * @param pop_hz popHz, 60 to 300 Hz, default 150: The pop split's corner, Hz: the first-order allpass (omx_allpass1)
 *        whose halves are the pop band and the rest.
 * @post `designs-inside-their-laws`: the pop split's allpass coefficient inside (-1, 1) and the consonant band's upper
 *       edge above its lower one.
 * @thread audio
 */
static inline void omx_plosive_instance_resolve(OmxPlosiveInstance *s, int bypass, float consonant_db, float sensitivity_db,
                                                float recovery_ms, float band_hz, float band_width_oct, float pop_db,
                                                float pop_sensitivity_db, float pop_recovery_ms, float pop_hz) {
  if (!s || !s->ready) return;
  s->cons_db = omx_clamp_or(consonant_db, (float)OMX_PLOSIVE_CONSONANT_DB_RANGE_MIN, (float)OMX_PLOSIVE_CONSONANT_DB_RANGE_MAX,
                         (float)OMX_PLOSIVE_CONSONANT_DB_RANGE_DEFAULT);
  s->cons_s = omx_clamp_or(sensitivity_db, (float)OMX_PLOSIVE_SENSITIVITY_DB_RANGE_MIN, (float)OMX_PLOSIVE_SENSITIVITY_DB_RANGE_MAX,
                         (float)OMX_PLOSIVE_SENSITIVITY_DB_RANGE_DEFAULT);
  s->cons_rec = omx_clamp_or(recovery_ms, (float)OMX_PLOSIVE_RECOVERY_MS_RANGE_MIN, (float)OMX_PLOSIVE_RECOVERY_MS_RANGE_MAX,
                         (float)OMX_PLOSIVE_RECOVERY_MS_RANGE_DEFAULT);
  s->band_hz = omx_clamp_or(band_hz, (float)OMX_PLOSIVE_BAND_HZ_RANGE_MIN, (float)OMX_PLOSIVE_BAND_HZ_RANGE_MAX,
                         (float)OMX_PLOSIVE_BAND_HZ_RANGE_DEFAULT);
  s->band_oct = omx_clamp_or(band_width_oct, (float)OMX_PLOSIVE_BAND_WIDTH_OCT_RANGE_MIN, (float)OMX_PLOSIVE_BAND_WIDTH_OCT_RANGE_MAX,
                         (float)OMX_PLOSIVE_BAND_WIDTH_OCT_RANGE_DEFAULT);
  s->pop_db = omx_clamp_or(pop_db, (float)OMX_PLOSIVE_POP_DB_RANGE_MIN, (float)OMX_PLOSIVE_POP_DB_RANGE_MAX,
                         (float)OMX_PLOSIVE_POP_DB_RANGE_DEFAULT);
  s->pop_s = omx_clamp_or(pop_sensitivity_db, (float)OMX_PLOSIVE_POP_SENSITIVITY_DB_RANGE_MIN, (float)OMX_PLOSIVE_POP_SENSITIVITY_DB_RANGE_MAX,
                         (float)OMX_PLOSIVE_POP_SENSITIVITY_DB_RANGE_DEFAULT);
  s->pop_rec = omx_clamp_or(pop_recovery_ms, (float)OMX_PLOSIVE_POP_RECOVERY_MS_RANGE_MIN, (float)OMX_PLOSIVE_POP_RECOVERY_MS_RANGE_MAX,
                         (float)OMX_PLOSIVE_POP_RECOVERY_MS_RANGE_DEFAULT);
  s->pop_hz = omx_clamp_or(pop_hz, (float)OMX_PLOSIVE_POP_HZ_RANGE_MIN, (float)OMX_PLOSIVE_POP_HZ_RANGE_MAX,
                         (float)OMX_PLOSIVE_POP_HZ_RANGE_DEFAULT);
  s->a = omx_allpass1_coef(s->pop_hz, s->sr);
  const double half = pow(2.0, 0.5 * (double)s->band_oct);
  const double lo = (double)s->band_hz / half, hi = fmin((double)s->band_hz * half, OMX_PLOSIVE_INSTANCE_EDGE * (double)s->sr);
  omx_eq_design_f(OMX_EQ_BANDPASS, sqrt(lo * hi), omx_eq_octaves_q(log2(hi / lo)), 0.0, (double)s->sr, s->bp);
  s->fe = (struct omx_env_params){omx_pole_from_time_ms(OMX_TRANSIENT_FAST_ATTACK_MS, s->sr),
                                  omx_pole_from_time_ms(OMX_TRANSIENT_FAST_RELEASE_MS, s->sr), OMX_DETECT_PEAK};
  omx_plosive_poles(&s->fe, s->pop_rec, s->sr, &s->pp);
  omx_plosive_poles(&s->fe, s->cons_rec, s->sr, &s->cp);
  s->enabled = bypass ? 0 : 1;
  OMX_POST(s->a > -1.0f && s->a < 1.0f && hi > lo, "designs-inside-their-laws");
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "plosive/instance-run"
/**
 * THE AUDIO CALLBACK'S WHOLE SHARE: the pop half then the consonant half, in to out. `in_*` and `out_*`
 * may alias. Not ready or bypassed is the identity and moves no state.
 * @param s The instance; null, not ready or bypassed leaves `out_*` holding `in_*`.
 * @param in_l The left input, `n` frames.
 * @param in_r The right input, `n` frames.
 * @param out_l The left output, `n` frames, may be `in_l`.
 * @param out_r The right output, `n` frames, may be `in_r`.
 * @param n The block length, frames; a null port or 0 touches nothing.
 * @pre `finite-in`: the input, copied through to the output legs, is finite.
 * @post `finite-out`: both output legs are finite.
 * @thread audio
 */
static inline void omx_plosive_instance_run(OmxPlosiveInstance *s, const float *in_l, const float *in_r, float *out_l,
                                            float *out_r, uint32_t n) {
  if (!omx_instance_through_engaged(in_l, in_r, out_l, out_r, n, s && s->ready && s->enabled)) return;
  OMX_PRE(omx_block_pair_finite(out_l, out_r, n), "finite-in");
  float pmin = 1.0f, cmin = 1.0f;
  for (uint32_t i = 0; i < n; i++) {
    const float xl = out_l[i], xr = out_r[i];
    /* the pop half: its detector reads this sample's low band, its gain applies to it */
    const float lpl = omx_plosive_pop_band(&s->ap[0], s->a, xl), lpr = omx_plosive_pop_band(&s->ap[1], s->a, xr);
    const float dp = 0.5f * (fabsf(lpl) + fabsf(lpr));
    const float fp = omx_env_step(&s->pd.fast, &s->fe, dp, s->pp.fast_attack, s->pp.fast_release);
    const float gp = omx_plosive_gain(s->pop_db, omx_envdiff_step(&s->pd.slow, &s->fe, dp, fp, &s->pp, OMX_TRANSIENT_FLOOR_LIN), s->pop_s);
    const float x1l = omx_plosive_pop_apply(xl, lpl, gp), x1r = omx_plosive_pop_apply(xr, lpr, gp);
    /* the consonant half, on what the pop half left */
    const float bl = omx_biquad(x1l, s->bp, s->bs[0]), br = omx_biquad(x1r, s->bp, s->bs[1]);
    const float dc = 0.5f * (fabsf(bl) + fabsf(br));
    const float fc = omx_env_step(&s->cd.fast, &s->fe, dc, s->cp.fast_attack, s->cp.fast_release);
    const float gc = omx_plosive_gain(s->cons_db, omx_envdiff_step(&s->cd.slow, &s->fe, dc, fc, &s->cp, OMX_TRANSIENT_FLOOR_LIN), s->cons_s);
    out_l[i] = omx_plosive_cons_apply(x1l, bl, gc);
    out_r[i] = omx_plosive_cons_apply(x1r, br, gc);
    for (int k = 0; k < 4; k++) s->bs[0][k] = omx_flush(s->bs[0][k]), s->bs[1][k] = omx_flush(s->bs[1][k]);
    for (int k = 0; k < OMX_DYN_ENV_STAGES; k++) {
      s->pd.fast.stage[k] = omx_flush(s->pd.fast.stage[k]);
      s->pd.slow.stage[k] = omx_flush(s->pd.slow.stage[k]);
      s->cd.fast.stage[k] = omx_flush(s->cd.fast.stage[k]);
      s->cd.slow.stage[k] = omx_flush(s->cd.slow.stage[k]);
    }
    pmin = gp < pmin ? gp : pmin;
    cmin = gc < cmin ? gc : cmin;
  }
  s->pop_min = pmin;
  s->cons_min = cmin;
  OMX_POST(omx_block_pair_finite(out_l, out_r, n), "finite-out");
}
#undef OMX_CONTRACT_STAGE

/** The consonantReductionDb readout: the deepest consonant cut of the last block, dB, at most 0.
 * @param s The instance; null or not ready reads 0.
 * @return The consonant half's deepest gain in the last block, dB, at most 0; 0 when it cut nothing.
 * @thread audio */
static inline float omx_plosive_instance_consonant_reduction_db(const OmxPlosiveInstance *s) {
  return s && s->ready && s->cons_min < 1.0f ? omx_lin_to_db(s->cons_min) : 0.0f;
}

/** The popReductionDb readout: the deepest pop cut of the last block, dB, at most 0.
 * @param s The instance; null or not ready reads 0.
 * @return The pop half's deepest gain in the last block, dB, at most 0; 0 when it cut nothing.
 * @thread audio */
static inline float omx_plosive_instance_pop_reduction_db(const OmxPlosiveInstance *s) {
  return s && s->ready && s->pop_min < 1.0f ? omx_lin_to_db(s->pop_min) : 0.0f;
}

/** The frames of latency the instance introduces: none.
 * @param s The instance.
 * @return 0.
 * @thread audio */
static inline uint32_t omx_plosive_instance_latency(const OmxPlosiveInstance *s) {
  (void)s;
  return 0u;
}

#endif /* OMX_PLOSIVE_INSTANCE_H */
