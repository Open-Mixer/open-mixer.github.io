/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
 *
 * omx_trim_instance.h — the console's input trim as a plugin instance: the lane's head gain, a
 * de-zippered ramp from the gain the last block ended on to the one resolved now, both legs from
 * the same start. No format in it.
 *
 * ## What it mirrors, and what it does not
 *
 * On the desk a lane is "trim-gain fill -> [ordered stages] -> level/pan/mute" (mix_lane.h): the
 * fill is the engine's `omx_fill_gain`, `out[i] = in[i] *
 * omx_ramp_at(r, i)` over omx_ramp.h's ramp, run once per leg from the same start gain
 * (mixer_rt.c, the trim-gain block). This face is that arithmetic, in place on the plugin's
 * output: `omx_ramp_begin` / `omx_ramp_at` / `omx_ramp_end`, the library's one ramp.
 *
 * The HPF and the LPF are NOT here. On the desk they are sections of the channel EQ's cascade
 * (`eqCoeffs` appends them after the bands; the contract declares hpfOn..lpfSlope as the eq
 * kernel's controls), so a plugin that wants them before its other stages runs the eq face
 * (omx_eq_instance.h) with every band off: one home per fact. Trim and that eq face, in that
 * order, are omx-strip's input stage bit for bit (test/fx/trim_instance.test.c, arm C, and the
 * golden digests).
 *
 * The desk folds the channel's polarity into this gain as a sign; the contract's trim kernel
 * declares no polarity control, so this face has none.
 *
 * ## The control
 *
 * `trim_db`, the trim kernel's one control `trimDb` (TRIM_RANGE, omxdsp_definitions.h), in dB:
 * clamped into its declared travel, a non-finite word reading as its declared default (0 dB), and
 * turned into a linear gain with omx_db_to_lin. Bypass is the identity and holds the ramp where it
 * was, so re-engaging glides from the gain the last engaged block ended on. A fresh instance's
 * gain is unity: a first block at 0 dB is the identity, a first block elsewhere ramps from unity.
 * LATENCY IS ZERO. No allocation, no lock; every word of state is in the caller's
 * {@link OmxTrimInstance}.
 */
/**
 * @file omx_trim_instance.h
 * @brief the console's input trim as a plugin instance: the lane's head gain, a de-zippered ramp from the gain the last block ended on to the one resolved now, both legs from the same start. No format in it.
 */
#ifndef OMX_TRIM_INSTANCE_H
#define OMX_TRIM_INSTANCE_H

#include <stdint.h>
#include <string.h>

#include <omxdsp/omxdsp_definitions.h>
#include <omxdsp/fx/omx_instance_io.h>
#include <omxdsp/omx_param.h>
#include <omxdsp/omx_ramp.h>
#include <omxdsp/omx_units.h>

/** @brief Audio legs in and out: TWO, a stereo pair. */
#define OMX_TRIM_INSTANCE_CHANNELS 2
/** @brief The latency the instance reports to its host, frames: none. */
#define OMX_TRIM_INSTANCE_LATENCY_FRAMES 0.0f

/** The port default: the declaration's (TRIM_RANGE.default, dB). */
#define OMX_TRIM_INSTANCE_TRIM_DB_DEFAULT ((float)OMX_TRIM_RANGE_DEFAULT)

/** One instance: the linear gain the last block ended on and the one the next block ramps to. */
typedef struct {
  /** The linear gain the last engaged block ended on; init sets it to 1, run() ramps it to `tgt`. */
  float cur, tgt; ///< tgt: the linear gain resolve() resolved from trimDb, the one the next block ramps to.
  /** Non-zero while bypassed, as the last resolve() set it; run() then copies the input and leaves `cur` as is. */
  int bypass;
  /** Non-zero once init bound the instance to a usable rate; while zero, resolve() does nothing and run() leaves the output as the input. */
  int ready;
} OmxTrimInstance;

/** Bind an instance to its rate: unity gain, engaged. Returns 1 when usable, 0 when the rate is
 * not positive and finite (run() is then the identity). The gain does not depend on the rate; the
 * rate is checked so a host's refused instance behaves as every other face's. Allocates nothing.
 * @param s The instance; every word of it is written.
 * @param sr The sample rate, Hz, positive and finite; the gain does not depend on it.
 * @return 1 when usable, 0 when not: a null instance or a rate that is not positive and finite is refused, `ready` stays clear and run() is the identity.
 * @thread control */
static inline int omx_trim_instance_init(OmxTrimInstance *s, float sr) {
  if (!s) return 0;
  memset(s, 0, sizeof(*s));
  if (!(sr > 0.0f) || sr - sr != 0.0f) return 0;
  s->cur = s->tgt = 1.0f;
  s->ready = 1;
  return 1;
}

#define OMX_CONTRACT_STAGE "trim-instance/resolve"
/**
 * Resolve the host's control value for one cycle. `bypass` non-zero makes run() the identity.
 * The argument is the trim kernel's contract control, in its user unit: `trim_db` (dB), clamped
 * into TRIM_RANGE, a non-finite word reading as its default.
 * @param s The instance; null or not ready leaves it as it is.
 * @param bypass Non-zero makes run() the identity.
 * @param trim_db trimDb, -24 to 24 dB, default 0: The digital input trim, in dB: the console's fine head gain, applied
 *        first in a channel's lane as a click-free ramp from the last block's gain to this one (the console's trim
 *        range, -24..+24 dB in 0.1 dB steps, spelled minDb/maxDb/stepDb there).
 * @post `a-finite-positive-gain`: the target gain is finite and above 0.
 * @thread audio
 */
static inline void omx_trim_instance_resolve(OmxTrimInstance *s, int bypass, float trim_db) {
  if (!s || !s->ready) return;
  s->bypass = bypass ? 1 : 0;
  s->tgt = omx_db_to_lin(omx_clamp_or(trim_db, (float)OMX_TRIM_RANGE_MIN, (float)OMX_TRIM_RANGE_MAX,
                                      OMX_TRIM_INSTANCE_TRIM_DB_DEFAULT));
  OMX_POST(s->tgt > 0.0f && s->tgt - s->tgt == 0.0f, "a-finite-positive-gain");
}
#undef OMX_CONTRACT_STAGE

/**
 * THE AUDIO CALLBACK'S WHOLE SHARE: copy in to out where they differ, then ramp both legs from
 * the same start gain to the resolved one, in place on out. `in_*` and `out_*` may alias. Not
 * ready, or bypassed, is the identity.
 * @param s The instance; null, not ready or bypassed leaves `out_*` holding `in_*`.
 * @param in_l The left input, `n` frames.
 * @param in_r The right input, `n` frames.
 * @param out_l The left output, `n` frames, may be `in_l`.
 * @param out_r The right output, `n` frames, may be `in_r`.
 * @param n The block length, frames; a null port or 0 touches nothing.
 * @thread audio
 */
static inline void omx_trim_instance_run(OmxTrimInstance *s, const float *in_l, const float *in_r, float *out_l,
                                         float *out_r, uint32_t n) {
  if (!omx_instance_copy_through(in_l, in_r, out_l, out_r, n)) return;
  if (!s || !s->ready || s->bypass) return;
  const struct omx_ramp g = omx_ramp_begin(&s->cur, s->tgt, n);
  for (uint32_t i = 0; i < n; i++) out_l[i] *= omx_ramp_at(g, i), out_r[i] *= omx_ramp_at(g, i);
  omx_ramp_end(g, &s->cur);
}

/** The frames of latency the instance introduces: none (a gain has no delay line).
 * @param s The instance.
 * @return 0.
 * @thread audio */
static inline uint32_t omx_trim_instance_latency(const OmxTrimInstance *s) {
  (void)s;
  return 0u;
}

#endif /* OMX_TRIM_INSTANCE_H */
