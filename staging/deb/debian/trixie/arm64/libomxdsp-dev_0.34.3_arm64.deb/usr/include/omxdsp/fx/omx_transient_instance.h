/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
 *
 * omx_transient_instance.h — the native transient designer as a plugin instance: the shell's core,
 * with no format in it.
 *
 * The shape is omx-plugins' omx_delay_instance.h's, under the same HRP shells rule (one C core, N shells). The
 * core here is `omx_transient.h`'s `omx_transient_process` — THE SAME INLINE the console's
 * transient stage runs — and this file adds no DSP to it. What it adds is the three things a
 * host's port model needs and the kernel's atom does not carry:
 *
 *   1. STATE. `struct omx_transient_state` is three envelope cascades and a gain word, plain
 *      inline floats, so the instance holds it whole; there is nothing to hand in.
 *   2. RESOLVE. A host publishes control ports as floats in the operator's units (dB, ms).
 *      omx_transient_instance_resolve() clamps every word into the declared travel
 *      (omxdsp_definitions.h's OMX_TRANSIENT_*) BEFORE the kernel's own resolve sees it, because
 *      a foreign host's port is not the console's codec and nothing upstream has clamped it: the
 *      three gains read any non-finite word as their declared default, 0 dB (omx_clamp_or — a
 *      NaN gain carries no position), the two times read NaN as the floor and ±Inf as the ends
 *      (omx_clampf — a time is ordered). The kernel's resolve is `expf`/`powf` work, so it runs
 *      only when a control MOVED; a static instance re-resolves nothing.
 *   3. IN -> OUT. The kernel works IN PLACE on the two legs; a host connects separate input and
 *      output buffers (and may connect them to the same memory). run() copies in to out when they
 *      differ and runs the kernel on out. Identity when bypassed.
 *
 * Re-engaging from bypass CLEARS the state (the followers restart from silence), so a re-enabled
 * designer does not apply a contrast measured before the bypass.
 *
 * THE READOUTS. attackGainDb and sustainGainDb are the two shares of the gain the last sample took
 * (omx_transient_instance_attack_gain_db(), omx_transient_instance_sustain_gain_db()); with
 * outputDb they sum to it.
 *
 * LATENCY IS ZERO, AND PUBLISHED: the gain is computed from the sample it multiplies
 * (omx_transient_latency()), and a host cannot tell "zero" from "never said".
 */
/**
 * @file omx_transient_instance.h
 * @brief the native transient designer as a plugin instance: the shell's core, with no format in it.
 */
#ifndef OMX_TRANSIENT_INSTANCE_H
#define OMX_TRANSIENT_INSTANCE_H

#include <stdint.h>
#include <string.h>

#include <omxdsp/fx/omx_transient.h>
#include <omxdsp/fx/omx_instance_io.h>
#include <omxdsp/omx_param.h>

/** Audio legs in and out: TWO, because the kernel folds both legs into one detector and applies
 * one gain to both. */
#define OMX_TRANSIENT_INSTANCE_CHANNELS 2

/** Frames of latency this plugin introduces: NONE — see the header note. */
#define OMX_TRANSIENT_INSTANCE_LATENCY_FRAMES 0.0f

/** One instance: the atom, the state and the last resolved controls. */
typedef struct {
  /** The sample rate init bound the instance to, Hz. */
  float sr;
  /** The kernel's controls as resolve() last resolved them; run() hands them to the kernel's process. */
  struct omx_transient atom;
  /** The kernel's running state, carried from block to block and handed to its process with the atom. */
  struct omx_transient_state state;
  /** The clamped controls the atom was last resolved from; `resolved` 0 until the first. */
  float attack_db, sustain_db, attack_time_ms, sustain_time_ms, output_db;
  /** Non-zero once resolve() ran the kernel's resolve; 0 until the first, which runs whatever the controls hold. */
  int resolved;
  /** The previous cycle's engaged flag, so a bypass->engaged edge can clear the state. */
  int was_engaged;
  /** Non-zero once init bound the instance to a usable rate; while zero, resolve() does nothing and run() leaves the output as the input. */
  int ready;
} OmxTransientInstance;

/** @var OmxTransientInstance::sustain_db
 * sustainDb as last resolved, dB, -24 to 24. */
/** @var OmxTransientInstance::attack_time_ms
 * attackTimeMs as last resolved, ms, 2 to 50. */
/** @var OmxTransientInstance::sustain_time_ms
 * sustainTimeMs as last resolved, ms, 50 to 2000. */
/** @var OmxTransientInstance::output_db
 * outputDb as last resolved, dB, -24 to 12. */

/**
 * Bind an instance to its rate. Returns 1 when usable, 0 when not: the rate must be one of the
 * oracle set (32 to 192 kHz), so any other rate is refused, `ready` stays clear and
 * omx_transient_instance_run() is then the identity: absence is a wire, not a crash.
 * @param s The instance; every word of it is written.
 * @param sr The sample rate, Hz, one of the oracle set.
 * @return 1 when usable, 0 when not: a rate the console does not declare (the oracle set, 32 to 192 kHz) is refused, `ready` stays clear and run() is the identity.
 * @thread control
 */
static inline int omx_transient_instance_init(OmxTransientInstance *s, float sr) {
  if (!omx_instance_bind(s, sizeof(*s), sr)) return 0;
  s->sr = sr;
  omx_transient_state_init(&s->state);
  s->ready = 1;
  return 1;
}

#define OMX_CONTRACT_STAGE "transient/instance-clear"
/** The engage-edge clear: the three followers back to silence, the gain meter to 0 dB. One
 * memset over a few dozen bytes; RT-safe.
 * @param s The instance; null or not ready is ignored.
 * @post `cleared-state-is-silent`: the gain meter is back at 0 dB and the fast follower's first stage at 0.
 * @thread audio */
static inline void omx_transient_instance_clear(OmxTransientInstance *s) {
  if (!s || !s->ready) return;
  omx_transient_state_init(&s->state);
  OMX_POST(s->state.gain_db == 0.0f && s->state.fast.stage[0] == 0.0f, "cleared-state-is-silent");
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "transient/instance-resolve"
/**
 * Resolve the host's control-port values into the kernel's atom for one cycle.
 *
 * `bypass` non-zero -> the atom is disabled and the kernel passes through. Every word is clamped
 * into its declared travel first (see the header note), so the kernel's `control-inside-travel`
 * PRE never sees a foreign value; the kernel's resolve runs only when a clamped word moved.
 * @param s The instance; null or not ready leaves it as it is.
 * @param bypass Non-zero makes run() the identity.
 * @param attack_db attackDb, -24 to 24 dB, default 0.
 * @param sustain_db sustainDb, -24 to 24 dB, default 0.
 * @param attack_time_ms attackTimeMs, 2 to 50 ms, default 10.
 * @param sustain_time_ms sustainTimeMs, 50 to 2000 ms, default 250.
 * @param output_db outputDb, -24 to 12 dB, default 0.
 * @post `atom-meets-the-kernel-preconditions`: the attack, sustain and output gains inside their travels, dB.
 * @thread audio
 */
static inline void omx_transient_instance_resolve(OmxTransientInstance *s, int bypass, float attack_db,
                                                  float sustain_db, float attack_time_ms, float sustain_time_ms,
                                                  float output_db) {
  if (!s || !s->ready) return;
  /* CONTRACT (omx_contract.h). The atom this leaves behind was resolved from controls inside the
   * declared travel, whatever the host's ports held. */
  const int engaged = bypass ? 0 : 1;
  if (engaged && !s->was_engaged) omx_transient_instance_clear(s);
  s->was_engaged = engaged;
  attack_db = omx_clamp_or(attack_db, OMX_TRANSIENT_ATTACK_DB_MIN, OMX_TRANSIENT_ATTACK_DB_MAX,
                           OMX_TRANSIENT_ATTACK_DB_DEFAULT);
  sustain_db = omx_clamp_or(sustain_db, OMX_TRANSIENT_SUSTAIN_DB_MIN, OMX_TRANSIENT_SUSTAIN_DB_MAX,
                            OMX_TRANSIENT_SUSTAIN_DB_DEFAULT);
  output_db = omx_clamp_or(output_db, OMX_TRANSIENT_OUTPUT_DB_MIN, OMX_TRANSIENT_OUTPUT_DB_MAX,
                           OMX_TRANSIENT_OUTPUT_DB_DEFAULT);
  attack_time_ms = omx_clampf(attack_time_ms, OMX_TRANSIENT_ATTACK_TIME_MS_MIN, OMX_TRANSIENT_ATTACK_TIME_MS_MAX);
  sustain_time_ms = omx_clampf(sustain_time_ms, OMX_TRANSIENT_SUSTAIN_TIME_MS_MIN, OMX_TRANSIENT_SUSTAIN_TIME_MS_MAX);
  const int moved = !s->resolved || s->attack_db != attack_db || s->sustain_db != sustain_db ||
                    s->attack_time_ms != attack_time_ms || s->sustain_time_ms != sustain_time_ms || s->output_db != output_db;
  if (moved) {
    omx_transient_resolve(&s->atom, 0, attack_db, sustain_db, attack_time_ms, sustain_time_ms, output_db, s->sr);
    s->attack_db = attack_db;
    s->sustain_db = sustain_db;
    s->attack_time_ms = attack_time_ms;
    s->sustain_time_ms = sustain_time_ms;
    s->output_db = output_db;
    s->resolved = 1;
  }
  s->atom.enabled = engaged;
  OMX_POST(s->atom.attack_db >= OMX_TRANSIENT_ATTACK_DB_MIN && s->atom.attack_db <= OMX_TRANSIENT_ATTACK_DB_MAX &&
               s->atom.sustain_db >= OMX_TRANSIENT_SUSTAIN_DB_MIN &&
               s->atom.sustain_db <= OMX_TRANSIENT_SUSTAIN_DB_MAX &&
               s->atom.output_db >= OMX_TRANSIENT_OUTPUT_DB_MIN && s->atom.output_db <= OMX_TRANSIENT_OUTPUT_DB_MAX,
           "atom-meets-the-kernel-preconditions");
}
#undef OMX_CONTRACT_STAGE

#define OMX_CONTRACT_STAGE "transient/instance-run"
/**
 * THE AUDIO CALLBACK'S WHOLE SHARE: copy in to out where they differ, run the console's kernel in
 * place on out. `in_*` and `out_*` may alias. Not ready, or bypassed, is the identity byte for
 * byte.
 * @param s The instance; null, not ready or bypassed leaves `out_*` holding `in_*`.
 * @param in_l The left input, `n` frames.
 * @param in_r The right input, `n` frames.
 * @param out_l The left output, `n` frames, may be `in_l`.
 * @param out_r The right output, `n` frames, may be `in_r`.
 * @param n The block length, frames; a null port or 0 touches nothing.
 * @thread audio
 */
static inline void omx_transient_instance_run(OmxTransientInstance *s, const float *in_l, const float *in_r,
                                              float *out_l, float *out_r, uint32_t n) {
  OMX_INSTANCE_RUN_IN_PLACE(s, in_l, in_r, out_l, out_r, n, omx_transient_process(out_l, out_r, n, &s->atom, &s->state));
}
#undef OMX_CONTRACT_STAGE

/** The attackGainDb readout: the onset share of the last sample's gain, dB; 0 for a refused instance.
 * @param s The instance; null or not ready reads 0.
 * @return The kernel state's attack_gain_db, dB.
 * @thread audio */
static inline float omx_transient_instance_attack_gain_db(const OmxTransientInstance *s) {
  return s && s->ready ? s->state.attack_gain_db : 0.0f;
}

/** The sustainGainDb readout: the decay share of the last sample's gain, dB; 0 for a refused instance.
 * @param s The instance; null or not ready reads 0.
 * @return The kernel state's sustain_gain_db, dB.
 * @thread audio */
static inline float omx_transient_instance_sustain_gain_db(const OmxTransientInstance *s) {
  return s && s->ready ? s->state.sustain_gain_db : 0.0f;
}

#endif /* OMX_TRANSIENT_INSTANCE_H */
